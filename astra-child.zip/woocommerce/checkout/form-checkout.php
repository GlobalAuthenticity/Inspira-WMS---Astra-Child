<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

print do_shortcode( '[process_steps]' );

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}

/**
 * Bandera para verificar si el usuario está comprando el test de parejas.
 * 
 * Si es así, se mostrará el formulario de checkout con los campos de pareja.
 */
$is_test_parejas = false;
$test_type_parejas = AppConstants::TEST_TYPE_PAREJAS;

if ( 
	isset($_GET['add-to-cart']) && 
	($_GET['add-to-cart'] == AppConstants::TESTS_PRODUCTS_IDS[$test_type_parejas]) 
) {
	$is_test_parejas = true;
}

?>

<form name="checkout" id="auth-form" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data" aria-label="<?php echo esc_attr__( 'Checkout', 'woocommerce' ); ?>">

	<?php if ( $checkout->get_checkout_fields() ) : ?>

		<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

		<div class="col2-set" id="customer_details">
			<div class="col-1">
				<?php do_action( 'woocommerce_checkout_billing' ); ?>
			</div>

			<div class="col-2">
				<?php do_action( 'woocommerce_checkout_shipping' ); ?>
			</div>

			<?php if ( $is_test_parejas ) : ?>
	
				<h3 style="font-size: 30px; font-weight: 400; letter-spacing: 0.25px; margin: 40px 0 32px;">Prepárate para el test</h3>

        <div>
					<p class="form-row form-row-wide validate-required validate-email" id="couple_email_field" data-priority="18">
						<label for="couple_email">
							Correo electrónico de tu pareja: <span class="required">*</span>
						</label>
						<span class="woocommerce-input-wrapper">
							<input type="email" class="input-text" name="couple_email" id="couple_email" placeholder="Ingresa tu correo electrónico" value="" aria-required="true" autocomplete="email">
						</span>
					</p>
        </div>

	
			<?php endif; ?>
		</div>


		<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

	<?php endif; ?>
	
	<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
	
	<!-- <h3 id="order_review_heading"><?php esc_html_e( 'Your order', 'woocommerce' ); ?></h3> -->
	<h3 id="order_review_heading">Tu pedido</h3>
	
	<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

	<div id="order_review" class="woocommerce-checkout-review-order">
		<?php do_action( 'woocommerce_checkout_order_review' ); ?>
	</div>

	<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
