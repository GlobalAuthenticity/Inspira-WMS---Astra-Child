<?php
function shortcode_asistente_virtual_chat() {
	ob_start();
	?>
	<style>
	  #chat-container {
		width: 100%;
		border-radius: 16px;
		box-shadow: 0 10px 25px rgba(0,0,0,0.12);
		font-family: Inter, system-ui, -apple-system, sans-serif;
		background: #ffffff;
		display: flex;
		flex-direction: column;
		overflow: hidden;
	  }

	  #chat-header {
		background: #57507b;
		color: #fff;
		padding: 14px 16px;
		font-weight: 600;
		text-align: center;
	  }

	  #chat-messages {
		padding: 14px;
		height: 320px;
		overflow-y: auto;
		background: #F2F1F7;
		display: flex;
		flex-direction: column;
		gap: 6px;
	  }

	  .chat-message {
		max-width: 75%;
		padding: 6px 12px;
		font-size: 14px;
		line-height: 1.4;
		word-wrap: break-word;
		white-space: pre-wrap;
		opacity: 0;
		transform: translateY(8px) scale(0.98);
	  }

	  .chat-message.animate-in {
		animation: message-pop 0.25s ease-out forwards;
	  }

	  @keyframes message-pop {
		to {
		  opacity: 1;
		  transform: translateY(0) scale(1);
		}
	  }

	  /* ASISTENTE */
	  .chat-message.assistant {
		align-self: flex-start;
		background: #ffffff;
		color: #1f2937;
		border-radius: 16px 16px 16px 4px;
		box-shadow: 0 1px 1px rgba(0,0,0,0.08);
	  }

	  /* USUARIO */
	  .chat-message.user {
		align-self: flex-end;
		background: #E6E4F0;
		color: #1f2937;
		border-radius: 16px 16px 4px 16px;
		box-shadow: 0 1px 1px rgba(0,0,0,0.08);
	  }

	  /* Typing */
	  .chat-message.typing {
		opacity: 1;
		transform: none;
		animation: none;
		align-self: flex-start;
		background: #ffffff;
		border-radius: 16px 16px 16px 4px;
		padding: 8px 12px;
		display: flex;
		gap: 4px;
		box-shadow: 0 1px 1px rgba(0,0,0,0.08);
		width: fit-content;
	  }

	  .typing-dot {
		width: 6px;
		height: 6px;
		background: #57507b;
		border-radius: 50%;
		animation: blink 1.4s infinite both;
	  }

	  .typing-dot:nth-child(2) { animation-delay: 0.2s; }
	  .typing-dot:nth-child(3) { animation-delay: 0.4s; }

	  @keyframes blink {
		0% { opacity: 0.2; }
		20% { opacity: 1; }
		100% { opacity: 0.2; }
	  }

	  #chat-input-area {
		display: flex;
		gap: 8px;
		padding: 12px;
		border-top: 1px solid #E5E7EB;
		background: #F9FAFB;
	  }

	  #chat-input {
		flex: 1;
		padding: 10px 14px;
		border-radius: 20px;
		border: 1px solid #D1D5DB;
		font-size: 14px;
		outline: none;
	  }

	  #chat-input:focus {
		border-color: #6a6390;
	  }

	  #chat-send {
		background: #57507b;
		color: #fff;
		border: none;
		border-radius: 50%;
		width: 42px;
		height: 42px;
		cursor: pointer;
	  }

	  #chat-send:hover {
		background: #4a4468;
	  }
	</style>

	<div id="chat-container">
	  <div id="chat-header"><img 
  src="https://inspira.wmslatam.com/wp-content/uploads/2026/01/LogoHomeHeader.png" style="width: 180px;"
  alt="Aprobandome Logo"
  loading="lazy"
/>
</div>

	  <div id="chat-messages">
		<div class="assistant animate-in">
		  Hola 👋 ¿En qué puedo ayudarte?
		</div>
	  </div>

	  <div id="chat-input-area">
		<input type="text" id="chat-input" placeholder="Escribe un mensaje…">
		<button id="chat-send">➤</button>
	  </div>
	</div>

		<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>

		<?php
	$current_user = wp_get_current_user();
    $user_id = $current_user->ID;

	// OBTENER RESULTADOS DEL TEST
    $test_results = null;

	if ($user_id) {
        // Obtener las respuestas del test
        $question_test_ids = get_user_meta($user_id, 'question_test_ids', true);
        
        if ($question_test_ids) {
            $test_answers = json_decode(stripslashes($question_test_ids), true);
            
            if ($test_answers && is_array($test_answers)) {
                // Procesar los resultados
                $test_results = proccess_test_answers($test_answers);
            }
        }
    }
    
	$user_data = array(
		"id" => $current_user->ID,
		"username" => $current_user->user_login,
		"name" => $current_user->display_name,
		"email" => $current_user->user_email,
		"token" => wp_create_nonce('chat_token'),
		"result" =>  $test_results ? json_encode($test_results) : 'tesa', // <-- AQUI YA VA TODO

	);
	?>
	<script>
	window.CHAT_USER_DATA = <?php echo json_encode($user_data); ?>;
	</script>

	<script>
	(function(){
	  if (window._CHAT_ASISTENTE_INIT_) return;
	  window._CHAT_ASISTENTE_INIT_ = true;

	  const sendBtn = document.getElementById("chat-send");
	  const input = document.getElementById("chat-input");
	  const box = document.getElementById("chat-messages");

	  function scrollBottom(){ box.scrollTop = box.scrollHeight; }

	  function typing(show=true){
		if(show){
		  if(document.getElementById("typing")) return;
		  box.insertAdjacentHTML("beforeend", `
			<div id="typing" class="chat-message typing">
			  <div class="typing-dot"></div>
			  <div class="typing-dot"></div>
			  <div class="typing-dot"></div>
			</div>
		  `);
		}else{
		  const t = document.getElementById("typing");
		  if(t) t.remove();
		}
		scrollBottom();
	  }

	  function addMsg(type, html){
		const el = document.createElement("div");
		el.className = "chat-message " + type;
		el.innerHTML = html;
		box.appendChild(el);
		requestAnimationFrame(()=>el.classList.add("animate-in"));
		scrollBottom();
	  }

	  function getUserData() {
  const baseData = window.CHAT_USER_DATA || {};
  
  // 🔥 Parsear el result si es un string JSON
  let resultParsed = "";
  
  if (baseData.result && baseData.result !== "no-data") {
    try {
      // Si es un string JSON, parsearlo
    //   resultParsed = JSON.parse(baseData.result);
      const fullResult = JSON.parse(baseData.result);
      
      // Luego extraer solo result_type_value (que ya es un objeto)
      resultParsed = fullResult.result_type_value || "";
    } catch (e) {
      console.error("Error parseando result:", e);
      resultParsed = ""; // Dejar como está si falla
    }
  }
  
  return {
    id: baseData.id,
    username: baseData.username,
    name: baseData.name,
    email: baseData.email,
    token: baseData.token,
    result: resultParsed // 🔥 Ahora es un objeto JSON, no un string
  };
}

	  function send(){
		const msg = input.value.trim();
		if(!msg) return;
		addMsg("user", msg);
		input.value="";
		typing(true);

		fetch("https://webhook.efrenmartinezortiz-ia.com/webhook/41b322f8-0e0b-477d-b852-31410e8a9d6e/chat", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			message: msg,
			conversationId: localStorage.getItem("chat_conversation_id") || crypto.randomUUID(),
			timestamp: new Date().toISOString(),
			userAgent: navigator.userAgent,
			userData: getUserData() || {
			id: "",
			username: "",
			name: "",
			email: "",
			token: "",
			result: "", 
			},
			pageInfo: {
			url: window.location.href,
			pathname: window.location.pathname,
			title: document.title,
			referrer: document.referrer
			}
		})
		})
		.then(r => r.text())
		.then(t => {
		typing(false);
		let reply = t;
		try {
			const d = JSON.parse(t);
			reply = d.reply || d.message || t;
		} catch {}
		addMsg("assistant", marked.parse(reply));
		})
		.catch(() => {
		typing(false);
		addMsg("assistant","<span style='color:red'>Error de conexión</span>");
		});

	  }

	  sendBtn.addEventListener("click", send);
	  input.addEventListener("keydown",e=>{ if(e.key==="Enter") send(); });
	})();
	</script>
	<?php
	return ob_get_clean();
}
add_shortcode('asistente_virtual_chat','shortcode_asistente_virtual_chat');
