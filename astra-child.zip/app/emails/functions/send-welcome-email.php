<?php

/**
 * Función para enviar correos de pareja
 * 
 * coupleOneID -> ID de usuario de la pareja que compró el test
 * coupleTwoEmail -> Dirección de correo electrónico de la segunda pareja
 * 
 * @return void.
 */
function send_welcome_email($user_email) {
  // Establecemos el destinatario y el asunto
  $recipient = $user_email;
  $subject = __("¡Bienvenido a Aprobandome!");
  
  // Obtenemos el HTML correspondiente
  $message = get_sitemadi_welcome_email();

  // Enviar el correo
  return send_email($recipient, $subject, $message);
}
