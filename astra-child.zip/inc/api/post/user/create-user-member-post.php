<?php

add_action('rest_api_init', function () {
    register_rest_route('aprobandome/v1', '/create-user-member', [
        'methods'  => 'POST',
        'callback' => 'aprobandome_api_create_user_member',
        'permission_callback' => 'aprobandome_api_check_token_member',
    ]);
});

/**
 * Validación del token Bearer
 */
function aprobandome_api_check_token_member( WP_REST_Request $request ) {

    $auth_header = $request->get_header('authorization');

    if ( ! $auth_header || ! str_starts_with($auth_header, 'Bearer ') ) {
        return new WP_Error(
            'unauthorized',
            'Missing Authorization header',
            ['status' => 401]
        );
    }

    $token_received = trim(str_replace('Bearer', '', $auth_header));
    $valid_token    = get_option('aprobandome_create_user_member');

    if ( ! hash_equals($valid_token, $token_received) ) {
        return new WP_Error(
            'unauthorized',
            'Invalid API token',
            ['status' => 403]
        );
    }

    return true;
}

/**
 * Crear usuario vía API
 */
function aprobandome_api_create_user_member( WP_REST_Request $request ) {

    // ----------------------------------
    // 0. Payload
    // ----------------------------------
    $data = $request->get_json_params();

    if ( empty($data['user']) || empty($data['meta']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Invalid payload'
        ], 400);
    }

    // * wp_users.
    $user_data = $data['user'];
    // * wp_usermeta.
    $meta_data = $data['meta'];
    // * area Id y membresia.
    $membresia = $data['membresia'] ?? [];


    //1. Validaciones.
    if ( empty($user_data['user_email']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Missing user_email'
        ], 400);
    }

    if ( email_exists($user_data['user_email']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'User already exists'
        ], 409);
    }

    $random = wp_generate_password( 4, false, false );

    //2. Crear usuario
    $user_id = wp_insert_user([
        'user_login'    => (sanitize_user( $user_data['user_login'] ?? $user_data['user_email'], true )). '_' . strtolower($random),
        'user_pass'     => $user_data['user_pass'],
        'user_email'    => sanitize_email( $user_data['user_email'] ),
        'user_nicename' => sanitize_title(
            $user_data['user_nicename']
            ?? ($meta_data['first_name'] ?? '') . '-' . ($meta_data['last_name'] ?? '')
        ),
        'display_name'  => trim(
            ($meta_data['first_name'] ?? '') . ' ' . ($meta_data['last_name'] ?? '')
        ) ?: sanitize_email( $user_data['user_email'] ),
    ]);

    if ( is_wp_error($user_id) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $user_id->get_error_message()
        ], 500);
    }

   //3. Agregar metadatos
    foreach ( $meta_data as $key => $value ) {
        update_user_meta(
            $user_id,
            sanitize_key($key),
            is_string($value) ? sanitize_text_field($value) : $value
        );
    }

    //4. Asignar rol.
    wp_update_user([
        'ID'   => $user_id,
        'role' => 'subscriber'
    ]);

    // 5. Asignar membresia.
    assign_membership(
        $user_id, 
        $membresia['area_id'], 
        'ACTIVO', 
        $membresia['fecha_membresia']
    );

    // ----------------------------------
    // 6. Respuesta
    // ----------------------------------
    return new WP_REST_Response([
        'success'       => true,
        'user_id'       => $user_id
    ], 201);
}

function assign_membership($user_id, $area_id, $status, $fecha_final_membresia) {

    global $wpdb;
    $table = $wpdb->prefix . 'user_members';

    // Convertir fecha de YYYY-MM-DD a DD-MM-YYYY
    $fecha_formateada = '';

    if ( ! empty($fecha_final_membresia) ) {
        $date = DateTime::createFromFormat('Y-m-d', $fecha_final_membresia);
        if ( $date ) {
            $fecha_formateada = $date->format('d-m-Y');
        }
    }

    $wpdb->insert(
        $table,
        [
            'user_id'               => intval($user_id),
            'area_id'               => intval($area_id),
            'status'                => sanitize_text_field($status),
            'fecha_final_membresia' => $fecha_formateada
        ],
        [
            '%d',
            '%d',
            '%s',
            '%s'
        ]
    );
}




