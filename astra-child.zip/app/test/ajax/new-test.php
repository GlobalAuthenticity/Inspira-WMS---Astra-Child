<?php

if ( !function_exists('prepare_new_test') ){
    /**
     * @description
     * Prepara la base de datos para que el usuario pueda hacer un nuevo test
     */
    function prepare_new_test(){
        if (defined( 'DOING_AJAX' ) && DOING_AJAX) {            
            global $wpdb;

            // Verificar si hay un usuario logueado
            $test_type = "";
            $user_id = $_POST['user_id'];

            // Determinar el tipo de test y normalizar el valor
            switch ($_POST['test_type']) {
                case 'individual':
                    $test_type = 'personal';
                    break;
                
                case 'parejas':
                    $test_type = 'pareja';
                    break;
                
                default:
                    $test_type = 'padres';
                    break;
            }

            // Validar datos
            if (!$user_id || !$test_type) {
                send_json_response(false, 'error', 'Información incompleta.');
            } else {
                // Antes de continuar, si es un test de pareja validar que solo la pareja que compró el test pueda reiniciarlo
                $is_second_couple = UserQueries::user_is_second_couple($user_id);
                if (count($is_second_couple) > 0 && $test_type == 'pareja') {
                    send_json_response(false, 'error', 'Para reiniciar el test de pareja, debes pedirle a él/ella que lo reinicie.', ['pareja_2' => true]);
                    return;
                }

                /**
                 *  1. Buscamos en la tabla 'formularios_pagos' los registros de 
                 *  compra del usuario por tipo de test.
                 */
                $results = $wpdb->get_results("SELECT * FROM `formularios_pagos` WHERE user_id = {$user_id} AND tipo_resultado = '{$test_type}'");

                // Si el test es de pareja, obtenemos el id de la pareja también
                $second_couple_id = null;
                if ($test_type == 'pareja' && $results[0]->pago) {
                    $second_couple_id = $results[0]->pareja_id;
                }

                // Si el usuario ya ha comprado el tipo de test, eliminamos el registro de compra
                if ($results[0]->pago) {
                    $wpdb->delete(
                        'formularios_pagos', 
                        ['user_id' => $user_id, 'tipo_resultado' => $test_type],
                    );
                }

                // Si el tipo de test es de pareja...
                if ($second_couple_id) {
                    // Guardamos el id del usuario que ha iniciado el nuevo test, para verificar posteriormente si ya lo pagó o no
                    $couple_one_id = $user_id;

                    // Verificamos si la segunda pareja ya tiene la meta key 'couple_one_id'
                    $couple_one_id_meta = get_user_meta($second_couple_id, 'couple_one_id', true);

                    if (!$couple_one_id_meta) {
                        // Si no existe, la creamos
                        add_user_meta($second_couple_id, 'couple_one_id', $couple_one_id);
                    } else {
                        // Si ya existe, solo actualizamos su valor
                        update_user_meta($second_couple_id, 'couple_one_id', $couple_one_id);
                    }

                    // Verificamos si la segunda pareja ya tiene la meta key 'second_couple_pending_test'
                    $second_couple_pending_test = get_user_meta($second_couple_id, 'second_couple_pending_test', true);

                    if (!$second_couple_pending_test) {
                        // Si ya existe, solo actualizamos su valor a true
                        add_user_meta($second_couple_id, 'second_couple_pending_test', true);
                    }

                    // Borramos las respuestas del test de la pareja también
                    // update_user_meta($second_couple_id, 'question_test_ids', NULL);
                }

                // 3. Notificamos al front que la base de datos se ha preparado correctamente.
                send_json_response(true, 'success', 'Base de datos preparada correctamente.', []);
            }
        }
    }
}

// Ajax
add_action( 'wp_ajax_nopriv_prepare_new_test', 'prepare_new_test' );
add_action( 'wp_ajax_prepare_new_test', 'prepare_new_test' );