<?php 

class UserQueries {
  public function __construct() { }

  public static function user_bought_test($user_id, $test_type) {
    global $wpdb;
    return $wpdb->get_results("SELECT * FROM formularios_pagos WHERE user_id={$user_id} AND tipo_resultado = '{$test_type}' ORDER BY id DESC LIMIT 1");
  }

  public static function user_is_second_couple($user_id) {
    global $wpdb;
    return $wpdb->get_results("SELECT * FROM formularios_pagos WHERE pareja_id={$user_id} AND tipo_resultado = 'pareja' ORDER BY id DESC LIMIT 1");
  }

  public static function create_couple_match($couple_one_id, $couple_two_id) {
    global $wpdb;
    return $wpdb->update( 
      'formularios_pagos', 
      array( 
        'pareja_id' => $couple_two_id,
      ),
      array( 'user_id' => $couple_one_id )
    );
  }

  public static function user_completed_test($user_id) {
    // Obtener el valor del campo personalizado
    return get_user_meta($user_id, 'question_test_ids', true);
  }
}

new UserQueries();