jQuery(document).ready(function ($) {

    const pageTest = 'page-id-637';

    if ($('body').hasClass(pageTest)) {

        console.log('pasa por aca');

        const $submitBtn = $('.elementor-shortcode form button[type="submit"]');

        if (!$submitBtn.length) return;

        // Estilos base
        $submitBtn.css({
            backgroundColor: '#000',
            color: '#fff',
            borderRadius: '30px',
            padding: '14px 26px',
            border: 'none',
            cursor: 'pointer',
            transition: 'all .3s ease'
        });

        // Hover
        $submitBtn.on('mouseenter', function () {
            $(this).css('backgroundColor', '#8867B0');
        });

        $submitBtn.on('mouseleave', function () {
            $(this).css('backgroundColor', '#8867B0');
        });
    }
});
