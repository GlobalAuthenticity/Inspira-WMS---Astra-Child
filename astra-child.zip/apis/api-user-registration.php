<?php
/**
 * API: Crear usuario por correo
 */

add_action( 'rest_api_init', function () {

    register_rest_route( 'ms/v1', '/create-user', array(
        'methods'  => 'POST',
        'callback' => 'ms_api_create_user_by_email',
        'permission_callback' => 'api_create_user_check_token', // ⚠️ Ajustar si quieres seguridad
    ));

});

/**
 * Validación del token Bearer
 */
function api_create_user_check_token( WP_REST_Request $request ) {

    $auth_header = $request->get_header('authorization');

    if ( ! $auth_header || ! str_starts_with($auth_header, 'Bearer ') ) {
        return new WP_Error(
            'unauthorized',
            'Missing Authorization header',
            ['status' => 401]
        );
    }

    $token_received = trim(str_replace('Bearer', '', $auth_header));
    $valid_token    = get_option('aprobandome_create_user');

    if ( ! hash_equals($valid_token, $token_received) ) {
        return new WP_Error(
            'unauthorized',
            'Invalid API token',
            ['status' => 403]
        );
    }

    return true;
}


function ms_api_create_user_by_email( WP_REST_Request $request ) {

    // Obtener parámetro email
    $email = sanitize_email( $request->get_param('email') );

    if ( empty( $email ) ) {
        return array(
            'success' => false,
            'message' => 'El correo es obligatorio'
        );
    }

    // Validar formato
    if ( ! is_email( $email ) ) {
        return array(
            'success' => false,
            'message' => 'Correo inválido'
        );
    }

    // ✅ SI YA EXISTE → solo actualizar meta
    if ( email_exists( $email ) ) {

        $user = get_user_by( 'email', $email );

        if ( ! $user ) {
            return array(
                'success' => false,
                'message' => 'Error al obtener el usuario existente'
            );
        }

        // Guardar meta
        update_user_meta( $user->ID, 'external_procurement_origin', true );

        return array(
            'success'  => true,
            'message'  => 'Usuario existente actualizado correctamente',
            'email'    => $email,
            'user_id'  => $user->ID
        );
    }

    // Generar username desde email
    $username = sanitize_user( current( explode('@', $email ) ), true );

    // Evitar duplicados
    $base_username = $username;
    $i = 1;

    while ( username_exists( $username ) ) {
        $username = $base_username . $i;
        $i++;
    }

    // Generar contraseña random
    $password = wp_generate_password( 12, true, true );

    // Crear usuario
    $user_id = wp_create_user( $username, $password, $email );

    if ( is_wp_error( $user_id ) ) {

        return array(
            'success' => false,
            'message' => $user_id->get_error_message()
        );

    }

    // Asignar rol Suscriptor
    $user = new WP_User( $user_id );
    $user->set_role( 'subscriber' );

    // Guardar meta
    update_user_meta( $user_id, 'external_procurement_origin', true );

    // Respuesta exitosa
    return array(
        'success'  => true,
        'message'  => 'Usuario creado correctamente',
        'email'    => $email,
        'username' => $username,
        'password' => $password,
        'user_id'  => $user_id
    );
}

