<?php

/**
 * ======================================================
 * SHORTCODE: Cursos LearnDash asignados por categoría
 * ======================================================
 * Uso:
 * [ids-cursos-learndash category="amenazas" grid="3"]
 */
function ids_learndash_cursos($atts)
{
    global $wpdb;

    $user_id = get_current_user_id();

    if (!$user_id) {
        return '';
    }

    wp_enqueue_style(
        'idp-courses-styles',
        get_stylesheet_directory_uri() . '/components/shortcodes/idp-courses.css'
    );

    $atts = shortcode_atts([
        'category' => '',
        'grid'     => '3',
    ], $atts);

    // --------------------------------------------------
    // Cursos asignados al usuario
    // --------------------------------------------------
    $user_courses = learndash_get_user_course_access_list($user_id);

    if (empty($user_courses)) {
        return '';
    }

    // --------------------------------------------------
    // Query SOLO cursos asignados + categoría
    // --------------------------------------------------
    $query_args = [
        'post_type'          => 'sfwd-courses',
        'post_status'        => 'publish',
        'post__in'           => $user_courses,
        'ld_course_category' => $atts['category'],
        'nopaging'           => true,
    ];

    $query = new WP_Query($query_args);

    if (!$query->have_posts()) {
        return '';
    }

    ob_start();
    ?>

    <div class="ids__cursos" >
        <?php
        while ($query->have_posts()) :
            $query->the_post();

            $postID = get_the_ID();
            $postCategory = $query->query['ld_course_category'];
            $categoryModifier = '';

            switch ($postCategory) {
                case 'estrategias':
                    $categoryModifier = 'ids__cursos__item__category--estrategias';
                    break;
                case 'amenazas':
                    $categoryModifier = 'ids__cursos__item__category--amenazas';
                    break;
                case 'dolores':
                    $categoryModifier = 'ids__cursos__item__category--dolores';
                    break;
            }
        ?>  
            <a href="<?php the_permalink(); ?>"
                    class="ids__cursos__item__link"
                    data-category="<?php echo esc_attr($atts['category']); ?>">
            <div class="ids__cursos__item ids__cursos__item__comprado"
                 data-category="<?php echo esc_attr($atts['category']); ?>">

                <?php the_post_thumbnail(); ?>

                

                    <div class="ids__cursos__item__content">

                        <div class="ids__cursos__item__title">
                            <?php the_title(); ?>
                        </div>

                        <span class="ids__cursos__item__category <?php echo esc_attr($categoryModifier); ?>">
                         <?php echo esc_html($postCategory); ?>
                        </span>

                        <div>
                            <?php echo do_shortcode('[learndash_course_progress course_id="' . $postID . '"]'); ?>
                        </div>
                        
                        <span class="ids__cursos__item__button ids__cursos__item__button__ver" aria-hidden="true">
                            <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/06/arrow-right-line-svgrepo-com.svg" alt="">
                        </span>

                    </div>
                 </a>
                
            </div>

        <?php endwhile; ?>
    </div>

    <?php
    wp_reset_postdata();
    return ob_get_clean();
}

add_shortcode('ids-cursos-learndash', 'ids_learndash_cursos');


/**
 * ======================================================
 * REDIRECCIÓN AL FINALIZAR CURSO
 * ======================================================
 */
function learndash_course_redirect($link, $course_id)
{
    return get_site_url() . '/mi-cuenta/cursos/';
}
add_filter('learndash_course_completion_url', 'learndash_course_redirect', 5, 2);
