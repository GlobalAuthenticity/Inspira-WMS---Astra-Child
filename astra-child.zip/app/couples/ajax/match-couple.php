<?php

/**
 * @description
 * 
 * Valida la segunda pareja
 */
if (!function_exists('match_couple')) {
  function match_couple() {
    $couple_one_id = $_POST['coupleOneId'];
    $couple_two_id = $_POST['coupleTwoId'];

    $updated = UserQueries::create_couple_match($couple_one_id, $couple_two_id);

    if ($updated) {
      send_json_response(true, 'success', 'Match de parejas realizado correctamente.');
    } else {
      send_json_response(false, 'error', 'Error al hacer match de parejas. Por favor, intente nuevamente más tarde.');
    }
  }
}

// Ajax
add_action('wp_ajax_nopriv_match_couple', 'match_couple');
add_action('wp_ajax_match_couple', 'match_couple');