jQuery(document).ready(function ($) {



   let result = null;
   /* =====================================================
    * PÁGINAS
    * ===================================================== */
   const pageResultTestPersonal  = code_scripts.page_result_individual;
   const pageUsersBoughtResults = 'page-id-811';


   /* =====================================================
    * REGLAS DE EVALUACIÓN
    * ===================================================== */
   const rules = {

      // Dolores
      insuficiencia: {
         minimum: 2,
         medium: 6,
         maximum: 11,
      },

      rechazo: {
         minimum: 7,
         medium: 16,
         maximum: 23,
      },

      // Amenazas
      desaprobacion: {
         minimum: 14,
         medium: 25,
         maximum: 32,
      },

      // Estrategias
      obsesividad: {
         minimum: 1,
         medium: 3,
         maximum: 7,
      },

      dependencia: {
         minimum: 1,
         medium: 3,
         maximum: 5,
      },

      evitacion: {
         minimum: 5,
         medium: 10,
         maximum: 13,
      },
   };


   /* =====================================================
    * ESTADO INICIAL
    * ===================================================== */
   ocultarClasesResultados();
   ocultarAreasCompletas();


   /* =====================================================
    * GESTIÓN DE GRÁFICAS
    * ===================================================== */

   // Inserta el canvas y renderiza la gráfica
   function chatItemResult(label, data) {

      const containerSelector = `.ids-col-${label.label}`;
      const canvasClass       = `grafica-${label.label}`;

      $(containerSelector).html(`
         <canvas
            class="${canvasClass}"
            style="background-color: white; padding: 16px; border-radius: 8px;">
         </canvas>
      `);

      chartResult(label, data);
   }


   // Crea la gráfica radar
   /*function chartResult(label, data) {

      // Normalizar títulos
      switch (label.title) {
         case 'obsesividad':
            label.title = 'control obsesivo';
            break;

         case 'dependencia':
            label.title = 'búsqueda de aprobación';
            break;

         case 'evitacion':
            label.title = 'evitación social';
            break;
      }

      try {

         const selector = `.grafica-${label.label}`;
         if (!$(selector).length) return;

         new Chart(
            document.getElementsByClassName(`grafica-${label.label}`),
            {
               type: 'bar',

               data: {
                  labels: data.labels,
                  datasets: [{
                     label: label.title,
                     data: data.value,
                     fill: true,
                     backgroundColor: 'rgba(136, 103, 176, 0.2)',
                     borderColor: 'rgba(136, 103, 176, 1)',
                     pointBackgroundColor: 'rgba(66, 58, 89, 1)',
                     pointBorderColor: '#fff',
                     pointHoverBackgroundColor: '#fff',
                     pointHoverBorderColor: 'rgb(255, 99, 132)',
                  }],
               },

               options: {
                  elements: {
                     line: {
                        tension: 0,
                        borderWidth: 3,
                     },
                  },
                  scales: {
                     r: {
                        suggestedMin: 0,
                        suggestedMax: 5,
                        ticks: {
                           stepSize: 1,
                        },
                     },
                  },
               },
            }
         );

      } catch (error) {
         console.error(error);
      }
   }*/

  // nueva grafica barras 
  // Crea la gráfica de BARRAS
// Crea la gráfica de BARRAS (POLAR AREA)
// Crea la gráfica de BARRAS (POLAR AREA)

function capitalize(str) {
   if (!str) return '';
   return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

// O si quieres capitalizar cada palabra:
function capitalizeWords(str) {
   if (!str) return '';
   return str.split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
   ).join(' ');
}


function chartResult(label, data) {

   // ✅ MAPEO DE LABELS REALES por categoría
   const labelMappings = {
      'insuficiencia': [
         'Baja autoestima',
         'Autocrítica severa',
         'Miedo al fracaso'
      ],
      'rechazo': [
         'Miedo al abandono',
         'Hipersensibilidad',
         'Evitar conflictos',
         'Necesidad de aceptación',
         'Dificultad para expresar'
      ],
      'desaprobacion': [
         'Miedo al juicio',
         'Necesidad de validación',
         'Preocupación por opiniones',
         'Ansiedad social',
         'Autocrítica excesiva',
         'Miedo a decepcionar',
         'Perfeccionismo',
         'Dificultad para negarse'
      ],
      'obsesividad': [
         'Control obsesivo',
         'Rigidez mental'
      ],
      'dependencia': [
         'Búsqueda de aprobación',
         'Dependencia emocional'
      ],
      'evitacion': [
         'Aislamiento social',
         'Evitar situaciones',
         'Ansiedad en grupos'
      ]
   };

   // Normalizar títulos
   const originalTitle = label.title;
   // switch (label.title) {
   //    case 'obsesividad':
   //       label.title = 'control obsesivo';
   //       break;
   //    case 'dependencia':
   //       label.title = 'búsqueda de aprobación';
   //       break;
   //    case 'evitacion':
   //       label.title = 'evitación social';
   //       break;
   // }

switch (label.title.toLowerCase()) {
   case 'insuficiencia':
      label.title = capitalizeWords('insuficiencia');
      break;
   case 'rechazo':
      label.title = capitalizeWords('rechazo');
      break;
   case 'desaprobacion':
      label.title = capitalizeWords('desaprobación');
      break;
   case 'obsesividad':
      label.title = capitalizeWords('control obsesivo');
      break;
   case 'dependencia':
      label.title = capitalizeWords('búsqueda de aprobación');
      break;
   case 'evitacion':
      label.title = capitalizeWords('evitación social');
      break;
}


   try {

      const canvas = document.querySelector(`.grafica-${label.label}`);
      if (!canvas) {
         console.error('Canvas no encontrado:', `.grafica-${label.label}`);
         return;
      }

      // Verificar que data existe
      if (!data || !data.value) {
         console.error('Datos inválidos:', data);
         return;
      }

      // ✅ CONSTRUIR DATOS VÁLIDOS
      const filteredData = [];
      
      // Determinar qué labels usar
      let labelsToUse = [];
      
      // Si tiene labels en data y son válidos (no genéricos), usarlos
      if (data.labels && data.labels.length > 0) {
         labelsToUse = data.labels;
      } else {
         // Obtener el mapeo correcto para esta categoría
         const categoryKey = label.label.split('-')[0]; // 'insuficiencia-alto' -> 'insuficiencia'
         labelsToUse = labelMappings[categoryKey] || labelMappings[originalTitle] || [];
      }

      console.log('Categoría:', label.label);
      console.log('Labels a usar:', labelsToUse);
      console.log('Values recibidos:', data.value);

      // ✅ Crear pares label-value válidos
      for (let i = 0; i < data.value.length; i++) {
         const value = data.value[i];
         
         // Solo agregar si el valor es válido (> 0)
         if (value && value > 0) {
            const labelText = labelsToUse[i] || `Categoría ${i + 1}`;
            filteredData.push({
               label: labelText,
               value: Number(value)
            });
         }
      }

      console.log('Datos filtrados finales:', filteredData);

      // Si no hay datos válidos después de filtrar
      if (filteredData.length === 0) {
         canvas.parentElement.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">No hay datos disponibles</p>';
         return;
      }

      // Extraer labels y values finales
      const finalLabels = filteredData.map(item => item.label);
      const finalValues = filteredData.map(item => item.value);
      const n = finalLabels.length;

      console.log('=== CREANDO GRÁFICA ===');
      console.log('Título:', label.title);
      console.log('Labels finales:', finalLabels);
      console.log('Values finales:', finalValues);

      // Colores
      const allBackgroundColors = [
         "rgba(145, 145, 145, 0.5)",
         "rgba(174, 180, 193, 0.5)",
         "rgba(87, 123, 131, 0.5)",
         "rgba(202, 147, 152, 0.5)",
         "rgba(135, 120, 144, 0.5)",
         "rgba(72, 68, 103, 0.5)",
         "rgba(135, 68, 64, 0.5)",
         "rgba(233, 147, 193, 0.5)",
      ];

      const allBorderColors = [
         "rgba(145, 145, 145, 1)",
         "rgba(174, 180, 193, 1)",
         "rgba(87, 123, 131, 1)",
         "rgba(202, 147, 152, 1)",
         "rgba(135, 120, 144, 1)",
         "rgba(72, 68, 103, 1)",
         "rgba(135, 68, 64, 1)",
         "rgba(233, 147, 193, 1)",
      ];

      new Chart(canvas, {
         type: 'polarArea',

         data: {
            labels: finalLabels,
            datasets: [{
               label: label.title,
               data: finalValues,
               backgroundColor: allBackgroundColors.slice(0, n),
               borderColor: allBorderColors.slice(0, n),
               borderWidth: 2,
            }],
         },
         
         options: {
            responsive: true,
            maintainAspectRatio: false,
            devicePixelRatio: 3,

            plugins: {
               legend: { 
                  position: "top",
                  labels: {
                     padding: 15,
                     font: { size: 12 }
                  }
               },
               title: {
                  display: true,
                  text: label.title,
                  font: { size: 16, weight: 'bold' },
                  color: '#3d4451'
               },
               tooltip: {
                  enabled: true,
                  callbacks: {
                     label: function(context) {
                        let label = context.label || '';
                        if (label) {
                           label += ': ';
                        }
                        label += context.parsed.r.toFixed(1);
                        return label;
                     }
                  }
               }
            },

            scales: {
               r: {
                  beginAtZero: true,
                  suggestedMax: 5,
                  ticks: {
                     stepSize: 1,
                     backdropColor: 'transparent',
                     color: '#666',
                     font: { size: 11 }
                  },
                  pointLabels: {
                     display: true,
                     centerPointLabels: true,
                     font: { size: 13 },
                     color: '#4B4467'
                  },
                  grid: {
                     color: 'rgba(0, 0, 0, 0.1)'
                  }
               }
            },
         },
      });

      console.log('✅ Gráfica creada exitosamente');

   } catch (error) {
      console.error('❌ Error al crear gráfica:', error);
      console.error('Stack:', error.stack);
   }
}


   /* =====================================================
    * AJAX RESULTADOS
    * ===================================================== */
   if ($('body').hasClass(pageUsersBoughtResults)) {

      // Modal de carga
      $('#customModalWaiting .modal-waiting-text')
         .html('Estamos cargando tus resultados.');

      $('#customModalWaiting')
         .css('display', 'flex')
         .hide()
         .fadeIn(300);

      const data = {
         action: 'get_test_results',
         // user_id: 13103,
      };

      $.ajax({
         url: code_scripts.ajaxurl,
         type: 'POST',
         dataType: 'json',
         data,

         success(response) {

            if (!response.success) return;

            // Guardar resultados
            localStorage.removeItem('resultado');
            localStorage.setItem('resultado', JSON.stringify(response.data));

            // Nombre del usuario
            $('.ids-name-test').html(response.data.name);

            // Resultado general
            const generalResult = {
               labels: ['Amenazas', 'Dolores', 'Estrategias'],
               value: [
                  response.data.results_promedio.amenazas_prom,
                  response.data.results_promedio.dolores_prom,
                  response.data.results_promedio.estrategias_prom,
               ],
            };

            chatItemResult(
               { title: 'General', label: 'test-general' },
               generalResult
            );

            evaluarNivelPorRules(rules, response.data);

            inicializarEscalas();
         },

         error(error) {
            console.error('Error en AJAX:', error);
         },

         complete() {
            $('#customModalWaiting').fadeOut(300, function () {
               $(this).css('display', 'none');
            });
         },
      });
   }

   /* =====================================================
    * EVALUACIÓN DE RESULTADOS
    * ===================================================== */
   function evaluarNivelPorRules(rules, result) {

      const questionMap = Object.fromEntries(
         result.results.map(({ question, answer }) => [question, answer])
      );

      const [q13, q16, q17, q18] = [13, 16, 17, 18].map(q => questionMap[q]);

      let course_codes = [];

      const resultsType   = result.results_type;
      const resultsValues = result.result_type_value;

      Object.keys(rules).forEach(key => {

         const puntaje = resultsType[key];
         if (puntaje === undefined) return;

         const { minimum, medium, maximum } = rules[key];

         // Nivel bajo
         if (puntaje <= minimum) {

            mostrarElemento('#tittle-area-bajo');
            mostrarElemento('#tittle-area-bajo2');
            mostrarElemento('#tittle-area-bajo3');

            mostrarElemento(`#${key}-bajo`);
            mostrarElemento(`.${key}-bajo`);

            chatItemResult(
               { title: key, label: `${key}-bajo` },
               resultsValues[key]
            );

            return;
         }

         // Nivel medio
         if (puntaje <= medium) {

            mostrarElemento('#tittle-area-medio');
            mostrarElemento('#tittle-area-medio2');
            mostrarElemento('#tittle-area-medio3');

            mostrarElemento(`#${key}-medio`);
            mostrarElemento(`.${key}-medio`);

            switch (key) {
               case 'desaprobacion': course_codes.push(1526); break;
               case 'insuficiencia': course_codes.push(1604); break;
               case 'rechazo':
                  course_codes.push(1593);
                  if ([0,1].includes(q13)) removerElementosPorClase('question-13');
                  if ([0,1].includes(q16)) removerElementosPorClase('question-16');
                  break;
               case 'obsesividad':
                  course_codes.push(1471);
                  if ([0,1].includes(q17)) removerElementosPorClase('question-17');
                  if ([0,1].includes(q18)) removerElementosPorClase('question-18');
                  break;
               case 'dependencia': course_codes.push(1443); break;
               case 'evitacion': course_codes.push(1429); break;
            }

            chatItemResult(
               { title: key, label: `${key}-medio` },
               resultsValues[key]
            );

            return;
         }

         // Nivel alto
         if (puntaje > medium || puntaje >= maximum) {

            mostrarElemento('#tittle-area-alto');
            mostrarElemento('#tittle-area-alto2');
            mostrarElemento('#tittle-area-alto3');

            mostrarElemento(`#${key}-alto`);
            mostrarElemento(`.${key}-alto`);

            switch (key) {
               case 'desaprobacion': course_codes.push(1526); break;
               case 'insuficiencia': course_codes.push(1604); break;
               case 'rechazo':
                  course_codes.push(1593);
                  if ([0,1].includes(q13)) removerElementosPorClase('question-13');
                  if ([0,1].includes(q16)) removerElementosPorClase('question-16');
                  break;
               case 'obsesividad':
                  course_codes.push(1471);
                  if ([0,1].includes(q17)) removerElementosPorClase('question-17');
                  if ([0,1].includes(q18)) removerElementosPorClase('question-18');
                  break;
               case 'dependencia': course_codes.push(1443); break;
               case 'evitacion': course_codes.push(1429); break;
            }
            chatItemResult(
               { title: key, label: `${key}-alto` },
               resultsValues[key]
            );
         }
      });
   }


   /* =====================================================
    * UTILIDADES DOM
    * ===================================================== */

   function removerElementosPorClase(className) {
      if (!className) return;

      const cleanClass = className.startsWith('.')
         ? className.slice(1)
         : className;

      document
         .querySelectorAll(`.${cleanClass}`)
         .forEach(el => el.remove());
   }


   function ocultarClasesResultados() {

      const clases = [
         'insuficiencia-alto','insuficiencia-medio',
         'rechazo-alto','rechazo-medio',
         'desaprobacion-alto','desaprobacion-medio',
         'obsesividad-alto','obsesividad-medio',
         'dependencia-alto','dependencia-medio',
         'evitacion-alto','evitacion-medio',
      ];

      clases.forEach(c =>
         document.querySelectorAll(`.${c}`).forEach(el => el.style.display = 'none')
      );
   }


   function ocultarAreasCompletas() {

      ['.areas-alto-container','.areas-medio-container','.areas-bajo-container']
         .forEach(s =>
            document.querySelectorAll(s).forEach(el => el.style.display = 'none')
         );

      [
         '#tittle-area-alto','#tittle-area-medio','#tittle-area-bajo',
         '#tittle-area-alto2','#tittle-area-medio2','#tittle-area-bajo2',
         '#tittle-area-alto3','#tittle-area-medio3','#tittle-area-bajo3',
         '#desaprobacion-alto','#insuficiencia-alto','#rechazo-alto',
         '#obsesividad-alto','#dependencia-alto','#evitacion-alto',
         '#insuficiencia-medio','#rechazo-medio','#obsesividad-medio',
         '#dependencia-medio','#evitacion-medio',
         '#desaprobacion-bajo','#insuficiencia-bajo','#rechazo-bajo',
         '#obsesividad-bajo','#dependencia-bajo','#evitacion-bajo',
      ].forEach(id => {
         const el = document.querySelector(id);
         if (el) el.style.display = 'none';
      });
   }


   function mostrarElemento(selector) {

      document.querySelectorAll(selector).forEach(el => {
         el.style.display = '';
         el.style.visibility = 'visible';
         el.style.opacity = '1';

         let parent = el.parentElement;
         while (parent) {
            if (parent.style?.display === 'none') {
               parent.style.display = '';
            }
            parent = parent.parentElement;
         }
      });
   }

});

/* Semaforo */

// ============================================
// ESCALAS SEGMENTADAS
// ============================================

// ✅ CAMBIO: Usar window.result o solo result (ya está en el scope)
function calcularPosicionDesaprobacion() {
    try {
        const data = window.result || JSON.parse(localStorage.getItem('resultado'));
        if (!data || !data.result_type_value) return 50;
        
        // ✅ CAMBIO: result_type_value en lugar de results_type
        if (data.result_type_value.desaprobacion.is_alto) return 83;
        if (data.result_type_value.desaprobacion.is_medio) return 50;
        return 17;
    } catch(e) {
        console.error('Error en calcularPosicionDesaprobacion:', e);
        return 50;
    }
}

function calcularPosicionRechazo() {
    try {
        const data = window.result || JSON.parse(localStorage.getItem('resultado'));
        if (!data || !data.result_type_value) return 50;
        
        // ✅ CAMBIO: result_type_value
        if (data.result_type_value.rechazo.is_alto) return 75;
        if (data.result_type_value.rechazo.is_medio) return 58;
        return 23;
    } catch(e) {
        return 50;
    }
}

function calcularPosicionInsuficiencia() {
    try {
        const data = window.result || JSON.parse(localStorage.getItem('resultado'));
        if (!data || !data.result_type_value) return 50;
        
        // ✅ CAMBIO: result_type_value
        if (data.result_type_value.insuficiencia.is_alto) return 83;
        if (data.result_type_value.insuficiencia.is_medio) return 50;
        return 17;
    } catch(e) {
        return 50;
    }
}

function calcularPosicionObsesividad() {
    try {
        const data = window.result || JSON.parse(localStorage.getItem('resultado'));
        if (!data || !data.result_type_value) return 50;
        
        // ✅ CAMBIO: result_type_value
        if (data.result_type_value.obsesividad.is_alto) return 75;
        if (data.result_type_value.obsesividad.is_medio) return 58;
        return 23;
    } catch(e) {
        return 50;
    }
}

function calcularPosicionDependencia() {
    try {
        const data = window.result || JSON.parse(localStorage.getItem('resultado'));
        if (!data || !data.result_type_value) return 50;
        
        // ✅ CAMBIO: result_type_value
        if (data.result_type_value.dependencia.is_alto) return 90;
        if (data.result_type_value.dependencia.is_medio) return 50;
        return 17;
    } catch(e) {
        return 50;
    }
}

function calcularPosicionEvitacion() {
    try {
        const data = window.result || JSON.parse(localStorage.getItem('resultado'));
        if (!data || !data.result_type_value) return 50;
        
        // ✅ CAMBIO: result_type_value
        if (data.result_type_value.evitacion.is_alto) return 83;
        if (data.result_type_value.evitacion.is_medio) return 40;
        return 10;
    } catch(e) {
        return 50;
    }
}


function crearEscalaSegmentada(containerId, titulo, marcadores, leyendas) {
    const colores = {
        segmento1: '#577B83',
        segmento2: '#D4C896',
        segmento3: '#C29398'
    };
    
    const viewBoxWidth = 1100;
    const barWidth = 1040;
    const segmentWidth = barWidth / 3;
    const startX = 30;
    
    const container = document.getElementById(containerId);
    if (!container) {
        console.warn('Container no encontrado:', containerId);
        return;
    }
    
    const svg = `
        <div style="margin-bottom: 60px; width: 100%; max-width: 100%; overflow: hidden;">
            <h3 style="color: #3d4451; font-size: 20px; margin-bottom: 20px; font-weight: 600;">${titulo}</h3>
            
            <svg width="100%" viewBox="0 0 ${viewBoxWidth} 100" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
                <rect x="${startX}" y="40" width="${segmentWidth}" height="35" fill="${colores.segmento1}" rx="8" ry="8"/>
                <rect x="${startX + segmentWidth}" y="40" width="${segmentWidth}" height="35" fill="${colores.segmento2}"/>
                <rect x="${startX + segmentWidth * 2}" y="40" width="${segmentWidth}" height="35" fill="${colores.segmento3}" rx="8" ry="8"/>
                
                ${marcadores.map(m => {
                    const x = startX + (m.posicion * barWidth / 100);
                    return `
                        <g>
                            <path d="M ${x},35 L ${x-12},10 L ${x+12},10 Z" fill="${m.color}" stroke="white" stroke-width="2"/>
                        </g>
                    `;
                }).join('')}
            </svg>
            
            <div style="display: flex; gap: 20px; margin-top: 20px; flex-wrap: wrap; padding: 0 5px;">
                ${leyendas.map(l => `
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="width: 16px; height: 16px; background: ${l.color}; border-radius: 3px; flex-shrink: 0;"></div>
                        <span style="font-size: 13px; color: #5a5f6b;">${l.texto}</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    container.innerHTML = svg;
}

function inicializarEscalas() {

    const data = window.result || JSON.parse(localStorage.getItem('resultado'));
    
    // ✅ CAMBIO: Verificar result_type_value
    if (!data || !data.result_type_value) {
        console.error('No se encontraron datos de resultados');
        return;
    }
    
    // Asignar temporalmente para que las funciones lo usen
    window.result = data;
    
    // ESTRATEGIAS
    crearEscalaSegmentada('escala-estrategias', 'Estrategias', 
        [
            { posicion: calcularPosicionEvitacion(), color: '#C29398' },
            { posicion: calcularPosicionObsesividad(), color: '#877890' },
            { posicion: calcularPosicionDependencia(), color: '#3d4451' }
        ],
        [
            { color: '#3d4451', texto: 'Dependencia y búsqueda de aprobación' },
            { color: '#877890', texto: 'Control obsesivo' },
            { color: '#C29398', texto: 'Evitación social' }
        ]
    );
    
    // AMENAZAS
    crearEscalaSegmentada('escala-amenazas', 'Amenazas',
        [{ posicion: calcularPosicionDesaprobacion(), color: '#8B9CAB' }],
        [{ color: '#8B9CAB', texto: 'Desaprobación' }]
    );
    
    // DOLORES
    crearEscalaSegmentada('escala-dolores', 'Dolores',
        [
            { posicion: calcularPosicionRechazo(), color: '#3d4451' },
            { posicion: calcularPosicionInsuficiencia(), color: '#877890' }
        ],
        [
            { color: '#3d4451', texto: 'Herida del rechazo' },
            { color: '#877890', texto: 'Herida de la insuficiencia' }
        ]
    );
}

// ✅ CAMBIO: Intentar cargar desde localStorage al inicio
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        // Solo ejecutar si hay datos en localStorage
        if (localStorage.getItem('resultado')) {
            inicializarEscalas();
        }
    });
} else {
    if (localStorage.getItem('resultado')) {
        inicializarEscalas();
    }
}
