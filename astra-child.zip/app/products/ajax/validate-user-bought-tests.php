<?php 

/**
 * @description
 * Función para recuperar todos los test que ha comprado el usuario.
 * 
 */
function validate_user_bought_tests() {
  if (defined('DOING_AJAX') && DOING_AJAX) {
    $user_id = get_current_user_id();

    $test_type_personal = AppConstants::TEST_TYPE_PERSONAL;
   

    $exist_test_personal = UserQueries::user_bought_test($user_id, $test_type_personal);  

    $data = [
      'result_individual' => $exist_test_personal[0]->pago ? 1 : 0,
    ];

    send_json_response(true, 'success', 'Test comprados obtenidos correctamente', $data);
  }
}

add_action( 'wp_ajax_validate_user_bought_tests', 'validate_user_bought_tests' );
add_action( 'wp_ajax_nopriv_validate_user_bought_tests', 'validate_user_bought_tests' );
