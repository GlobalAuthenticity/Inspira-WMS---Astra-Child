<?php

function bar_test_steps() {
    wp_enqueue_style( 'content-table-styles', get_stylesheet_directory_uri() . '/components/shortcodes/bar_test_steps.css' );
    $current_url = $_SERVER['REQUEST_URI'];

    // Estados por defecto
    $step_register = 'active';
    $step_test     = '';
    $step_pay      = '';
    $step_results  = '';

    $test_text = 'Realiza tu evaluación de dependencia';

    // Página del test individual
    if (strpos($current_url, '/test/') !== false && strpos($current_url, 'test-type=individual') !== false) {
        $step_register = 'active';
        $step_test     = '';
    }

    // Checkout
    if (strpos($current_url, '/finalizar-compra/') !== false) {
        $step_register = 'completed';
        $step_test     = 'completed';
        $step_pay      = 'active';
        $test_text     = 'Realiza tu evaluación de dependencia';
    }

    ob_start(); ?>
    
    <div class="apro-steps">

    <div class="apro-step <?php echo esc_attr($step_register); ?>">
        <img class="icon-img" src="http://aprobandome.com/wp-content/uploads/2026/01/CheckStepsResultados.png" alt="">
        <span class="text">Regístrate y crea<br>tu cuenta</span>
    </div>

    <div class="apro-step <?php echo esc_attr($step_test); ?>">
        <img class="icon-img" src="http://aprobandome.com/wp-content/uploads/2026/01/CheckStepsResultados.png" alt="">
        <span class="text"><?php echo esc_html($test_text); ?></span>
    </div>

    <div class="apro-step <?php echo esc_attr($step_results); ?>">
        <img class="icon-img" src="http://aprobandome.com/wp-content/uploads/2026/01/TimeStepsResultados.png" alt="">
        <span class="text">Descarga tus resultados y comienza tu programa</span>
    </div>

</div>




    <?php
    return ob_get_clean();
}
add_shortcode('apro_test_steps', 'bar_test_steps');

