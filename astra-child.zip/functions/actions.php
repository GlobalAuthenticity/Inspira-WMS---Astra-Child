<?php

function sistemadi_change_registration_url($user_id) {
  $couple;
  $test_type = "individual";

  if (isset($_GET['test-type'])) {
    $test_type = $_GET['test-type'];
  }

  if (isset($_GET['pareja2'])) {
    $couple = $_GET['pareja2'];
  }

  wp_set_current_user($user_id);
  wp_set_auth_cookie($user_id);

  if ($couple == 'true') {
    wp_redirect(get_site_url() . '/verificacion-pareja/');
  } else {
    wp_redirect(get_site_url() . '/test/?test-type=' . $test_type);
  }

  exit;
}
add_action('um_registration_complete', 'sistemadi_change_registration_url', 10, 2);

function load_custom_shortcodes() {
  $shortcode_files = glob(get_stylesheet_directory() . '/components/shortcodes/*.php');
  if ($shortcode_files) {
    foreach ($shortcode_files as $file) {
      require_once $file;
    }
  }
}
add_action('init', 'load_custom_shortcodes');

function load_custom_modals() {
  $modals_files = glob(get_stylesheet_directory() . '/components/modals/*.php');
  if ($modals_files) {
    foreach ($modals_files as $file) {
      require_once $file;
    }
  }
}
add_action('init', 'load_custom_modals');

function clean_cart_and_add_product() {
  if (isset($_GET['previous']) && $_GET['previous'] == 'true') {
    return;
  }
  if (
    isset($_GET['add-to-cart']) && 
    in_array($_GET['add-to-cart'], AppConstants::TESTS_PRODUCTS_IDS)
  ) {
    $product_id = $_GET['add-to-cart'];
    WC()->cart->empty_cart();
    wp_redirect(AppConstants::urlComprarTestById($product_id).'&previous=true');
    exit;
  }
}
add_action('template_redirect', 'clean_cart_and_add_product');

function verify_user_test_completion() {
  // FIX: Evitar loop — si la URL ya tiene redirect_to anidado, no hacer nada
  if ( isset($_GET['redirect_to']) ) {
    return;
  }

  $user_id = get_current_user_id();

  if (
    UserQueries::user_completed_test($user_id) && 
    str_contains($_SERVER['REQUEST_URI'], '/registro/')
  ) {
    $product_id = 0;

    if (isset($_GET['test-type'])) {
      $test_type = $_GET['test-type'];
      $test_type = $_GET['test-type'] == 'individual' ? 'personal' : $_GET['test-type'];
      $exist = UserQueries::user_bought_test($user_id, AppConstants::TESTS_PRODUCTS_IDS[$test_type]);

      if (
        in_array($test_type, AppConstants::TESTS_TYPES) && 
        !$exist[0]->pago
      ) {
        $product_id = AppConstants::TESTS_PRODUCTS_IDS[$test_type];
        wp_redirect(AppConstants::urlComprarTestById($product_id));
      } else {
        wp_redirect(get_site_url() . '/mi-cuenta/panel-usuario');
      }

      exit;
    }
  } 
}
add_action('template_redirect', 'verify_user_test_completion');

function add_custom_price_course( $cart ) {
  foreach ( $cart->cart_contents as $key => $value ) {
    // FIX: verificar que el índice 'price' exista antes de usarlo
    if( isset($value['price']) && $value['price'] ) {
      $value['data']->set_price($value['price']);
    }
  }
}
add_action( 'woocommerce_before_calculate_totals', 'add_custom_price_course', 20, 1 );