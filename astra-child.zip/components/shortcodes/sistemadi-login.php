<?php

function sistemadi_login_function($atts) {
    if(!is_admin()) {
      wp_enqueue_style( 'auth-styles', get_stylesheet_directory_uri() . '/components/shortcodes/login-signup.css' );

      ob_start();
      ?>
        <div>
            <form class="sistemadi-auth-form" id="sistemadi-login-form">
                <div id="sistemadi-error-messages"></div>
                <div class="sistemadi-form-group">
                    <label for="sistemadi-email">Correo electrónico</label>
                    <input type="text" id="sistemadi-email" name="sistemadi-email" required>
                </div>
                <div class="sistemadi-form-group">
                    <label for="sistemadi-password">Contraseña</label>
                    <input type="password" id="sistemadi-password" name="sistemadi-password" required>
                    <button class="sistemadi-password-toggle" type="button">
                        <img src="<?php print get_site_url() . '/wp-content/uploads/2026/01/Eye.svg'; ?>">
                    </button>
                </div>
                <button type="submit" class="sistemadi-submit-button">Iniciar sesión</button>
            </form>
        </div>
      <?php
      return ob_get_clean();
    }
}
add_shortcode('sistemadi_login', 'sistemadi_login_function');
