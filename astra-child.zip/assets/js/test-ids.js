jQuery(document).ready(function($) {
  const url = new URL($(location).attr('href'));
  const pageTest = 'page-id-637';
	const testType = url.searchParams.get('test-type');
	const isCoupleTwo = url.searchParams.get('pareja2') === 'true' ? true : false;

	// TODO: Globalizar los productos para obtener su precio desde el backend
  const testTypesInfo = {
    individual: {
      img: `${code_scripts['get_site_url']}/wp-content/uploads/2025/03/test-personal-cabecera.webp`,
      titleEl: `
          Test 
          <span style="color: #F45C62"><i>personal</i></span>
      `,
      price: 89,
      descriptionEl: `
        Este test te ayudará a identificar tus fortalezas y áreas de mejora personales. Con los resultados, podrás desarrollar una mejor comprensión de ti mismo y tomar decisiones más conscientes para tu crecimiento y bienestar.
        <br>
        <br>
        A continuación, te presentamos una serie de afirmaciones sobre la personalidad y cómo afrontamos diferentes situaciones. Responde en una escala del 0 al 5, donde 0 significa "muy en desacuerdo" y 5, "muy de acuerdo".
        <br>
        <br>
        Tu honestidad es clave para obtener resultados precisos.
      `
    },
		padres: {
			img: `${code_scripts['get_site_url']}/wp-content/uploads/2025/02/Sistemadi-padres.webp`,
      titleEl: `
          Test para 
          <span style="color: #F45C62"><i>padres</i></span>
      `,
      price: 57,
      descriptionEl: `
        Este test te permitirá descubrir tus fortalezas y áreas de mejora como padre/madre. Con los resultados, podrás fomentar una mejor comunicación y construir relaciones familiares más fuertes y conscientes.
        <br>
        <br>
        A continuación, te presentamos una serie de afirmaciones sobre la personalidad y cómo afrontamos diferentes situaciones. Responde en una escala del 0 al 5, donde 0 significa "muy en desacuerdo" y 5, "muy de acuerdo".
        <br>
        <br>
        Tu honestidad es clave para obtener resultados precisos.
      `
		},
		parejas: {
			img: `${code_scripts['get_site_url']}/wp-content/uploads/2025/06/test-pareja-cabecera.webp`,
      titleEl: `
          Test de 
          <span style="color: #F45C62"><i>pareja</i></span>
      `,
      price: 148,
      descriptionEl: `
        Este test te ayudará a conocerte mejor a ti y a tu pareja, identificando fortalezas y áreas a mejorar. Con los resultados, podrán comunicarse mejor, resolver problemas juntos y fortalecer su relación de forma consciente.
        <br>
        <br>
        A continuación, te presentamos una serie de afirmaciones sobre la personalidad y cómo afrontamos diferentes situaciones. Responde en una escala del 0 al 5, donde 0 significa "muy en desacuerdo" y 5, "muy de acuerdo".
        <br>
        <br>
        Tu honestidad es clave para obtener resultados precisos.
      `
		}
  };
  
	/**
	 * @description
	 * Cambia la imagen, título, precio y descripción en la página del test,
	 * según el tipo de test.
	 */
  if ($('body').hasClass(pageTest)) {
    const testInfo = testTypesInfo[testType];
		console.log(testType)

    // Cambiar la imagen del tipo de test
    const testTypeImg = $('#test-type-img img');
    testTypeImg.attr('src', testInfo.img);
    testTypeImg.attr('alt', `Imagen de cabecera del test ${testType}`);

    // Cambiar el título del tipo de test
    const testTypeTitle = $('#test-type-title h2');
    testTypeTitle.html(testInfo.titleEl);

    // Cambiar el precio del tipo de test
    const testTypePrice = $('#test-type-price span');
    testTypePrice.html(`$${testInfo.price} USD`);

    // Cambiar la descripción del test
    const testTypeDescription = $('#test-type-description p');
    testTypeDescription.html(testInfo.descriptionEl);

		// Cambiar el texto del botón de ver resultados
		const viewResultsBtn = $('#action-button.watupro-submit-button');
		viewResultsBtn.attr('value', 'Ver resultados');
  }

	/**
	 * @description
	 * Procesa las respuestas del formulario del test y las guarda en localstorage.
	 */
	function processResponseQuiz(){
		let answerArray = [];
		const quiz = $(".quiz-form").serializeArray();

		const questions = quiz.find(element => element.name == 'watupro_questions');
		if(questions && questions.value){
			const questionIndividual = questions.value.split(' | ');

			for (let question of questionIndividual) {
				const questionAnswers = question.split(':');
				const numberQuestion = questionAnswers[0];
				const answersCommas = questionAnswers[1];
				const answers = answersCommas.split(',');
				const answerExactly = quiz.find(element => element.name == `answer-${numberQuestion}[]`);

				if (answerExactly) {
					const savedAnswer = answers.findIndex(element => element == answerExactly.value);
					answerArray = [
						...answerArray,
						{
							question: numberQuestion,
							answer: savedAnswer,
							value: answerExactly.value
						}
					];
				}
			}
		}

		localStorage.setItem('quiz-1', JSON.stringify(answerArray));
		return answerArray;
	}

	/**
	 * @description
	 * Remueve el click en el evento continuar del formulario del test.
	 */
	$('.form-test-questions #watuproNextCatButton input').removeAttr('onclick');
	$('.form-test-questions #watuproPrevCatButton input').removeAttr('onclick');

	/**
	 * @description
	 * Manejo de errores de las preguntas del formulario.
	 */
	function manejoErroresQuestions(){
		$(".watupro_catpage").append('<div class="error-form js-error-questions js-error-questions-global" style="text-align: center; margin-top: 20px;">Debe responder todas las preguntas para continuar.</div>');
		const quiz = $(".quiz-form").serializeArray();
		const questions = quiz.find(element => element.name == 'watupro_questions');

		if (questions && questions.value) {
			const questionIndividual = questions.value.split(' | ');

			for (let question of questionIndividual) {
				const questionAnswers = question.split(':');
				const numberQuestion = questionAnswers[0];
				const answerExactly = quiz.find(element => element.name == `answer-${numberQuestion}[]`);

				if (!answerExactly) {
					$(`#question-${numberQuestion}`).append('<div class="error-form js-error-questions">La pregunta es obligatoria.</div>');
				}
			}
		}
	}

	/**
	 * @description
	 * Click en el evento continuar del formulario.
	 */
	$(document).on('click', '.form-test-questions #watuproNextCatButton input', function () {
		navigateTestForm(true);
	});

	/**
	 * @description
	 * Click en el evento anterior del formulario.
	 */
	$(document).on('click', '.form-test-questions #watuproPrevCatButton', function () {
		navigateTestForm(false);
	});

		/**
	 * @description
	 * Click en el evento siguiente/anterior del formulario.
	 * @param {boolean} next -> true: siguiente, false: anterior
	 */
	function navigateTestForm(next) {
		$(".js-error-questions").remove();
		$('.watupro_catpage:visible').find('input').prop('required', next);

		if ($('.quiz-form')[0].checkValidity()) {
			showSectionRegister();
			processResponseQuiz();

			WatuPRO.nextCategory(3, next);
		} else {
			manejoErroresQuestions();
			$(".quiz-form")[0].reportValidity();
		}
	} 

	/**
	 * @description
	 * Cuando escoge una opción de respuesta elimina los errores si tiene.
	 */
	$('input[type=radio]').change(function() {
		$(this).closest('.watu-question').find('.js-error-questions').remove();
		$(".js-error-questions-global").remove();
	});
	$('.form-test-questions .watupro-submit-button').removeAttr('onclick');

	/**
	 * @description
	 * Procesar todas las respuestas para guardarlas, revisar que todas las preguntas se hayan contestado.
	 * Si responde bien, lo redirecciona a la página de compra del test.
	 */
	let confirmResponseTest = false;
	$(document).on('click', '.form-test-questions .watupro-submit-button', function () {
		$(".js-error-questions").remove();
		$('.watupro_catpage:visible').find('input').prop('required',true);

		if ($('.quiz-form')[0].checkValidity()) {
			$('.loading-submit-test').show();
			processResponseQuiz();

			const data = {};
			const quiz = localStorage.getItem('quiz-1');

			data['answers'] = quiz;
			data['action'] = 'save_test_answers';

			$.ajax({
				url: code_scripts.ajaxurl,
				type: 'post',
				dataType: "json",
				data,
				success: function (response) {
					$('.loading-submit-test').hide();

					if (response['success'] && testType === 'individual') {
						$(location).prop('href', `${code_scripts.get_site_url}/mi-cuenta/resultados`);
					} else {
						$(location).prop('href', `${code_scripts.get_site_url}/mi-cuenta/panel-usuario`);
					}
					
				},
				error: function (error) {
					$('.loading-submit-test').hide();
				}
			})
		} else {
			$(".quiz-form")[0].reportValidity();
		}
	});

	/**
	 * @description
	 * Carga las respuestas del localstorage y llena el formulario.
	 */
	function loadAnswerQuiz(){
		if ($('body').hasClass(pageTest)) {
			const quiz = localStorage.getItem('quiz-1');

			if (quiz) {
				const quizArray = JSON.parse(quiz);
				if (quizArray && $(".quiz-form").length) {
					quizArray.forEach(answer => {
						document.getElementById(`answer-id-${answer.value}`).checked = true;
					});
				}
			}
		}
	}
	loadAnswerQuiz();

	/**
	 * @description
	 * Función para determinar el paso activo y mostrar la sección de registro para el usuario.
	 */
	function showSectionRegister() {
		$('.quiz-form .watupro_catpage').each(function () {
			if ($(this).css("display") == "block") {
				const idElement = $(this).attr('id');
				const stepForm = Number(idElement.replace('catDiv', ''));
				if (stepForm > 1) {
					isLogged().then(idUser => {
						if (!idUser) {
							$(".class-not-register").show();
						}else{
							$(".class-not-register").hide();
						}
					});
				}
			}
		});
	}

	/**
	 * @description
	 * Función para revisar si el usuario está logueado o no, devuelve el id del usuario.
	 * @returns {number}
	 */
  function isLogged() {
    return new Promise((resolve) => {
      $.ajax({
        url: code_scripts.ajaxurl,
        type: 'post',
        dataType: "json",
        data: {
          action: 'is_user_logged_in'
        },
        success: function (response) {
          resolve(response)
        },
        error: function (error) {
          resolve(0);
        }
      })
    });
  }
});