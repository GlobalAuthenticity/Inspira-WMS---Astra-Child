<?php

// =============================================================================
// FUNCIONES DE CURSOS — LearnDash
// =============================================================================

/**
 * Desasigna todos los cursos LearnDash de un usuario.
 */
function remove_all_user_courses( int $user_id ): bool {

    if ( empty( $user_id ) || ! get_user_by( 'id', $user_id ) ) {
        return false;
    }

    $user_courses = learndash_user_get_enrolled_courses( $user_id );

    if ( empty( $user_courses ) ) {
        return true;
    }

    foreach ( $user_courses as $course_id ) {
        ld_update_course_access( $user_id, $course_id, true );
    }

    return true;
}

/**
 * Asigna múltiples cursos LearnDash al usuario logueado.
 *
 * @param array $course_ids IDs de cursos LearnDash
 * @return bool
 */
function assign_courses_to_logged_user( array $course_ids ): bool {

    $user_id = get_current_user_id();

    if ( ! $user_id ) {
        error_log( 'assign_courses_to_logged_user: Usuario no logueado' );
        return false;
    }

    if ( empty( $course_ids ) ) {
        error_log( 'assign_courses_to_logged_user: course_ids vacío' );
        return false;
    }

    foreach ( array_unique( $course_ids ) as $course_id ) {

        $course_id = (int) $course_id;

        if ( $course_id <= 0 ) {
            continue;
        }

        if ( get_post_type( $course_id ) !== 'sfwd-courses' ) {
            error_log( "assign_courses_to_logged_user: Curso inválido: {$course_id}" );
            continue;
        }

        ld_update_course_access( $user_id, $course_id, false );
        error_log( "assign_courses_to_logged_user: Curso {$course_id} asignado al usuario {$user_id}" );
    }

    return true;
}

/**
 * Asigna cursos adicionales a un usuario específico.
 * Evita reasignar cursos a los que el usuario ya tiene acceso.
 *
 * @param int   $user_id    ID del usuario
 * @param array $course_ids IDs de cursos LearnDash
 * @return bool
 */
function asignar_cursos_adicionales( int $user_id, array $course_ids ): bool {

    if ( ! function_exists( 'ld_update_course_access' ) ) {
        return false;
    }

    foreach ( $course_ids as $course_id ) {

        $course_id = (int) $course_id;

        if ( $course_id <= 0 ) {
            continue;
        }

        if ( get_post_type( $course_id ) !== 'sfwd-courses' ) {
            continue;
        }

        if ( ld_course_check_user_access( $course_id, $user_id ) ) {
            continue;
        }

        ld_update_course_access( $user_id, $course_id, false );
    }

    return true;
}


// =============================================================================
// LÓGICA DE EVALUACIÓN — Asignación de cursos según resultados del test
// =============================================================================

/**
 * Evalúa los resultados del test y asigna los cursos correspondientes
 * al usuario logueado según las reglas de negocio.
 *
 * @param array $result Resultado devuelto por get_user_test_detailed_results()
 */
function validate_result( array $result ): void {

    // ── Umbrales de clasificación por dimensión ───────────────────────────────
    $rules = [
        // Amenazas
        'desaprobacion' => [ 'minimum' => 14, 'medium' => 25, 'maximum' => 32 ],
        // Dolores
        'insuficiencia' => [ 'minimum' => 2,  'medium' => 6,  'maximum' => 11 ],
        'rechazo'       => [ 'minimum' => 7,  'medium' => 16, 'maximum' => 23 ],
        // Estrategias
        'dependencia'   => [ 'minimum' => 1,  'medium' => 3,  'maximum' => 5  ],
        'evitacion'     => [ 'minimum' => 5,  'medium' => 10, 'maximum' => 13 ],
        'obsesividad'   => [ 'minimum' => 1,  'medium' => 3,  'maximum' => 7  ],
    ];

    // ── Mapeo dimensión → ID de curso ─────────────────────────────────────────
    $course_map = [
        'desaprobacion' => 1526,
        'insuficiencia' => 1604,
        'rechazo'       => 1593,
        'dependencia'   => 1443,
        'evitacion'     => 1429,
        'obsesividad'   => 1471,
    ];

    $results = $result['results_type'] ?? [];
    $courses = [];

    // ── AMENAZAS ──────────────────────────────────────────────────────────────
    // Regla: supera el mínimo → asignar curso
    if ( isset( $results['desaprobacion'] ) ) {
        if ( (int) $results['desaprobacion'] > $rules['desaprobacion']['minimum'] ) {
            $courses[] = $course_map['desaprobacion'];
        }
    }

    // ── DOLORES ───────────────────────────────────────────────────────────────
    // 1. Alguno MAX  → solo los MAX
    // 2. Ambos MEDIO → ambos
    // 3. MEDIO+BAJO  → solo el MEDIO
    // 4. Ambos BAJO  → ninguno
    $niveles = [];
    foreach ( [ 'insuficiencia', 'rechazo' ] as $key ) {
        if ( ! isset( $results[ $key ] ) ) continue;
        $p = (int) $results[ $key ];
        $r = $rules[ $key ];
        $niveles[ $key ] = $p > $r['medium'] ? 'max' : ( $p > $r['minimum'] ? 'med' : 'low' );
    }

    if ( in_array( 'max', $niveles, true ) ) {
        foreach ( $niveles as $key => $level ) {
            if ( $level === 'max' ) $courses[] = $course_map[ $key ];
        }
    } elseif ( count( $niveles ) === 2 && count( array_unique( $niveles ) ) === 1 && current( $niveles ) === 'med' ) {
        foreach ( $niveles as $key => $level ) $courses[] = $course_map[ $key ];
    } elseif ( in_array( 'med', $niveles, true ) ) {
        foreach ( $niveles as $key => $level ) {
            if ( $level === 'med' ) $courses[] = $course_map[ $key ];
        }
    }

    // ── ESTRATEGIAS ───────────────────────────────────────────────────────────
    // 1. Todos MAX           → todos
    // 2. Todos MEDIO         → todos
    // 3. Alguno MAX          → solo los MAX
    // 4. Alguno MEDIO + BAJO → solo los MEDIO
    // 5. Todos BAJO          → ninguno
    $niveles = [];
    foreach ( [ 'dependencia', 'evitacion', 'obsesividad' ] as $key ) {
        if ( ! isset( $results[ $key ] ) ) continue;
        $p = (int) $results[ $key ];
        $r = $rules[ $key ];
        $niveles[ $key ] = $p > $r['medium'] ? 'max' : ( $p > $r['minimum'] ? 'med' : 'low' );
    }

    $unique = array_unique( $niveles );

    if ( count( $unique ) === 1 && current( $unique ) === 'max' ) {
        foreach ( $niveles as $key => $level ) $courses[] = $course_map[ $key ];
    } elseif ( count( $unique ) === 1 && current( $unique ) === 'med' ) {
        foreach ( $niveles as $key => $level ) $courses[] = $course_map[ $key ];
    } elseif ( in_array( 'max', $niveles, true ) ) {
        foreach ( $niveles as $key => $level ) {
            if ( $level === 'max' ) $courses[] = $course_map[ $key ];
        }
    } elseif ( in_array( 'med', $niveles, true ) ) {
        foreach ( $niveles as $key => $level ) {
            if ( $level === 'med' ) $courses[] = $course_map[ $key ];
        }
    }

    // ── Asignación final ──────────────────────────────────────────────────────
    assign_courses_to_logged_user( array_values( array_unique( $courses ) ) );
}


// =============================================================================
// PROCESAMIENTO DEL TEST — Cálculo de resultados por dimensión
// =============================================================================

/**
 * Procesa las respuestas del test y devuelve resultados detallados
 * agrupados por dimensión (amenazas, dolores, estrategias).
 *
 * @param string $test_answers JSON con las respuestas del test
 * @return array
 */
function get_user_test_detailed_results( string $test_answers ): array {

    $test_answers = json_decode( $test_answers, true );

    // ── Definición de grupos por dimensión ────────────────────────────────────
    $groups = [
        'desaprobacion' => [ 'questions' => [1,2,3,4,5,6,7,8],  'labels' => ['A','B','C','D','E','F','G','H'], 'values' => [], 'sum' => 0 ],
        'insuficiencia' => [ 'questions' => [9,10,11],           'labels' => ['A','B','C','',''],               'values' => [], 'sum' => 0 ],
        'rechazo'       => [ 'questions' => [12,13,14,15,16],    'labels' => ['A','B','C','D','E'],             'values' => [], 'sum' => 0 ],
        'obsesividad'   => [ 'questions' => [17,18],             'labels' => ['A','B','','',''],                'values' => [], 'sum' => 0 ],
        'dependencia'   => [ 'questions' => [19,20],             'labels' => ['A','B','','',''],                'values' => [], 'sum' => 0 ],
        'evitacion'     => [ 'questions' => [21,22,23],          'labels' => ['A','B','C','',''],               'values' => [], 'sum' => 0 ],
    ];

    // ── Procesamiento de respuestas ───────────────────────────────────────────
    foreach ( $test_answers as &$answer ) {

        $question_index     = (int) $answer['question'] - 89;
        $answer_value       = (int) $answer['answer'];
        $answer['question'] = $question_index;

        foreach ( $groups as $key => &$group ) {
            if ( in_array( $question_index, $group['questions'], true ) ) {
                $group['sum']      += $answer_value;
                $group['values'][] = $answer_value;
            }
        }
        unset( $group );
    }
    unset( $answer );

    // ── Totales agrupados ─────────────────────────────────────────────────────
    $amenazas_total    = $groups['desaprobacion']['sum'];
    $dolores_total     = $groups['insuficiencia']['sum'] + $groups['rechazo']['sum'];
    $estrategias_total = $groups['obsesividad']['sum'] + $groups['dependencia']['sum'] + $groups['evitacion']['sum'];

    // ── Vulnerabilidad dominante ──────────────────────────────────────────────
    $vulnerabilidades    = [ 'insuficiencia' => $groups['insuficiencia']['sum'], 'rechazo' => $groups['rechazo']['sum'] ];
    $vulnerabilidad_alta = array_search( max( $vulnerabilidades ), $vulnerabilidades, true );

    // ── Respuesta final ───────────────────────────────────────────────────────
    return [
        'total'                      => count( $test_answers ),
        'result_vulnerabilidad_alta' => $vulnerabilidad_alta,
        'results_general'            => [
            'amenazas_total'    => $amenazas_total,
            'dolores_total'     => $dolores_total,
            'estrategias_total' => $estrategias_total,
        ],
        'results_promedio'           => [
            'amenazas_prom'    => $amenazas_total    / count( $groups['desaprobacion']['questions'] ),
            'dolores_prom'     => $dolores_total     / ( count( $groups['insuficiencia']['questions'] ) + count( $groups['rechazo']['questions'] ) ),
            'estrategias_prom' => $estrategias_total / ( count( $groups['obsesividad']['questions'] )  + count( $groups['dependencia']['questions'] )  + count( $groups['evitacion']['questions'] ) ),
        ],
        'results_type'               => [
            'desaprobacion' => $groups['desaprobacion']['sum'],
            'insuficiencia' => $groups['insuficiencia']['sum'],
            'rechazo'       => $groups['rechazo']['sum'],
            'obsesividad'   => $groups['obsesividad']['sum'],
            'dependencia'   => $groups['dependencia']['sum'],
            'evitacion'     => $groups['evitacion']['sum'],
        ],
        'result_type_value'          => [
            'desaprobacion' => [ 'labels' => $groups['desaprobacion']['labels'], 'value' => $groups['desaprobacion']['values'] ],
            'insuficiencia' => [ 'labels' => $groups['insuficiencia']['labels'], 'value' => $groups['insuficiencia']['values'] ],
            'rechazo'       => [ 'labels' => $groups['rechazo']['labels'],       'value' => $groups['rechazo']['values']       ],
            'obsesividad'   => [ 'labels' => $groups['obsesividad']['labels'],   'value' => $groups['obsesividad']['values']   ],
            'dependencia'   => [ 'labels' => $groups['dependencia']['labels'],   'value' => $groups['dependencia']['values']   ],
            'evitacion'     => [ 'labels' => $groups['evitacion']['labels'],     'value' => $groups['evitacion']['values']     ],
        ],
        'results'                    => $test_answers,
    ];
}


// =============================================================================
// AJAX HANDLER — Guardar respuestas del test
// =============================================================================

if ( ! function_exists( 'save_test_answers' ) ) :

    /**
     * Guarda las respuestas del test, calcula resultados y asigna cursos.
     * Hooks: wp_ajax_save_test_answers / wp_ajax_nopriv_save_test_answers
     */
    function save_test_answers(): void {

        if ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX ) {
            return;
        }

        $user_id = get_current_user_id();

        if ( ! $user_id ) {
            send_json_response( false, 'error', 'El usuario no está logueado.' );
            return;
        }

        // 1. Guardar respuestas en user meta
        $answers = $_POST['answers'] ?? '';
        update_user_meta( $user_id, 'question_test_ids', $answers );

        // 2. Leer la meta recién guardada
        $question_test_ids = get_user_meta( $user_id, 'question_test_ids', true );

        // 3. Reiniciar cursos asignados
        remove_all_user_courses( $user_id );

        // 4. Calcular resultados y asignar cursos según evaluación
        $test_results = get_user_test_detailed_results( $question_test_ids );
        validate_result( $test_results );

        // 5. Asignar cursos adicionales fijos
        asignar_cursos_adicionales( $user_id, [ 3045 ] );

        // 6. Responder
        send_json_response( true, 'success', 'Respuestas guardadas correctamente.', [
            'answers' => $answers,
        ] );
    }

endif;

add_action( 'wp_ajax_nopriv_save_test_answers', 'save_test_answers' );
add_action( 'wp_ajax_save_test_answers',        'save_test_answers' );