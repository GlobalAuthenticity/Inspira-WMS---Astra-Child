<?php

if ( !function_exists('custom_logout_handler') ){
  function custom_logout_handler() {
    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
      wp_logout();

      wp_send_json_success(array(
        'message' => 'Logout successful',
      ));
    }
  }
}

add_action( 'wp_ajax_custom_logout', 'custom_logout_handler' );
add_action( 'wp_ajax_nopriv_custom_logout', 'custom_logout_handler' );