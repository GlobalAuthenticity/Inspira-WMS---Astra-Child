jQuery(document).ready(function($) {
  // Check if the element with class 'pending-test' exists
  if ($('.pending-test').length) {
    // Add a click event listener to the element
    $('.pending-test').on('click', async function() {
      const { value: testType } = await Swal.fire({
        title: "¿Qué tipo de test quieres hacer?",
        confirmButtonText: "Continuar",
        input: "radio",
        inputOptions: {"individual": "Personal", "padres": "De padres", "parejas": "De parejas"},
        inputValidator: (value) => {
          if (!value) {
            return "¡Debes seleccionar un tipo de test!";
          }
        }
      });

      const href = $(this).data('href') + '?test-type=' + testType;
      window.location.href = href;
    });
  }
});