<?php

/**
 * @description
 * 
 * Valida la segunda pareja
 */
if (!function_exists('validate_couple')) {
  function validate_couple() {
    $couple_one_id = $_POST['coupleOneId'];
    $couple_one = get_user_by('ID', $couple_one_id);

    if (!$couple_one) {
      send_json_response(
        false, 
        'error', 
        'El código de pareja es incorrecto. Por favor, verifíquelo e intente nuevamente.'
      );
    }

    $couple_one_completed_test = UserQueries::user_completed_test($couple_one->ID);

    send_json_response(true, 'success', 'Código verificado.', ['couple_one' => $couple_one, 'completed_test' => !!$couple_one_completed_test]);
  }
}

// Ajax
add_action('wp_ajax_nopriv_validate_couple', 'validate_couple');
add_action('wp_ajax_validate_couple', 'validate_couple');