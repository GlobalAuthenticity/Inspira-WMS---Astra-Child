<?php

add_action('init', function () {

    $predefined_token = 'MUkYjVTwjJFlZDgkdPYJUNWhrueHYZo';

    // Genera 
    if ( ! get_option('aprobandome_create_user') ) {
        update_option('aprobandome_create_user', $predefined_token);
    }

});