<?php

// ─────────────────────────────────────────────────────────────────
// Shortcode: [user-general-progress]
// Muestra el progreso general de cursos LearnDash del usuario.
// Solo visible para el rol "subscriber".
// ─────────────────────────────────────────────────────────────────

// Evita "Cannot redeclare" si el archivo (o una copia) se carga dos veces:
// functions/actions.php incluye todos los .php de esta carpeta.
if ( ! function_exists( 'user_general_courses_progress' ) ) :

// Slug de la categoría LearnDash de los cursos de "Recursos adicionales"
// (los que se muestran en /mi-cuenta/adicionales/ → "Nuevos cursos").
if ( ! defined( 'UGP_ADDITIONAL_COURSES_CATEGORY' ) ) {
    define( 'UGP_ADDITIONAL_COURSES_CATEGORY', 'nuevos' );
}

/**
 * Calcula el progreso de una lista de cursos para un usuario.
 *
 * @return array{courses: array<int, array{id:int, title:string, percentage:int}>, average: int|null}
 */
function ugp_get_courses_progress( int $userId, array $courseIds ): array {
    $courses = [];
    $total   = 0;

    foreach ( $courseIds as $courseId ) {
        $progress = learndash_course_progress([
            'user_id'   => $userId,
            'course_id' => $courseId,
            'array'     => true,
        ]);

        if ( ! isset( $progress['percentage'] ) ) continue;

        $percentage = (int) $progress['percentage'];
        $total     += $percentage;
        $courses[]  = [
            'id'         => (int) $courseId,
            'title'      => get_the_title( $courseId ),
            'percentage' => $percentage,
        ];
    }

    return [
        'courses' => $courses,
        'average' => $courses ? (int) round( $total / count( $courses ) ) : null,
    ];
}

/**
 * Pinta el resumen de un grupo (porcentaje + botón "Ver cursos")
 * y su modal con el listado de cursos.
 *
 * @param string $id        Identificador único del grupo (para el modal).
 * @param string $title     Título del grupo y del modal.
 * @param array  $group     Resultado de ugp_get_courses_progress().
 * @param string $emptyText Texto cuando el grupo no tiene cursos.
 * @param string $goUrl     URL del botón "Ir a cursos".
 */
function ugp_render_group( string $id, string $title, array $group, string $emptyText, string $goUrl ): void {
    $modalId   = 'ugp-modal-' . $id;
    $total     = count( $group['courses'] );
    $completed = count( array_filter( $group['courses'], function ( $course ) {
        return $course['percentage'] >= 100;
    } ) );
    $isDone    = $group['average'] !== null && $group['average'] >= 100;
    ?>
    <div class="ugp-group">
        <div class="ugp-group-header">
            <div class="ugp-group-heading">
                <span class="ugp-group-title"><?php echo esc_html( $title ); ?></span>
                <?php if ( $total > 0 ) : ?>
                    <span class="ugp-group-sub">
                        <?php
                        echo esc_html( sprintf(
                            '%1$d de %2$d completado%3$s · %2$d curso%4$s',
                            $completed,
                            $total,
                            $completed === 1 ? '' : 's',
                            $total === 1 ? '' : 's'
                        ) );
                        ?>
                    </span>
                <?php endif; ?>
            </div>

            <?php if ( $group['average'] !== null ) : ?>
                <div class="ugp-group-actions">
                    <?php if ( $isDone ) : ?>
                        <span class="ugp-badge-done">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                <path d="M5 12.5l4.5 4.5L19 7.5" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            Completado
                        </span>
                    <?php else : ?>
                        <span class="ugp-group-pct"><?php echo esc_html( $group['average'] ); ?>%</span>
                    <?php endif; ?>
                    <button type="button" class="ugp-btn ugp-btn--ghost" data-ugp-open="<?php echo esc_attr( $modalId ); ?>">
                        Ver cursos
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <?php if ( $group['average'] === null ) : ?>
            <div class="ugp-empty">
                <span class="ugp-empty-dot"></span>
                <?php echo esc_html( $emptyText ); ?>
            </div>
        <?php else : ?>
            <div class="ugp-bar-track">
                <div class="ugp-bar-fill" style="width: <?php echo esc_attr( $group['average'] ); ?>%"></div>
            </div>

            <dialog class="ugp-modal" id="<?php echo esc_attr( $modalId ); ?>" aria-labelledby="<?php echo esc_attr( $modalId ); ?>-title">
                <div class="ugp-modal-header">
                    <h3 class="ugp-modal-title" id="<?php echo esc_attr( $modalId ); ?>-title"><?php echo esc_html( $title ); ?></h3>
                    <button type="button" class="ugp-modal-close" data-ugp-close aria-label="Cerrar">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>

                <ul class="ugp-course-list">
                    <?php foreach ( $group['courses'] as $course ) : ?>
                        <?php $courseUrl = get_permalink( $course['id'] ); ?>
                        <li class="ugp-course">
                            <div class="ugp-course-info">
                                <div class="ugp-course-meta">
                                    <a class="ugp-course-name" href="<?php echo esc_url( $courseUrl ); ?>">
                                        <?php echo esc_html( $course['title'] ); ?>
                                    </a>
                                    <span class="ugp-course-pct"><?php echo esc_html( $course['percentage'] ); ?>%</span>
                                </div>
                                <div class="ugp-bar-track ugp-bar-track--sm">
                                    <div class="ugp-bar-fill" style="width: <?php echo esc_attr( $course['percentage'] ); ?>%"></div>
                                </div>
                            </div>
                            <a class="ugp-btn ugp-btn--ghost ugp-course-btn" href="<?php echo esc_url( $courseUrl ); ?>">
                                Ir al curso
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <div class="ugp-modal-footer">
                    <a class="ugp-btn ugp-btn--primary" href="<?php echo esc_url( $goUrl ); ?>">Ir a cursos</a>
                </div>
            </dialog>
        <?php endif; ?>
    </div>
<?php }

/**
 * Script de los modales (se imprime una sola vez por página).
 */
function ugp_modal_script(): void {
    static $printed = false;
    if ( $printed ) return;
    $printed = true;
    ?>
    <script>
    (function () {
        document.addEventListener('click', function (e) {
            var open = e.target.closest('[data-ugp-open]');
            if (open) {
                var modal = document.getElementById(open.getAttribute('data-ugp-open'));
                if (modal && typeof modal.showModal === 'function') modal.showModal();
                return;
            }

            if (e.target.closest('[data-ugp-close]')) {
                e.target.closest('dialog.ugp-modal').close();
                return;
            }

            // Clic en el fondo (fuera del contenido) cierra el modal
            if (e.target.matches && e.target.matches('dialog.ugp-modal')) {
                e.target.close();
            }
        });
    })();
    </script>
    <?php
}

/**
 * En /mi-cuenta/adicionales/#nuevos-cursos desplaza la página hasta
 * la sección "Nuevos Cursos". El contenido de esa página está en
 * Elementor, así que se busca por id, por el botón "Nuevos cursos"
 * o por el título de la sección.
 */
function ugp_scroll_to_new_courses(): void {
    $isEndpoint = function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'adicionales' );
    $isPath     = strpos( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), '/mi-cuenta/adicionales/#nuevos-cursos' ) !== false;
    if ( ! $isEndpoint && ! $isPath ) return;
    ?>
    <script>
    (function () {
        if (window.location.hash !== '#nuevos-cursos') return;

        function normalize(text) {
            return (text || '').replace(/\s+/g, ' ').trim().toLowerCase();
        }

        function findTarget() {
            var byId = document.getElementById('nuevos-cursos');
            if (byId) return byId;

            // Botón/enlace "Nuevos cursos" que apunte a un ancla de la página
            var links = document.querySelectorAll('a[href*="#"]');
            for (var i = 0; i < links.length; i++) {
                if (normalize(links[i].textContent) !== 'nuevos cursos') continue;
                var hash = links[i].getAttribute('href').split('#')[1];
                var anchor = hash && document.getElementById(hash);
                if (anchor) return anchor;
            }

            // Título de la sección
            var headings = document.querySelectorAll('h1, h2, h3, h4, .elementor-heading-title');
            for (var j = 0; j < headings.length; j++) {
                if (normalize(headings[j].textContent) === 'nuevos cursos') return headings[j];
            }
            return null;
        }

        window.addEventListener('load', function () {
            var target = findTarget();
            if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    })();
    </script>
    <?php
}
add_action( 'wp_footer', 'ugp_scroll_to_new_courses' );

function user_general_courses_progress() {

    // 🔐 Solo usuarios logueados con rol subscriber
    if ( ! is_user_logged_in() ) return '';

    $user = wp_get_current_user();
    if ( ! in_array( 'subscriber', (array) $user->roles ) ) return '';

    $userId = $user->ID;

    // 📋 Datos necesarios
    $userHasTest  = get_user_meta( $userId, 'question_test_ids', true );
    $user_courses = learndash_get_user_course_access_list( $userId );

    // ── CSS ──────────────────────────────────────────────────────
    ob_start(); ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

        .ugp-wrap {
            --ugp-purple:      #5C3590;
            --ugp-purple-soft: #EDE7F6;
            --ugp-text:        #2A2240;
            --ugp-text-soft:   #7A6E90;
            --ugp-border:      #E2D9F0;
            --ugp-bg:          #FDFCFF;
            --ugp-radius:      10px;
            --ugp-shadow:      0 2px 12px rgba(92, 53, 144, 0.07);
            font-family: 'Inter', sans-serif;
            width: 100%;
            box-sizing: border-box;
        }

        /* ── Card contenedor ── */
        .ugp-card {
            background: var(--ugp-bg);
            border: 1.5px solid var(--ugp-border);
            border-radius: var(--ugp-radius);
            box-shadow: var(--ugp-shadow);
            padding: 16px 20px;
            box-sizing: border-box;
        }

        /* ── Encabezado ── */
        .ugp-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
        }

        .ugp-header-icon {
            width: 28px;
            height: 28px;
            min-width: 28px;
            background: var(--ugp-purple-soft);
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .ugp-title {
            font-family: 'Inter', sans-serif !important;
            font-size: 14px !important;
            font-weight: 600 !important;
            color: var(--ugp-text) !important;
            margin: 0 !important;
            padding: 0 !important;
            line-height: 1 !important;
            border: none !important;
            display: block;
        }

        /* ── Estado vacío ── */
        .ugp-empty {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            background: var(--ugp-purple-soft);
            border-radius: 7px;
            font-size: 12px;
            font-weight: 500;
            color: var(--ugp-text-soft);
        }

        .ugp-empty-dot {
            width: 6px;
            height: 6px;
            background: var(--ugp-purple);
            border-radius: 50%;
            flex-shrink: 0;
            opacity: 0.45;
        }

        /* ── Barra de progreso ── */
        .ugp-progress-section {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .ugp-progress-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .ugp-progress-label {
            font-size: 13px;
            font-weight: 500;
            color: var(--ugp-text-soft);
            letter-spacing: 0.2px;
        }

        .ugp-progress-pct {
            font-size: 20px;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            color: var(--ugp-purple);
            line-height: 1;
        }

        .ugp-bar-track {
            width: 100%;
            height: 6px;
            background: var(--ugp-purple-soft);
            border-radius: 100px;
            overflow: hidden;
        }

        .ugp-bar-fill {
            height: 100%;
            border-radius: 100px;
            background: linear-gradient(90deg, #7B52C0, #5C3590);
            transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            min-width: 4px;
        }

        .ugp-progress-footer {
            font-size: 13px;
            color: var(--ugp-text-soft);
            margin: 0;
            line-height: 1.5;
        }

        /* ── Desglose por grupo ── */
        .ugp-groups {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--ugp-border);
        }

        .ugp-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .ugp-group-title {
            font-size: 13px;
            font-weight: 600;
            color: var(--ugp-text);
        }

        .ugp-group-pct {
            font-size: 16px;
            font-weight: 700;
            color: var(--ugp-purple);
            line-height: 1;
        }

        .ugp-group-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
        }

        .ugp-group-heading {
            display: flex;
            flex-direction: column;
            gap: 3px;
            min-width: 0;
        }

        .ugp-group-sub {
            font-size: 12px;
            color: var(--ugp-text-soft);
        }

        .ugp-group-actions {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
        }

        .ugp-badge-done {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 10px;
            border-radius: 100px;
            background: #E6F4EA;
            color: #1E7B3C;
            font-size: 12px;
            font-weight: 600;
            line-height: 1;
            white-space: nowrap;
        }

        /* ── Botones ── */
        .ugp-btn {
            font-family: 'Inter', sans-serif !important;
            font-size: 12px !important;
            font-weight: 600 !important;
            line-height: 1 !important;
            border-radius: 7px !important;
            padding: 8px 14px !important;
            cursor: pointer;
            white-space: nowrap;
            text-decoration: none !important;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            box-shadow: none !important;
            transition: background 0.2s, color 0.2s;
        }

        .ugp-btn--ghost {
            background: var(--ugp-purple-soft) !important;
            color: var(--ugp-purple) !important;
            border: 1px solid var(--ugp-border) !important;
        }

        .ugp-btn--ghost:hover,
        .ugp-btn--ghost:focus-visible {
            background: var(--ugp-purple) !important;
            color: #fff !important;
        }

        .ugp-btn--primary {
            background: var(--ugp-purple) !important;
            color: #fff !important;
            border: 1px solid var(--ugp-purple) !important;
            padding: 10px 18px !important;
            font-size: 13px !important;
        }

        .ugp-btn--primary:hover,
        .ugp-btn--primary:focus-visible { background: #4A2A75 !important; }

        /* ── Modal ── */
        .ugp-modal {
            font-family: 'Inter', sans-serif;
            width: min(520px, calc(100vw - 32px));
            max-height: calc(100vh - 48px);
            padding: 0;
            border: none;
            border-radius: 12px;
            background: #fff;
            color: var(--ugp-text);
            box-shadow: 0 20px 50px rgba(42, 34, 64, 0.25);
            overflow: hidden;
        }

        .ugp-modal[open] {
            display: flex;
            flex-direction: column;
        }

        .ugp-modal::backdrop {
            background: rgba(42, 34, 64, 0.45);
        }

        .ugp-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 18px 20px 14px;
            border-bottom: 1px solid var(--ugp-border);
        }

        .ugp-modal-title {
            font-family: 'Inter', sans-serif !important;
            font-size: 16px !important;
            font-weight: 700 !important;
            color: var(--ugp-text) !important;
            margin: 0 !important;
            line-height: 1.3 !important;
        }

        .ugp-modal-close {
            background: transparent !important;
            border: none !important;
            color: var(--ugp-text-soft) !important;
            padding: 6px !important;
            border-radius: 6px !important;
            cursor: pointer;
            line-height: 0 !important;
            box-shadow: none !important;
        }

        .ugp-modal-close:hover,
        .ugp-modal-close:focus-visible {
            background: var(--ugp-purple-soft) !important;
            color: var(--ugp-purple) !important;
        }

        .ugp-course-list {
            list-style: none !important;
            margin: 0 !important;
            padding: 16px 20px !important;
            display: flex;
            flex-direction: column;
            gap: 14px;
            overflow-y: auto;
            min-height: 0;
        }

        .ugp-course {
            display: flex;
            align-items: center;
            gap: 14px;
            margin: 0 !important;
        }

        .ugp-course-info {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .ugp-course-btn { flex-shrink: 0; }

        .ugp-course-meta {
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            gap: 12px;
        }

        .ugp-course-name {
            font-size: 13px;
            font-weight: 500;
            color: var(--ugp-text) !important;
            text-decoration: none !important;
        }

        .ugp-course-name:hover { color: var(--ugp-purple) !important; }

        .ugp-bar-track--sm { height: 4px; }

        .ugp-course-pct {
            font-size: 13px;
            font-weight: 700;
            color: var(--ugp-purple);
            flex-shrink: 0;
        }

        .ugp-modal-footer {
            display: flex;
            justify-content: flex-end;
            padding: 14px 20px 18px;
            border-top: 1px solid var(--ugp-border);
        }

        /* ── Responsive ── */
        @media (max-width: 480px) {
            .ugp-card  { padding: 14px 16px; }
            .ugp-title { font-size: 13px; }
            .ugp-progress-pct { font-size: 14px; }
            .ugp-group-header { align-items: flex-start; gap: 10px; }
            .ugp-group-actions { gap: 8px; }
            .ugp-modal-footer .ugp-btn { width: 100%; }
            .ugp-course { gap: 10px; }
            .ugp-course-btn { padding: 7px 10px !important; font-size: 11px !important; }
        }
    </style>
    <?php
    $styles = ob_get_clean();

    // ── HTML ─────────────────────────────────────────────────────
    ob_start();
    echo $styles;
    ?>

    <div class="ugp-wrap">
        <div class="ugp-card">

            <!-- Encabezado -->
            <div class="ugp-header">
                <div class="ugp-header-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#5C3590" stroke-width="1.7" stroke-linejoin="round"/>
                        <path d="M2 17l10 5 10-5" stroke="#5C3590" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2 12l10 5 10-5" stroke="#5C3590" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <span class="ugp-title">Progreso general de mis cursos</span>
            </div>

            <?php
            // ── Estado A: Sin test realizado ──
            if ( empty( $userHasTest ) ) : ?>

                <div class="ugp-empty">
                    <span class="ugp-empty-dot"></span>
                    Aún no tienes cursos asignados
                </div>

            <?php
            // ── Estado B: Sin cursos asignados ──
            elseif ( empty( $user_courses ) ) : ?>

                <div class="ugp-empty">
                    <span class="ugp-empty-dot"></span>
                    Aún no tienes cursos asignados
                </div>

            <?php
            // ── Estado C: Calcular progreso ──
            else :
                $totalProgress = 0;
                $validCourses  = 0;

                foreach ( $user_courses as $courseId ) {
                    $progress = learndash_course_progress([
                        'user_id'   => $userId,
                        'course_id' => $courseId,
                        'array'     => true,
                    ]);

                    if ( ! isset( $progress['percentage'] ) ) continue;

                    $totalProgress += (int) $progress['percentage'];
                    $validCourses++;
                }

                // ── Estado D: Cursos sin progreso aún ──
                if ( $validCourses === 0 ) : ?>

                    <div class="ugp-empty">
                        <span class="ugp-empty-dot"></span>
                        Aún no tienes cursos en progreso
                    </div>

                <?php
                // ── Estado E: Progreso calculado ──
                else :
                    $generalProgress = round( $totalProgress / $validCourses );
                ?>

                    <div class="ugp-progress-section">

                        <div class="ugp-progress-meta">
                            <span class="ugp-progress-label">
                                Progreso promedio · <?php echo esc_html( sprintf( '%d curso%s', $validCourses, $validCourses === 1 ? '' : 's' ) ); ?>
                            </span>
                            <span class="ugp-progress-pct"><?php echo esc_html( $generalProgress ); ?>%</span>
                        </div>

                        <div class="ugp-bar-track">
                            <div
                                class="ugp-bar-fill"
                                style="width: <?php echo esc_attr( $generalProgress ); ?>%"
                            ></div>
                        </div>

                        <p class="ugp-progress-footer">
                            Continúa avanzando para completar tu camino de aprendizaje
                        </p>

                    </div>

                <?php endif; ?>
            <?php endif; ?>

            <?php
            // ── Desglose: cursos del test / recursos adicionales ──
            $testCourseIds       = [];
            $additionalCourseIds = [];

            foreach ( (array) $user_courses as $courseId ) {
                if ( has_term( UGP_ADDITIONAL_COURSES_CATEGORY, 'ld_course_category', $courseId ) ) {
                    $additionalCourseIds[] = $courseId;
                } else {
                    $testCourseIds[] = $courseId;
                }
            }

            $additionalGroup = ugp_get_courses_progress( $userId, $additionalCourseIds );
            $testGroup       = ! empty( $userHasTest )
                ? ugp_get_courses_progress( $userId, $testCourseIds )
                : [ 'courses' => [], 'average' => null ];

            if ( ! empty( $userHasTest ) || $additionalGroup['average'] !== null ) : ?>

                <div class="ugp-groups">
                    <?php
                    ugp_render_group(
                        'test',
                        'Cursos asignados por tu test',
                        $testGroup,
                        empty( $userHasTest ) ? 'Realiza el test para recibir tus cursos' : 'Aún no tienes cursos del test en progreso',
                        home_url( '/mi-cuenta/cursos/' )
                    );

                    ugp_render_group(
                        'adicionales',
                        'Cursos de recursos adicionales',
                        $additionalGroup,
                        'Aún no tienes cursos adicionales',
                        home_url( '/mi-cuenta/adicionales/#nuevos-cursos' )
                    );
                    ?>
                </div>

                <?php ugp_modal_script(); ?>

            <?php endif; ?>

        </div>
    </div>

    <?php
    return ob_get_clean();
}

add_shortcode( 'user-general-progress', 'user_general_courses_progress' );

endif;