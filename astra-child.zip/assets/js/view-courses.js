jQuery(document).ready(function($) {

    const pageTest = 'page-id-1049';


    if ($('body').hasClass(pageTest)) {

        // ===== ESTRATEGIAS =====
        const sectionEstrategias = document.getElementById('seccion_estrategias');
        if (sectionEstrategias) {
            const cursosContainerEstrategias = sectionEstrategias.querySelector('.ids__cursos');

            if (!cursosContainerEstrategias) {
                sectionEstrategias.remove();
            } else {
                const itemsEstrategias = cursosContainerEstrategias.querySelectorAll('[data-category="estrategias"]');
                if (itemsEstrategias.length === 0) {
                    sectionEstrategias.remove();
                }
            }
        }

        // ===== AMENAZAS =====
        const sectionAmenazas = document.getElementById('seccion_amenazas');
        if (sectionAmenazas) {
            const cursosContainerAmenazas = sectionAmenazas.querySelector('.ids__cursos');

            if (!cursosContainerAmenazas) {
                sectionAmenazas.remove();
            } else {
                const itemsAmenazas = cursosContainerAmenazas.querySelectorAll('[data-category="amenazas"]');
                if (itemsAmenazas.length === 0) {
                    sectionAmenazas.remove();
                }
            }
        }

        // ===== DOLORES =====
        const sectionDolores = document.getElementById('seccion_dolores');
        if (sectionDolores) {
            const cursosContainerDolores = sectionDolores.querySelector('.ids__cursos');

            if (!cursosContainerDolores) {
                sectionDolores.remove();
            } else {
                const itemsDolores = cursosContainerDolores.querySelectorAll('[data-category="dolores"]');
                if (itemsDolores.length === 0) {
                    sectionDolores.remove();
                }
            }
        }
    }

});