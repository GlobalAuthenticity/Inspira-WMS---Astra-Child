<?php
if (!function_exists('get_item_view_menu')) {

    function get_item_view_menu()
    {
        if (!defined('DOING_AJAX') || !DOING_AJAX) {
            return;
        }

        // --------------------------------------------------
        // USUARIO
        // --------------------------------------------------
        $user_id = get_current_user_id();

        if (!$user_id) {
            send_json_response(false, 'error', 'El usuario no está logueado.');
        }

        $options = [];

        // Si el usuario no ha realizado el test
        if (!UserQueries::user_completed_test($user_id)) {

            // Opciones que debe ocultar si no ha realizado el test.
            $options = [
                'my-recursos-adicionales',
                'my-results',
                'my-courses',
                'my-efren-ia'
            ];
        }

        // RESPUESTA AJAX
        // --------------------------------------------------
        $data = [
            'view_options' => $options,
        ];

        send_json_response(true, 'success', 'Resultados obtenidos correctamente', $data);

    }
}

/**
 * ======================================================
 * HOOKS AJAX
 * ======================================================
 */
add_action('wp_ajax_get_item_view_menu', 'get_item_view_menu');
add_action('wp_ajax_nopriv_get_item_view_menu', 'get_item_view_menu');