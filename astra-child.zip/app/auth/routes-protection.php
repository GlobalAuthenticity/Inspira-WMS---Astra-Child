<?php
require_once get_stylesheet_directory() . '/app/queries/user-queries.php';
require_once get_stylesheet_directory() . '/app/constants.php';

function protect_test_routes() {
  if (!is_user_logged_in()) return;

  $user_id = get_current_user_id();
  $current_user = wp_get_current_user();

  $current_url = home_url(add_query_arg([], $_SERVER['REQUEST_URI']));

  foreach (AppConstants::TEST_RESULT_URL_BY_TYPE as $type => $url) {
    if (strpos($current_url, $url) !== false) {

      // 1. Debe tener el rol 'subscriber'
      if (!in_array('subscriber', (array) $current_user->roles)) {
        wp_redirect(home_url());
        exit;
      }

      // 2. Debe tener 'question_test_ids' en wp_usermeta
      if (empty(get_user_meta($user_id, 'question_test_ids', true))) {
        wp_redirect(home_url());
        exit;
      }
    }
  }
}

add_action('template_redirect', 'protect_test_routes');

function protect_registro_route() {

    // Si el usuario NO está logueado, no hacemos nada
    if (!is_user_logged_in()) {
        return;
    }

    // URL actual completa
    $current_url = home_url(add_query_arg([], $_SERVER['REQUEST_URI']));

    // Si intenta acceder a /registro/
    if (strpos($current_url, '/registro') !== false) {

        wp_redirect(home_url('/test/?test-type=individual'));
        exit;
    }
}

add_action('template_redirect', 'protect_registro_route', 1);


/**
 * Redirige usuarios no logueados a wmslatam.com
 */
function aprobandome_protect_home() {

    // Permitir edición con Elementor
    if ( str_contains( $_SERVER['REQUEST_URI'], 'elementor' ) ) {
        return;
    }

    // Si no está logueado → redirigir siempre
    if ( ! is_user_logged_in() ) {
        wp_redirect( 'https://wmslatam.com/' );
        exit;
    }

    // Si está logueado y está en el home → panel de usuario
    if ( is_front_page() ) {
        wp_redirect( home_url( '/mi-cuenta/panel-usuario/' ) );
        exit;
    }
}

add_action( 'template_redirect', 'aprobandome_protect_home' );


