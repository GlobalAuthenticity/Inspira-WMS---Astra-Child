<p>&nbsp;</p>
<p>&nbsp;</p>
<p>/* Reset predeterminado en móviles */ @media only screen and (max-width:480px) { .container { width:100% !important; padding:0 !important; border-radius:0 !important; } .header img.logo { float:none !important; margin:0 auto 16px !important; } .header div.clearfix { display:none !important; } /* Imagen de la chica más pequeña en móvil */ .header img.hero { width:60% !important; max-width:200px !important; margin:16px auto !important; } .content { padding:16px !important; } .content h1 { font-size:24px !important; } .content p { font-size:14px !important; } .btn { padding:10px 16px !important; font-size:14px !important; } .footer td { display:block !important; width:100% !important; padding:12px 0 !important; } }</p>
<div class="container" style="max-width: 600px;margin: 0 auto;background-color: #efeee7;border-radius: 16px;overflow: hidden;font-family: Arial,sans-serif;color: #333"><!-- HEADER: logo alineado a la izquierda, imagen centrada -->
<div class="header" style="background-color: #efeee7;padding: 24px"><img class="logo" style="display: block;margin: 0;float: left" src="https://aprobandome.com/wp-content/uploads/2025/01/Logo.png" alt="Interpersonal Development System" width="180" />
<div class="clearfix" style="clear: both"> </div>
<img class="hero" style="display: block;margin: 24px auto 0;width: 80%;max-width: 270px;height: auto" src="https://aprobandome.com/wp-content/uploads/2025/10/Register.png" alt="Registro" /></div>
<!-- CUERPO con texto alineado a la izquierda -->
<div class="content" style="padding: 32px 24px;text-align: left">
<h1 style="margin: 0 0 16px;font-size: 28px;color: #000">Contraseña cambiada</h1>
<p style="margin: 0 0 24px;font-size: 16px;line-height: 1.5">Has cambiado tu contraseña correctamente. Ahora puedes usar tu nueva contraseña para iniciar sesión en tu cuenta. Si no realizaste este cambio, te recomendamos que contactes con el administrador del sitio lo antes posible.</p>
<a class="btn" style="display: inline-block;padding: 12px 24px;background-color: #f76c5e;color: #ffffff;text-decoration: none;font-size: 16px;border-radius: 20px" href="https://aprobandome.com/mi-cuenta/panel-usuario/" target="_blank" rel="noopener"> Ir a mi cuenta </a></div>
<!-- FOOTER -->
<div class="footer" style="background-color: #2a2732;color: #e0e0e0;padding: 24px">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr><!-- Contacto -->
<td style="padding-right: 16px" valign="top">
<p style="margin: 0 0 8px;font-size: 18px;font-weight: bold;color: #ffffff">Contacto</p>
<p style="margin: 4px 0;font-size: 14px;line-height: 1.4">848 Brickell ave st 950<br />Miami – Florida<br /><a style="color: #e0e0e0;text-decoration: none" href="mailto:info@wmslatam.com">info@wmslatam.com</a></p>
</td>
<!-- Síguenos -->
<td style="padding-right: 16px" valign="top">
<p style="margin: 0 0 8px;font-size: 18px;font-weight: bold;color: #ffffff">Síguenos</p>
<p style="margin: 4px 0"><a style="display: inline-block;margin-right: 8px" href="https://www.instagram.com/sistemadin?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank" rel="noopener"> <img style="display: block;border: 0" src="https://aprobandome.com/wp-content/uploads/2025/10/Instagram.png" alt="Instagram" width="24" height="24" /> </a> <!-- Logo de LinkedIn oculto --> <a style="display: none" href="https://www.linkedin.com/" target="_blank" rel="noopener"> <img style="display: block;border: 0" src="https://aprobandome.com/wp-content/uploads/2025/03/Linkedin.svg" alt="LinkedIn" width="24" height="24" /> </a></p>
</td>
<!-- Grupo empresarial -->
<td valign="top">
<p style="margin: 0 0 8px;font-size: 18px;font-weight: bold;color: #ffffff">Grupo empresarial</p>
<p style="margin: 4px 0;font-size: 14px;line-height: 1.4"><a style="color: #e0e0e0;text-decoration: none" href="https://efrenmartinezortiz.com/" target="_blank" rel="noopener">Dr. Efren Martínez Ortiz</a><br /><a style="color: #e0e0e0;text-decoration: none" href="https://wmslatam.com/" target="_blank" rel="noopener">WMS</a><br /><a style="color: #e0e0e0;text-decoration: none" href="https://terapiaunclick.com/" target="_blank" rel="noopener">TClick</a><br /><a style="color: #e0e0e0;text-decoration: none" href="https://colectivoaquiyahora.org/" target="_blank" rel="noopener">Colectivo Aquí y Ahora</a><br /><a style="color: #e0e0e0;text-decoration: none" href="https://saps-col.org/" target="_blank" rel="noopener">SAPS</a></p>
</td>
</tr>
</tbody>
</table>
<p style="font-size: 12px;color: #aaa;text-align: center;margin-top: 24px">© 2025 IDS, Todos los derechos reservados</p>
</div>
</div>
<p>&lt;!--</p>
<div style="max-width: 560px;padding: 20px;background: #ffffff;border-radius: 5px;margin: 40px auto;font-family: Open Sans,Helvetica,Arial;font-size: 15px;color: #666">
<div style="color: #444444;font-weight: normal">
<div style="text-align: center;font-weight: 600;font-size: 26px;padding: 10px 0;border-bottom: solid 3px #eeeeee">{site_name}</div>
<div style="clear: both"> </div>
</div>
<div style="padding: 0 30px 30px 30px;border-bottom: 3px solid #eeeeee">
<div style="padding: 30px 0;font-size: 24px;text-align: center;line-height: 40px">You recently changed the password associated with your account.</div>
<div style="padding: 10px 0 50px 0;text-align: center"><a style="background: #555555;color: #fff;padding: 12px 30px;text-decoration: none;border-radius: 3px;letter-spacing: 0.3px" href="{user_account_link}">Go to your Account</a></div>
<div style="padding: 15px;background: #eee;border-radius: 3px;text-align: center">If you did not make this change and believe your account has been compromised, please <a style="color: #3ba1da;text-decoration: none" href="mailto:{admin_email}">contact us</a> ASAP.</div>
</div>
<div style="color: #999;padding: 20px 30px">
<div>Thank you!</div>
<div>The <a style="color: #3ba1da;text-decoration: none" href="{site_url}">{site_name}</a> Team</div>
</div>
</div>
<p>--&gt;</p>
<p>&nbsp;</p>