<?php
/**
 * Funciones del child theme
 *
 * @package astra child theme
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

define( 'CHILD_THEME_ASTRA_CHILD_THEME_VERSION', '1.0.0' );


// ─── Archivos importados ──────────────────────────────────────────────────────

// require_once get_stylesheet_directory() . '/hooks/course_assignment_import.php'; // Asignación de tests y cursos
// require_once get_stylesheet_directory() . '/hooks/generate_secure_token_secret.php'; // Generación de tokens para APIs

require_once get_stylesheet_directory() . '/apis/api-user-registration.php'; // Registro de usuario por correo
require_once get_stylesheet_directory() . '/hooks/wc_hooks.php';             // Hooks de WooCommerce
require_once get_stylesheet_directory() . '/inc/helpers.php';

// ─── API REST – POST Endpoints ──────────────────────────────────────────────────────────────────

// --------- Users ----------
require_once get_stylesheet_directory() . '/inc/api/post/user/create-user-admin-post.php';
require_once get_stylesheet_directory() . '/inc/api/post/user/create-user-member-post.php';
require_once get_stylesheet_directory() . '/inc/api/post/user/user-id-by-email.php';
// --------- Areas ----------
require_once get_stylesheet_directory() . '/inc/api/post/area/create-area-post.php';
require_once get_stylesheet_directory() . '/inc/api/post/area/update-area-post.php';



// ─── Estilos ──────────────────────────────────────────────────────────────────

function child_enqueue_styles() {
    wp_enqueue_style(
        'astra-child-theme-theme-css',
        get_stylesheet_directory_uri() . '/style.css',
        array( 'astra-theme-css' ),
        CHILD_THEME_ASTRA_CHILD_THEME_VERSION,
        'all'
    );
}
add_action( 'wp_enqueue_scripts', 'child_enqueue_styles', 15 );


// ─── Recursos del tema (cursos, tests, correos…) ─────────────────────────────

function sistemadi_resources_init() {
    include dirname( __FILE__ ) . '/' . trailingslashit( 'functions' ) . 'enqueue-php-files.php';
}
add_action( 'init', 'sistemadi_resources_init', 0 );


// ─── Autenticación y redirecciones ───────────────────────────────────────────

// Redirige a /login/ si intenta acceder a /mi-cuenta/ sin sesión.
// Usa wp_safe_redirect y verifica que no estemos ya en el flujo de login
// para evitar el loop de redirect_to con double-encoding infinito.
// function wc_bypass_woocommerce_login() {
//     if ( ! is_page( 'mi-cuenta' ) || get_current_user_id() ) {
//         return;
//     }

//     // Si hay un redirect_to en la URL significa que WP ya está procesando
//     // el login — no interrumpir ese flujo para evitar el loop.
//     if ( ! empty( $_GET['redirect_to'] ) ) {
//         return;
//     }

//     wp_safe_redirect( home_url( '/login/' ) );
//     exit;
// }
// add_action( 'template_redirect', 'wc_bypass_woocommerce_login' );

// Fuerza la URL de destino post-login a una ruta fija y limpia,
// cortando cualquier redirect_to anidado que WooCommerce pudiera generar.
add_filter( 'woocommerce_login_redirect', function( $redirect, $user ) {
    return home_url( '/mi-cuenta/panel-usuario/' );
}, 10, 2 );

// Redirige a /cerrar-sesion al hacer logout
function wc_bypass_logout_confirmation() {
    global $wp;
    if ( isset( $wp->query_vars['customer-logout'] ) ) {
        wp_redirect( esc_url_raw( get_site_url() . '/cerrar-sesion' ) );
        exit;
    }
}
add_action( 'template_redirect', 'wc_bypass_logout_confirmation' );

// Redirige a /mi-cuenta/editar-cuenta/ tras guardar cambios de cuenta
function ids_redirigir_con_mensaje_exito( $user_id ) {
    if ( ! $user_id ) return;
    wp_safe_redirect( home_url( '/mi-cuenta/editar-cuenta/' ) );
    exit;
}
add_action( 'woocommerce_save_account_details', 'ids_redirigir_con_mensaje_exito', 20 );

// Redirige /test sin parámetros a /test/?test-type=individual
add_action( 'template_redirect', function () {
    if ( is_admin() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) ) return;

    $path = rtrim( parse_url( $_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH ), '/' );

    if ( $path === '/test' && empty( $_GET['test-type'] ) ) {
        $args = array_merge( $_GET, [ 'test-type' => 'individual' ] );
        wp_safe_redirect( add_query_arg( $args, home_url( '/test/' ) ), 301 );
        exit;
    }
}, 1 );

// Comentado: redirección automática tras login
// function auto_redirect_after_login( $user_login, $user ) {
//     wp_redirect( esc_url_raw( get_site_url() . '/mi-cuenta/panel-usuario' ) );
//     exit;
// }
// add_action( 'wp_login', 'auto_redirect_after_login', 10, 2 );


// ─── YITH: menú lateral ───────────────────────────────────────────────────────

// Elimina el menú lateral por defecto de YITH My Account Menu
function sistemadi_remove_yith_menu_print_actions() {
    remove_all_actions( 'yith_wcmap_print_single_endpoint' );
    remove_all_actions( 'yith_wcmap_print_endpoints_group' );
}
add_action( 'after_setup_theme', 'sistemadi_remove_yith_menu_print_actions' );


// ─── Checkout: email de pareja ────────────────────────────────────────────────

// Validar el campo en el checkout
function validate_field_couple_email() {
    if ( isset( $_POST['couple_email'] ) ) {
        if ( empty( $_POST['couple_email'] ) ) {
            wc_add_notice( __( 'Debe ingresar el correo electrónico de su pareja' ), 'error' );
        } elseif ( ! filter_var( $_POST['couple_email'], FILTER_VALIDATE_EMAIL ) ) {
            wc_add_notice( __( 'Por favor ingresa un correo electrónico válido' ), 'error' );
        }
    }
}
add_action( 'woocommerce_checkout_process', 'validate_field_couple_email' );

// Guardar el email de pareja en metadatos del pedido
function save_couple_email_metadata( $order_id ) {
    error_log( 'POST: ' . print_r( $_POST, true ) );
    if ( ! empty( $_POST['couple_email'] ) ) {
        update_post_meta( $order_id, '_couple_email', sanitize_email( $_POST['couple_email'] ) );
    }
}
add_action( 'woocommerce_checkout_update_order_meta', 'save_couple_email_metadata' );

// Mostrar el email de pareja en el panel de administración
function show_couple_email_admin( $order ) {
    $email = get_post_meta( $order->get_id(), '_couple_email', true );
    if ( $email ) {
        echo '<p><strong>Email Pareja:</strong> ' . esc_html( $email ) . '</p>';
    }
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'show_couple_email_admin', 10, 1 );


// ─── Correo de bienvenida ─────────────────────────────────────────────────────

// Se dispara al completar el formulario de registro con Ultimate Member
function sistemadi_send_welcome_email( $user_id, $args ) {
    if ( isset( $args['user_email'] ) ) {
        send_welcome_email( $args['user_email'] );
    }
}
add_action( 'um_registration_complete', 'sistemadi_send_welcome_email', 10, 2 );


// ─── Perfil de usuario: campos adicionales ────────────────────────────────────

// Mostrar campos extra en el perfil del admin
function custom_extra_user_profile_fields( $user ) { ?>
    <h2>Datos adicionales</h2>
    <table class="form-table" role="presentation">
        <tr>
            <th><label for="user_phone_number">Teléfono</label></th>
            <td>
                <input type="text" name="user_phone_number" id="user_phone_number"
                       value="<?php echo esc_attr( get_user_meta( $user->ID, 'user_phone_number', true ) ); ?>"
                       class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="country">País</label></th>
            <td>
                <input type="text" name="country" id="country"
                       value="<?php echo esc_attr( get_user_meta( $user->ID, 'country', true ) ); ?>"
                       class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="user_has_children">¿Tiene hijos?</label></th>
            <td>
                <input type="text" name="user_has_children" id="user_has_children"
                       value="<?php echo esc_attr( get_user_meta( $user->ID, 'user_has_children', true ) ); ?>"
                       class="regular-text" />
                <p class="description">Ej: sí/no, 0/1, o el valor que uses en tu formulario.</p>
            </td>
        </tr>
        <tr>
            <th><label for="user_marital_status">Estado civil</label></th>
            <td>
                <input type="text" name="user_marital_status" id="user_marital_status"
                       value="<?php echo esc_attr( get_user_meta( $user->ID, 'user_marital_status', true ) ); ?>"
                       class="regular-text" />
            </td>
        </tr>
    </table>
<?php }
add_action( 'show_user_profile', 'custom_extra_user_profile_fields' );
add_action( 'edit_user_profile', 'custom_extra_user_profile_fields' );

// Guardar los campos extra al actualizar el perfil
function custom_save_extra_user_profile_fields( $user_id ) {
    if ( ! current_user_can( 'edit_user', $user_id ) ) return false;

    $fields = [ 'user_phone_number', 'country', 'user_has_children', 'user_marital_status' ];
    foreach ( $fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_user_meta( $user_id, $field, sanitize_text_field( $_POST[ $field ] ) );
        }
    }
}
add_action( 'personal_options_update',  'custom_save_extra_user_profile_fields' );
add_action( 'edit_user_profile_update', 'custom_save_extra_user_profile_fields' );

// Desactiva el email nativo de WordPress al cambiar contraseña
add_filter( 'send_password_change_email', '__return_false' );


// ─── API REST: obtener usuario por email ──────────────────────────────────────

if ( ! defined( 'CUSTOM_API_KEY' ) ) {
    define( 'CUSTOM_API_KEY', 'piz_ksdjfhdsflksdnhflkvjlkdsjlkdsjlkvcjds_123' );
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'custom/v1', '/user', [
        'methods'             => 'GET',
        'callback'            => 'custom_get_user_by_email',
        'permission_callback' => 'custom_api_permission_check_get',
    ]);
});

function custom_api_permission_check_get( WP_REST_Request $request ) {
    if ( ! defined( 'CUSTOM_API_KEY' ) || empty( CUSTOM_API_KEY ) ) {
        return new WP_Error( 'api_key_missing', 'API Key no configurada', [ 'status' => 500 ] );
    }
    $provided = (string) $request->get_header( 'x-api-key' );
    if ( empty( $provided ) || ! hash_equals( (string) CUSTOM_API_KEY, $provided ) ) {
        return new WP_Error( 'forbidden', 'No autorizado', [ 'status' => 403 ] );
    }
    return true;
}

function custom_get_user_by_email( WP_REST_Request $request ) {
    $email = sanitize_email( $request->get_param( 'email' ) );
    if ( empty( $email ) || ! is_email( $email ) ) {
        return new WP_REST_Response( [ 'ok' => false, 'error' => 'Email inválido' ], 400 );
    }

    $user = get_user_by( 'email', $email );
    if ( ! $user ) {
        return new WP_REST_Response( [ 'ok' => false, 'error' => 'Usuario no encontrado' ], 404 );
    }

    return new WP_REST_Response( [
        'ok'   => true,
        'user' => [
            'id'           => (int) $user->ID,
            'email'        => $user->user_email,
            'username'     => $user->user_login,
            'display_name' => $user->display_name,
            'registered'   => $user->user_registered,
            'roles'        => $user->roles,
        ],
        'meta' => [
            'first_name' => get_user_meta( $user->ID, 'first_name', true ),
            'last_name'  => get_user_meta( $user->ID, 'last_name', true ),
            'phone'      => get_user_meta( $user->ID, 'phone',      true ),
        ],
    ], 200 );
}


// ─── Fix: parámetro test-type en formularios y enlaces ───────────────────────

// Asegura que test-type siempre sea "individual" en URLs, formularios y botones
add_action( 'wp_footer', function () { ?>
    <script>
    (function () {
        'use strict';

        function fixTestTypeParam() {
            var url = window.location.href;
            if ( url.includes('test-type=') && ! url.includes('test-type=individual') ) {
                window.location.href = url.replace(/test-type=([^&]*)/, 'test-type=individual');
            }
        }

        document.addEventListener('DOMContentLoaded', function () {

            // Formularios
            document.querySelectorAll('form').forEach(function (form) {
                form.addEventListener('submit', function (e) {
                    var action = this.getAttribute('action') || '';
                    if ( action.includes('test-type=') && ! action.includes('test-type=individual') ) {
                        e.preventDefault();
                        this.setAttribute('action', action.replace(/test-type=([^&]*)/, 'test-type=individual'));
                        this.submit();
                    }
                });
            });

            // Botones y enlaces
            document.querySelectorAll('button, a, input[type="submit"], input[type="button"]').forEach(function (el) {
                el.addEventListener('click', function (e) {
                    var href   = this.getAttribute('href') || '';
                    var parent = this.closest('form');

                    if ( href.includes('test-type=') && ! href.includes('test-type=individual') ) {
                        e.preventDefault();
                        window.location.href = href.replace(/test-type=([^&]*)/, 'test-type=individual');
                    }

                    if ( parent ) {
                        var action = parent.getAttribute('action') || '';
                        if ( action.includes('test-type=') && ! action.includes('test-type=individual') ) {
                            parent.setAttribute('action', action.replace(/test-type=([^&]*)/, 'test-type=individual'));
                        }
                    }
                });
            });

            fixTestTypeParam();
        });
    })();
    </script>
<?php }, 999 );


// ─── Fix: video LearnDash en Safari ──────────────────────────────────────────

// Habilita el botón "Marcar como completado" al finalizar o llegar al 90% del video
add_action( 'wp_footer', 'fix_learndash_safari_video' );
function fix_learndash_safari_video() {
    if ( ! is_singular( 'sfwd-lessons' ) && ! is_singular( 'sfwd-topic' ) ) return;
    ?>
    <script>
    jQuery(document).ready(function ($) {
        var video = $('video').get(0);
        if ( ! video || ! /^((?!chrome|android).)*safari/i.test(navigator.userAgent) ) return;

        video.addEventListener('seeked',  function () { $(video).trigger('timeupdate'); });
        video.addEventListener('ended',   function () {
            $('.ld-button-mark-complete').prop('disabled', false).removeClass('disabled');
        });
        video.addEventListener('timeupdate', function () {
            if ( video.currentTime / video.duration >= 0.9 ) {
                $('.ld-button-mark-complete').prop('disabled', false).removeClass('disabled');
            }
        });
    });
    </script>
    <?php
}

// Desactiva la progresión de video en Safari (compatibilidad)
add_filter( 'learndash_video_progression', 'disable_video_progression_safari' );
function disable_video_progression_safari( $enabled ) {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    return ( str_contains( $ua, 'Safari' ) && ! str_contains( $ua, 'Chrome' ) ) ? false : $enabled;
}


// ─── HTTPS: forzar en todos los recursos ─────────────────────────────────────

function force_https_urls( $url ) {
    return is_ssl() ? str_replace( 'http://', 'https://', $url ) : $url;
}
add_filter( 'script_loader_src', 'force_https_urls', 999 );
add_filter( 'style_loader_src',  'force_https_urls', 999 );
add_filter( 'content_url',       'force_https_urls', 999 );


// ─── Afiliados: guardar cookie en el pedido ───────────────────────────────────

// Guarda affiliate_ref y affiliate_ref_aprobandome desde las cookies del navegador
add_action( 'woocommerce_checkout_create_order', function ( $order, $data ) {
    foreach ( [ 'affiliate_ref', 'affiliate_ref_aprobandome' ] as $key ) {
        if ( ! empty( $_COOKIE[ $key ] ) ) {
            $order->update_meta_data( $key, sanitize_text_field( $_COOKIE[ $key ] ) );
        }
    }
}, 10, 2 );

// Añade los datos de afiliado al payload del webhook de WooCommerce
add_filter( 'woocommerce_webhook_payload', function ( $payload, $resource, $webhook_id ) {
    if ( $resource !== 'order' ) return $payload;

    $order_id = $payload['id'] ?? null;
    if ( ! $order_id ) return $payload;

    foreach ( [ 'affiliate_ref', 'affiliate_ref_aprobandome' ] as $key ) {
        $value = get_post_meta( $order_id, $key, true );
        if ( empty( $value ) ) continue;

        $decoded = json_decode( stripslashes( $value ), true );
        $payload[ $key ] = ( json_last_error() === JSON_ERROR_NONE ) ? $decoded : $value;
    }

    return $payload;
}, 10, 3 );


// ─── HubSpot: código de seguimiento ──────────────────────────────────────────

add_action( 'wp_footer', function () { ?>
    <!-- HubSpot Tracking -->
    <script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/50065652.js"></script>
<?php } );


// ─── Menú: eliminar ítem "areas admin" del header ────────────────────────────

// IMPORTANTE: se usa wp_head en lugar de template_redirect para no interferir
// con las redirecciones de WooCommerce durante el flujo de login.
// Usar ob_start en template_redirect enviaba headers antes que WC pudiera
// hacer sus propias redirecciones, contribuyendo al loop de redirect_to.
add_action( 'wp_head', function () {
    ob_start( function ( $html ) {
        return preg_replace(
            '#<ul class="sistemadi-header__navigation">\s*<li class="sistemadi-header__navigation-item">\s*<a href="https://aprobandome\.wmslatam\.com/areas-admin/">areas admin</a>\s*</li>\s*</ul>#is',
            '',
            $html
        );
    });
});


// ─── Efrén IA: bloquear tarjeta si el usuario no completó el test ────────────

// La tarjeta "Efrén IA" (#efrenia) es un contenedor de Elementor. Si el
// usuario no tiene 'question_test_ids' en wp_usermeta (mismo criterio que
// UserQueries::user_completed_test), se blurea, se le pone un candado y el
// click muestra un modal en vez de ejecutar la acción configurada en Elementor.
add_action( 'wp_footer', function () {
    $user = wp_get_current_user();

    // Los empresa_admin siempre ven la tarjeta completa, hayan hecho el test o no.
    if ( in_array( 'empresa_admin', (array) $user->roles, true ) ) {
        return;
    }

    $completed_test = is_user_logged_in()
        ? get_user_meta( $user->ID, 'question_test_ids', true )
        : '';

    if ( ! empty( $completed_test ) ) {
        return;
    }
    ?>
    <style>
        #efrenia {
            position: relative;
            cursor: not-allowed !important;
            overflow: hidden;
            border-radius: 16px;
        }
        #efrenia > * {
            pointer-events: none;
            user-select: none;
        }
        /* Un único blur sobre todo el contenido (evita la costura entre
           bloques que se ve al blurear cada hijo por separado). */
        #efrenia::after {
            content: "";
            position: absolute;
            inset: 0;
            backdrop-filter: blur(6px) brightness(0.7) saturate(0.9);
            -webkit-backdrop-filter: blur(6px) brightness(0.7) saturate(0.9);
            background: rgba(0, 0, 0, 0.15);
            z-index: 5;
        }
        #efrenia::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 60px;
            height: 60px;
            z-index: 6;
            background-color: rgba(20, 18, 30, 0.65);
            border: 1px solid rgba(255, 255, 255, 0.35);
            border-radius: 50%;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.45);
            background-repeat: no-repeat;
            background-position: center;
            background-size: 24px;
            background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><rect x='5' y='11' width='14' height='9' rx='2' ry='2'/><path d='M8 11V7a4 4 0 0 1 8 0v4'/></svg>");
        }
    </style>
    <script>
    // Captura el click antes que cualquier acción de Elementor en #efrenia.
    document.addEventListener('click', function (e) {
        var el = e.target.closest && e.target.closest('#efrenia');
        if (!el) return;

        e.preventDefault();
        e.stopPropagation();

        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'info',
                title: 'Test pendiente',
                text: 'Para acceder a Efrén IA debes terminar el test',
                confirmButtonText: 'Entendido'
            });
        } else {
            alert('Para acceder a Efrén IA debes terminar el test');
        }
    }, true);
    </script>
    <?php
}, 20 );


// Romper redirect loop en homepage
add_action('init', function() {
    if (
        isset($_GET['redirect_to']) &&
        strpos(urldecode($_GET['redirect_to']), 'redirect_to') !== false
    ) {
        // Loop detectado — redirigir limpio al home
        wp_safe_redirect(home_url('/'), 302);
        exit;
    }
}, 0); // prioridad 0 = antes de todo


add_action('template_redirect', function() {
    if (is_front_page() || is_home()) {
        error_log('=== FRONT PAGE REDIRECT DEBUG ===');
        error_log('User ID: ' . get_current_user_id());
        error_log('Filters on template_redirect: ' . print_r(
            array_keys($GLOBALS['wp_filter']['template_redirect']->callbacks ?? []), 
            true
        ));
    }
}, 0);

add_action('template_redirect', function() {
    if (is_front_page() || is_home()) {
        global $wp_filter;
        $hooks = $wp_filter['template_redirect']->callbacks ?? [];
        $prioridades_sospechosas = [555, 999, 1000, 1010, 9990, 9999, 10000, 10001, 10002];
        
        foreach ($prioridades_sospechosas as $p) {
            if (isset($hooks[$p])) {
                foreach ($hooks[$p] as $key => $callback) {
                    $func = $callback['function'];
                    if (is_array($func)) {
                        $name = get_class($func[0]) . '::' . $func[1];
                    } elseif (is_string($func)) {
                        $name = $func;
                    } else {
                        $name = 'closure';
                    }
                    error_log("=== HOOK prioridad $p: $name ===");
                }
            }
        }
    }
}, 0);

add_action('template_redirect', function() {
    if (is_front_page() || is_home()) {
        if (function_exists('UM')) {
            remove_action('template_redirect', array(UM()->access(), 'template_redirect'), 1000);
        }
    }
}, 5);


add_action('init', function () {

    $predefined_token = 'MUkYjVTwjJFlZDgkdPYJUNWhrueHYZo';

    if ( ! get_option('aprobandome_create_admin_user') ) {
        update_option('aprobandome_create_admin_user', $predefined_token);
    }

    if ( ! get_option('aprobandome_create_area') ) {
        update_option('aprobandome_create_area', $predefined_token);
    }

    if ( ! get_option('aprobandome_create_user_member') ) {
        update_option('aprobandome_create_user_member', $predefined_token);
    }

    if ( ! get_option('aprobandome_update_area') ) {
        update_option('aprobandome_update_area', $predefined_token);
    }

    if ( ! get_option('aprobandome_user_id_by_email') ) {
        update_option('aprobandome_user_id_by_email', $predefined_token);
    }

});

