document.addEventListener("DOMContentLoaded", () => {
  const sistemadiOverlay = document.querySelector(".sistemadi-header__mobile-overlay")
  const mobileMenu = document.querySelector(".sistemadi-header__mobile-menu")
  const btnToggle = document.querySelector(".sistemadi-header__mobile-menu-toggle")
  const btnClose = document.querySelector(".sistemadi-header__mobile-menu-close")
  const navigationItems = document.querySelectorAll(".sistemadi-header__navigation-item")

  btnToggle.addEventListener("click", () => {
    mobileMenu.classList.remove("sistemadi-hide")
    sistemadiOverlay.classList.remove("sistemadi-hide")
  })

  btnClose.addEventListener("click", () => {
    mobileMenu.classList.add("sistemadi-hide")
    sistemadiOverlay.classList.add("sistemadi-hide")
  })

  navigationItems.forEach(item => {
    if (window.matchMedia("(max-width: 1050px)").matches) {
      item.addEventListener("click", () => {
        const subMenu = item.querySelector(".sistemadi-header__submenu")
        
        if (subMenu) {
            const isShown = subMenu.style.display !== 'none';
            subMenu.style.display = isShown ? 'none' : 'block'
        }
      })
    }
  })
})
