<?php

if (!function_exists('get_assign_course_ids_to_users')) {

    function get_assign_course_ids_to_users()
    {
        // -----------------------------------------
        // Validar AJAX
        // -----------------------------------------
        if (!defined('DOING_AJAX') || !DOING_AJAX) {
            wp_send_json_error([
                'message' => 'Acceso no permitido.'
            ]);
        }

        // -----------------------------------------
        // Usuario logueado
        // -----------------------------------------
        $user_id = get_current_user_id();

        if (!$user_id) {
            wp_send_json_error([
                'message' => 'El usuario no está logueado.'
            ]);
        }

        // -----------------------------------------
        // Obtener cursos desde POST
        // -----------------------------------------
        $course_ids = isset($_POST['course_ids']) ? (array) $_POST['course_ids'] : [];

        if (empty($course_ids)) {
            wp_send_json_error([
                'message' => 'No se recibieron cursos.'
            ]);
        }

        // Sanitizar IDs
        $course_ids = array_map('intval', $course_ids);

        // -----------------------------------------
        // Cursos ya asignados al usuario
        // -----------------------------------------
        $user_courses = learndash_user_get_enrolled_courses($user_id);
        $user_courses = array_map('intval', $user_courses);

        // -----------------------------------------
        // Filtrar solo los cursos NO asignados
        // -----------------------------------------
        $courses_to_assign = array_diff($course_ids, $user_courses);

        if (empty($courses_to_assign)) {
            wp_send_json_success([
                'message' => 'El usuario ya tiene todos los cursos asignados.',
                'assigned' => [],
            ]);
        }

        // -----------------------------------------
        // Asignar cursos faltantes
        // -----------------------------------------
        foreach ($courses_to_assign as $course_id) {
            ld_update_course_access($user_id, $course_id);
        }

        // -----------------------------------------
        // Respuesta OK
        // -----------------------------------------
        wp_send_json_success([
            'message'  => 'Cursos asignados correctamente.',
            'assigned' => array_values($courses_to_assign),
        ]);
    }
}

/**
 * ======================================================
 * HOOKS AJAX
 * ======================================================
 */
add_action('wp_ajax_get_assign_course_ids_to_users', 'get_assign_course_ids_to_users');
add_action('wp_ajax_nopriv_get_assign_course_ids_to_users', 'get_assign_course_ids_to_users');
