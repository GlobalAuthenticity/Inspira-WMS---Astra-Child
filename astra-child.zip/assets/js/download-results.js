jQuery(document).ready(function ($) {

    /**
    * @description
    * Click en el botón para descargar resultado del test
    */

   /**
    * URL del webhook que genera el PDF del resultado personal.
    *
    * La publica el plugin «Webhooks de generación de PDF (Inspira)» en
    * window.ipwPdfWebhooks, de modo que se cambia desde wp-admin sin tocar
    * este archivo. El literal de respaldo es la URL que estaba escrita aquí
    * antes de existir esa pantalla: si el plugin se desactiva, la descarga
    * sigue funcionando exactamente igual que antes.
    */
   function urlWebhookPDF() {
      var configurada = window.ipwPdfWebhooks && window.ipwPdfWebhooks.personal;

      return configurada || 'https://api.efrenmartinezortiz-ia.com/webhook/pdf_inspira';
   }

   function descargarPDF() {
      // Cambiar texto del modal de espera
      $('#customModalWaiting .modal-waiting-text').html('Estamos descargando tu informe.');

      // Abrir modal de espera
      $("#customModalWaiting").css("display", "flex").hide().fadeIn(300);

      // Recuperar el resultado del test desde el localStorage
      const result = JSON.parse(localStorage.getItem('resultado'));

      console.log({result});

      $.ajax({
         url: urlWebhookPDF(),
         type: 'POST',
         headers: {
            'Content-Type': 'application/json'
         },
         data: JSON.stringify(result),
         success: function (response) {
            //const pdfUrl = response['pdfUrl'];
            //window.open(pdfUrl, '_parent').focus();
            //window.open(pdfUrl, '_blank').focus();
            const pdfUrl = response['pdfUrl'];
            const nombreUsuario = (typeof code_scripts !== 'undefined' && code_scripts.user_full_name)
               ? code_scripts.user_full_name
               : 'usuario';
            const nombreArchivo = `${nombreUsuario} resultado.pdf`.replace(/[\\/:*?"<>|]/g, '');
            forzarDescargaDesdeGCS(pdfUrl, nombreArchivo);
         },
         error: function () {
            alert('Ocurrió un error al generar el PDF.');
         },
         complete: function () {
            // Cerrar modal de espera
            $("#customModalWaiting").fadeOut(300, function () {
               $(this).css("display", "none");
            });

            // localStorage.removeItem('resultado');
         }
      });
   }
   

   const forzarDescargaDesdeGCS = async (url, nombreArchivo = "documento.pdf") => {
   try {
      const respuesta = await fetch(url);
      const blob = await respuesta.blob();

      const urlDescarga = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = urlDescarga;
      link.download = nombreArchivo;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      URL.revokeObjectURL(urlDescarga);
   } catch (error) {
      console.error("No se pudo descargar el PDF:", error);
   }
   };
    // Asignar el evento a los botones de descargar el PDF
    $(document).on('click', '.pdf-test-dependencia', function (event) {
        event.preventDefault();
        descargarPDF();
    });

    




});