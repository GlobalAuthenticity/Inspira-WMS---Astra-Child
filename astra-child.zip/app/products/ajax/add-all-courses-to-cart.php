<?php

/**
 * @description
 * Función para añadir todos los cursos o los cursos de una categoría al carrito de compras.
 * 
 * Esta lógica se llama desde ../assets/js/buy-courses.js
 * @param $_POST 'product_id' y 'price'
 */
function ids_wc_add_category_all_to_cart() {
    if (defined('DOING_AJAX') && DOING_AJAX) {
        // Estado de la respuesta
        $status = true;
    
        // ID del producto
        $product_id = absint($_POST['product_id']);
        $price = absint($_POST['price']);
    
        // Obtenemos el carrito actual
        $cart = WC()->cart;
        if ($cart) {
            // Obtenemos los items del carrito
            $items = $cart->cart_contents;
            if ($items) {
                // Verificamos si el producto con todos los cursos está en el carrito y si el id que se está agregando no es el de todos los cursos.
                if (
                    in_array(AppConstants::ALL_COURSES_PRODUCT_ID, array_column($items, 'product_id')) &&
                    $product_id != AppConstants::ALL_COURSES_PRODUCT_ID
                ) {
                    // Remover el producto de todos los cursos del carrito
                    foreach ($items as $cart_item_key => $cart_item) {
                        if ($cart_item['product_id'] == AppConstants::ALL_COURSES_PRODUCT_ID) {
                            WC()->cart->remove_cart_item($cart_item_key);
                        }
                    }
                } else if ($product_id == AppConstants::ALL_COURSES_PRODUCT_ID) {
                    // Remover otros productos del carrito si el producto que se está agregando es el de todos los cursos.
                    foreach ($items as $cart_item_key => $cart_item) {
                        WC()->cart->remove_cart_item($cart_item_key);
                    }
                }

                // Recorremos todos los items
                foreach ($items as $item) {
                    // Verificamos si el ID del producto ya existe en el carrito
                    if ($item['product_id'] == $product_id) {
                        $status = false;
                        break;
                    }
                }
            }
        }
    
        if ($status) {
          // Agregamos el producto al carrito
          // Podemos configurar mas parametros como la cantidad si se desea
          $cart_item_data = array('price' => $price);
          WC()->cart->add_to_cart($product_id, 1, '', array(), $cart_item_data);

          // Enviar respuesta JSON
          send_json_response(true, 'success', 'Producto agregado al carrito');
        } else {
          // Enviar respuesta JSON
          send_json_response(false, 'error', 'El producto ya existe en el carrito');
        }
    }
}

add_action( 'wp_ajax_ids_wc_add_category_all_to_cart', 'ids_wc_add_category_all_to_cart' );
add_action( 'wp_ajax_nopriv_ids_wc_add_category_all_to_cart', 'ids_wc_add_category_all_to_cart' );
