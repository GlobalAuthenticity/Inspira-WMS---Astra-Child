<?php

/**
 * Remover campos del formulario de checkout
 */
function wc_remove_checkout_fields( $fields ) {

  // Billing fields
  unset( $fields['billing']['billing_company'] );
  unset( $fields['billing']['billing_address_2'] );
  unset( $fields['billing']['billing_postcode'] );

  // Shipping fields
  unset( $fields['shipping']['shipping_company'] );
  unset( $fields['shipping']['shipping_phone'] );
  unset( $fields['shipping']['shipping_state'] );
  unset( $fields['shipping']['shipping_first_name'] );
  unset( $fields['shipping']['shipping_last_name'] );
  unset( $fields['shipping']['shipping_address_1'] );
  unset( $fields['shipping']['shipping_address_2'] );
  unset( $fields['shipping']['shipping_city'] );
  unset( $fields['shipping']['shipping_postcode'] );

  // Order fields
  unset( $fields['order']['order_comments'] );

  return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'wc_remove_checkout_fields' );

/**
 * Remover restricciones de campos obligatorios del formulario de checkout
 */
function wc_unrequire_checkout_fields( $fields ) {
  $fields['billing_company']['required'] = false;
  $fields['billing_postcode']['required'] = false;
  $fields['billing_address_2']['required'] = false;

  return $fields;
}
add_filter( 'woocommerce_billing_fields', 'wc_unrequire_checkout_fields');

/**
 * Cambiar labels y placeholders del formulario de checkout
 */
function custom_override_checkout_fields($fields) {
  $fields['billing']['billing_first_name']['label'] = 'Nombre'; 
  $fields['billing']['billing_last_name']['label'] = 'Apellidos';
  $fields['billing']['billing_email']['label'] = 'Correo electrónico';
  $fields['billing']['billing_phone']['label'] = 'Número de contacto';
  $fields['billing']['billing_country']['label'] = 'País';
  $fields['billing']['billing_address_1']['label'] = 'Dirección del domicilio';
  $fields['billing']['billing_city']['label'] = 'Ciudad';

  $fields['billing']['billing_first_name']['placeholder'] = 'Ingresa tu nombre'; 
  $fields['billing']['billing_last_name']['placeholder'] = 'Ingresa tus apellidos';
  $fields['billing']['billing_email']['placeholder'] = 'Ingresa tu correo electrónico';
  $fields['billing']['billing_phone']['placeholder'] = 'Ingresa tu número';
  $fields['billing']['billing_address_1']['placeholder'] = 'Ingresa calle, número y más detalles';
  $fields['billing']['billing_city']['placeholder'] = 'Ingresa tu ciudad';

  return $fields;
}
add_filter('woocommerce_checkout_fields', 'custom_override_checkout_fields');

/**
 * Remover los estilos generales de woocommerce.css
 */
// function wooc_dequeue_styles( $enqueue_styles ) {
//   unset( $enqueue_styles['woocommerce-general'] );
//   return $enqueue_styles;
// }
// add_filter( 'woocommerce_enqueue_styles', 'wooc_dequeue_styles' );
