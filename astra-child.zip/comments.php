<?php
/**
 * Comments template personalizado para Astra Child
 */

if (post_password_required()) {
    return;
}
?>

<div id="comments" class="comments-area comentarios-anonimos-wrap">

    <?php if (comments_open() || get_comments_number()) : ?>

        <?php comment_form(); ?>

        <?php if (have_comments()) : ?>
            <ol class="comment-list">
                <?php
                wp_list_comments(array(
                    'style'       => 'ol',
                    'short_ping'  => true,
                    'avatar_size' => 0,
                    'callback'    => 'tulua_comentario_anonimo_callback',
                    'max_depth'   => 3,
                ));
                ?>
            </ol>

            <?php the_comments_navigation(); ?>
        <?php endif; ?>

    <?php endif; ?>

</div>