<?php

/**
 * Función para enviar correo con enlace de resultados
 * 
 * results_url -> enlace para que el usuario pueda ver el resultado del test 
 * 
 * @return void.
 */
function send_results_email($user_email, $results_url) {
  // Establecemos el destinatario y el asunto
  $recipient = $user_email;
  $subject = __("¡Gracias por completar tu test!");
  
  // Obtenemos el HTML correspondiente
  $message = get_sitemadi_results_email($account_url);

  // Enviar el correo
  return send_email($recipient, $subject, $message);
}
