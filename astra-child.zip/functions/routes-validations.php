<?php

function verify_user_registered() {
  if (is_page('registro')) {
    // Verificar si hay un usuario logueado
    $user_id = get_current_user_id();
    
    // Si no hay usuario logueado, se mantiene el formulario de registro
    if ($user_id) {
      // Obtener el tipo de test 
      $test_type = "individual";
      if (isset($_GET['test-type'])) {
        $test_type = $_GET['test-type'];
      }

      wp_redirect(get_site_url() . '/test/?test-type=' . $test_type);
    }
  }
}

add_action('template_redirect', 'verify_user_registered');