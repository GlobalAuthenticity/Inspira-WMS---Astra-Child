<?php

/**
 * Verifica si un usuario tiene el rol empresa_admin.
 *
 * @param int $user_id
 * @return bool
 */
function ms_user_is_group_admin( $user_id ) {

    if ( empty($user_id) || ! is_numeric($user_id) ) {
        return false;
    }

    $user = get_userdata( $user_id );
    if ( ! $user ) {
        return false;
    }

    return in_array( 'empresa_admin', (array) $user->roles );
}


/**
 * Obtiene datos básicos del usuario.
 *
 * @param int $user_id
 * @return array|false
 */
function ms_get_user_detail( $user_id ) {

    $user = get_userdata( $user_id );
    if ( ! $user ) {
        return false;
    }

    $nombre_completo = trim(
        (string) $user->first_name . ' ' . (string) $user->last_name
    );

    return [
        'nombre'       => $nombre_completo,
        'display_name' => $user->display_name,
    ];
}


/**
 * Obtiene todas las áreas asociadas a un group_id.
 *
 * @param int $grupo_id
 * @return array
 */
function ms_get_areas_by_group( $grupo_id ) {
    global $wpdb;

    if ( ! $grupo_id ) {
        return [];
    }

    $table = $wpdb->prefix . 'areas';

    $results = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, nombre, fecha_expiracion
             FROM $table
             WHERE grupo_id = %d",
            $grupo_id
        ),
        ARRAY_A
    );

    if ( empty($results) ) {
        return [];
    }

    foreach ( $results as &$row ) {
        $row['fecha_expiracion'] =
            ! empty($row['fecha_expiracion'])
                ? date( 'd-m-Y', strtotime($row['fecha_expiracion']) )
                : null;
    }

    return $results;
}


/**
 * Obtiene el nombre (first_name) de la empresa/usuario administrador.
 *
 * @param int $user_id
 * @return string|null
 */
function ms_company_name( $user_id ) {
    if ( ! $user_id ) return null;

    $first_name = get_user_meta( $user_id, 'first_name', true );
    return $first_name ?: null;
}


/**
 * Obtiene los IDs de usuario asignados a un área.
 *
 * @param int $area_id
 * @return array
 */
function ms_get_area_user_ids( $area_id ) {
    global $wpdb;

    if ( ! $area_id ) {
        return [];
    }

    return $wpdb->get_col(
        $wpdb->prepare(
            "SELECT user_id FROM wp_user_members WHERE area_id = %d",
            $area_id
        )
    );
}


/**
 * Obtiene el progreso promedio de LearnDash para los usuarios de un área.
 *
 * @param int $area_id
 * @return float
 */
function ms_get_area_progress( $area_id ) {

    $user_ids = ms_get_area_user_ids( $area_id );

    if ( empty($user_ids) ) {
        return 0;
    }

    $total_users      = count($user_ids);
    $total_percentage = 0;

    foreach ( $user_ids as $user_id ) {

        $courses = learndash_user_get_enrolled_courses( $user_id );

        // Usuario sin cursos → 0%
        if ( empty($courses) ) {
            $total_percentage += 0;
            continue;
        }

        $course_sum   = 0;
        $course_count = 0;

        foreach ( $courses as $course_id ) {

            $progress = learndash_user_get_course_progress( $user_id, $course_id );
            $percentage = 0;

            if ( isset($progress['percentage']) ) {
                $percentage = floatval( $progress['percentage'] );

            } elseif ( isset($progress['completed'], $progress['total']) && $progress['total'] > 0 ) {
                $percentage = ( $progress['completed'] / $progress['total'] ) * 100;
            }

            $course_sum += $percentage;
            $course_count++;
        }

        $user_avg = $course_count > 0 ? $course_sum / $course_count : 0;
        $total_percentage += $user_avg;
    }

    return round( $total_percentage / $total_users, 2 );
}


/**
 * Obtiene el porcentaje de usuarios de un área que ya presentaron
 * el test, es decir, que tienen en wp_usermeta el meta_key
 * "question_test_ids" con un valor registrado.
 *
 * @param int $area_id
 * @return float
 */
function ms_get_area_test_percentage( $area_id ) {
    global $wpdb;

    $user_ids = ms_get_area_user_ids( $area_id );

    if ( empty($user_ids) ) {
        return 0;
    }

    $total_users = count($user_ids);

    $placeholders = implode( ',', array_fill( 0, count($user_ids), '%d' ) );

    // Usuarios distintos que tienen registrado el meta_key "question_test_ids"
    $completed_users = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT DISTINCT user_id
             FROM {$wpdb->usermeta}
             WHERE user_id IN ($placeholders)
               AND meta_key = %s
               AND meta_value != ''",
            array_merge( $user_ids, [ 'question_test_ids' ] )
        )
    );

    if ( empty($completed_users) ) {
        return 0;
    }

    return round( ( count($completed_users) / $total_users ) * 100, 2 );
}


/**
 * Shortcode: Detalle del grupo empresarial.
 *
 * @return string|null
 */
function ms_shortcode_group_detail() {

    $current_user = get_current_user_id();

    // Validación de permisos
    if ( ! ms_user_is_group_admin( $current_user ) ) {
        return null;
    }

    wp_enqueue_style(
        'membership-details-styles',
        get_stylesheet_directory_uri() . '/assets/css/membership-details.css',
        [],
        '1.0'
    );

    $company_name = ms_company_name( $current_user );
    $areas        = ms_get_areas_by_group( $current_user );

    ob_start();
    ?>

    <div class="membership-details">

        <div class="membership-details__header">
            <h3>Información General de la Empresa</h3>

            <div class="membership-details__tabs" role="tablist">
                <button type="button" class="membership-details__tab is-active" data-mdtab="test">
                    Test
                </button>
                <button type="button" class="membership-details__tab" data-mdtab="courses">
                    Cursos
                </button>
            </div>
        </div>

        <div class="membership-details__body">

            <!-- Información empresa -->
            <div class="membership-details__info">
                <div>
                    <span class="membership-details__subheading">Identificación de la Empresa</span>
                    <span class="membership-details__heading">
                        <?php echo esc_html( $company_name ); ?>
                    </span>
                </div>
            </div>

            <!-- Áreas -->
            <div class="membership_details__dependencies">

                <div class="membership_details__dependencies-header">
                    <span class="membership-details__subheading">Áreas</span>
                </div>

                <div class="membership_details__dependencies-body">
                    <?php // Cada área se muestra en su propia columna, con el nombre
                    // y el porcentaje en la misma fila y la barra completa debajo. ?>
                    <?php foreach ( $areas as $area ) :
                        $progress_cursos = ms_get_area_progress( $area['id'] );
                        $progress_test   = ms_get_area_test_percentage( $area['id'] );
                    ?>
                        <div class="membership-details__dependency">

                            <div class="membership-details__dependency-row">
                                <span class="membership-details__dependency-name">
                                    <?php echo esc_html( $area['nombre'] ); ?>
                                </span>
                                <span class="progress-bar__number"><?php echo esc_html( $progress_test ); ?>%</span>
                            </div>

                            <div class="progress-bar__container"
                                 data-test="<?php echo esc_attr( $progress_test ); ?>"
                                 data-cursos="<?php echo esc_attr( $progress_cursos ); ?>">
                                <div class="progress-bar">
                                    <div class="progress-bar__fill"
                                         style="width: <?php echo esc_attr( $progress_test ); ?>%;">
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endforeach; ?>
                </div>

            </div>

        </div>
    </div>

    <style>
    .membership-details {
        --md-navy:        #3A3154; /* morado oscuro, ancla de contraste (chips, tab activo) */
        --md-black-purple:#241E33; /* morado casi negro (footer / sombras) */
        --md-accent:      #B084F5; /* morado vibrante para la barra de progreso (sobre fondo claro) */
        --md-accent-soft: #E4D9FA; /* lavanda claro para detalles secundarios */
        --md-lavender-bg: #F4EEFC; /* fondo lavanda muy suave (track de barra y tabs) */
        --md-text:        #241E33; /* texto oscuro, alto contraste */
        --md-text-soft:   #E9E3F5; /* texto claro sobre fondos morados */
    }

    .membership-details__header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 16px;
    }

    /* Especificidad reforzada (.membership-details repetido) para ganarle
       en cascada a membership-details.css del tema, que pisaba estos
       colores y hacía que el texto y los porcentajes se perdieran. */
    .membership-details.membership-details .membership-details__header h3 {
        color: var(--md-text) !important;
    }

    .membership-details.membership-details .membership-details__subheading {
        color: var(--md-text-soft) !important;
        opacity: 0.85;
    }

    .membership-details.membership-details .membership-details__heading {
        color: #ffffff !important;
        font-weight: 700;
    }

    .membership-details.membership-details .membership-details__dependency-name {
        color: #ffffff !important;
    }

    /* Cada área ocupa su propia columna, con ancho suficiente para que
       el nombre y el porcentaje respiren (igual que en la referencia). */
    .membership-details.membership-details .membership_details__dependencies-body {
        display: flex;
        flex-wrap: wrap;
        gap: 28px 40px;
    }

    .membership-details.membership-details .membership-details__dependency {
        display: block !important;
        flex: 1 1 220px;
        min-width: 200px;
    }

    /* Fila: nombre del área a la izquierda, porcentaje a la derecha
       (mismo layout que la referencia). */
    .membership-details.membership-details .membership-details__dependency-row {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 8px;
    }

    .membership-details.membership-details .membership-details__tabs {
        display: inline-flex;
        align-items: center;
        background-color: var(--md-lavender-bg) !important; /* fondo lavanda claro del track */
        border-radius: 999px;
        padding: 4px;
        gap: 2px;
        position: relative;
    }

    .membership-details.membership-details .membership-details__tab {
        position: relative;
        z-index: 1;
        border: none !important;
        background: transparent !important;
        cursor: pointer;
        font-family: inherit;
        font-size: 14px;
        font-weight: 600;
        line-height: 1;
        padding: 10px 20px;
        border-radius: 999px;
        color: var(--md-navy) !important; /* texto inactivo oscuro, bien legible sobre el track claro */
        transition: background-color .25s ease, color .25s ease, transform .15s ease;
    }

    .membership-details.membership-details .membership-details__tab:hover:not(.is-active) {
        color: var(--md-accent) !important;
    }

    .membership-details.membership-details .membership-details__tab:active {
        transform: scale(0.96);
    }

    .membership-details.membership-details .membership-details__tab.is-active {
        background-color: var(--md-navy) !important; /* morado oscuro del botón activo */
        color: #ffffff !important;
        box-shadow: 0 2px 8px rgba(36, 30, 51, 0.4);
    }

    .membership-details.membership-details .progress-bar {
        background-color: var(--md-lavender-bg) !important;
        border-radius: 999px;
        overflow: hidden;
    }

    .membership-details.membership-details .progress-bar__fill {
        background-color: var(--md-accent) !important; /* morado vibrante, bien visible sobre el track claro */
        border-radius: 999px;
        min-width: 6px; /* para que se note incluso en porcentajes bajos */
        transition: width .5s ease; /* transición visible al cambiar de tab */
    }

    /* Porcentaje como texto simple en negrita, sin fondo tipo "chip",
       igual al de la imagen de referencia (tamaño más grande para que
       destaque frente al nombre del área). */
    .membership-details.membership-details .progress-bar__number {
        color: #ffffff !important;
        font-size: 18px;
        font-weight: 700;
        line-height: 1;
        white-space: nowrap;
    }

    .membership-details.membership-details .membership-details__dependency-name {
        font-size: 15px;
        font-weight: 500;
    }

    .membership-details.membership-details .progress-bar__container {
        display: block !important;
        width: 100% !important;
    }

    .membership-details.membership-details .progress-bar {
        display: block !important;
        width: 100% !important;
        height: 8px;
    }
    </style>

    <script>
    (function () {
        document.querySelectorAll('.membership-details__tabs').forEach(function (tabsEl) {
            var wrapper = tabsEl.closest('.membership-details');
            if (!wrapper) return;

            tabsEl.addEventListener('click', function (e) {
                var btn = e.target.closest('.membership-details__tab');
                if (!btn) return;

                var tab = btn.dataset.mdtab; // "test" | "courses"
                var dataKey = (tab === 'courses') ? 'cursos' : 'test';

                tabsEl.querySelectorAll('.membership-details__tab').forEach(function (b) {
                    b.classList.toggle('is-active', b === btn);
                });

                wrapper.querySelectorAll('.membership-details__dependency').forEach(function (dep) {
                    var bar = dep.querySelector('.progress-bar__container');
                    if (!bar) return;

                    var value = parseFloat(bar.dataset[dataKey] || '0');
                    var fill = bar.querySelector('.progress-bar__fill');
                    var number = dep.querySelector('.progress-bar__number');

                    if (fill) fill.style.width = value + '%';
                    if (number) number.textContent = value + '%';
                });
            });
        });
    })();
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode( 'group_detail', 'ms_shortcode_group_detail' );
