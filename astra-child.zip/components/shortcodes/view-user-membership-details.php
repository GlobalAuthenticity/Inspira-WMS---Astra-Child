<?php

// ─────────────────────────────────────────────
// Helper: último registro de membresía del usuario
// ─────────────────────────────────────────────
function ultima_fecha_membresia( $user_id ) {
    global $wpdb;

    $user_id = absint( $user_id );
    if ( ! $user_id ) return null;

    $registro = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}user_members
             WHERE user_id = %d
             ORDER BY id DESC LIMIT 1",
            $user_id
        )
    );

    return $registro;
}

// ─────────────────────────────────────────────
// Helper: fecha en texto natural español
// ─────────────────────────────────────────────
function fecha_a_texto_natural( $fecha_string ) {
    $fecha = DateTime::createFromFormat( 'Y-m-d', $fecha_string )
          ?: DateTime::createFromFormat( 'd-m-Y', $fecha_string );

    if ( ! $fecha ) return 'Fecha inválida';

    $meses = [
        'January' => 'enero', 'February' => 'febrero', 'March'    => 'marzo',
        'April'   => 'abril', 'May'      => 'mayo',    'June'     => 'junio',
        'July'    => 'julio', 'August'   => 'agosto',  'September'=> 'septiembre',
        'October' => 'octubre','November'=> 'noviembre','December' => 'diciembre',
    ];

    $mes_en = $fecha->format( 'F' );
    return $fecha->format( 'd' ) . ' de ' . ( $meses[ $mes_en ] ?? $mes_en ) . ' de ' . $fecha->format( 'Y' );
}

// ─────────────────────────────────────────────
// Shortcode principal
// ─────────────────────────────────────────────
function view_user_membership_details() {

    if ( ! is_user_logged_in() ) return '';

    $user  = wp_get_current_user();
    $roles = (array) $user->roles;

    // 🔐 Solo visible para suscriptores
    if ( ! in_array( 'subscriber', $roles ) ) return '';

    $user_id        = $user->ID;
    $membresia_data = ultima_fecha_membresia( $user_id );

    if ( ! $membresia_data ) return '';

    $fecha_expira     = fecha_a_texto_natural( $membresia_data->fecha_final_membresia );
    $estado_membresia = $membresia_data->status;

    // ── CSS compartido ────────────────────────
    ob_start(); ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');

        .aprob-wrap {
            font-family: 'DM Sans', sans-serif;
            width: 100%;
            box-sizing: border-box;
        }

        /* ── Card base ── */
        .aprob-card {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 13px 20px;
            border-radius: 10px;
            border: 1.5px solid transparent;
            position: relative;
            overflow: hidden;
            box-sizing: border-box;
        }

        /* ── Punto de estado ── */
        .aprob-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            flex-shrink: 0;
        }

        /* ── Label principal ── */
        .aprob-label {
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.9px;
            text-transform: uppercase;
            white-space: nowrap;
            flex-shrink: 0;
        }

        /* ── Separador vertical ── */
        .aprob-sep {
            width: 1px;
            height: 16px;
            flex-shrink: 0;
            opacity: 0.35;
            margin: 0 2px;
        }

        /* ── Texto secundario ── */
        .aprob-meta {
            font-size: 12px;
            font-weight: 400;
            opacity: 0.75;
            white-space: nowrap;
            flex-shrink: 0;
        }

        /* ── Valor destacado ── */
        .aprob-value {
            font-size: 13px;
            font-weight: 600;
            white-space: nowrap;
        }

        /* ── Descripción larga ── */
        .aprob-desc {
            font-size: 13px;
            font-weight: 400;
            line-height: 1.55;
            flex: 1;
            min-width: 0;
        }

        /* ── Botón ── */
        .aprob-btn {
            display: inline-block;
            padding: 9px 22px;
            border-radius: 6px;
            font-family: 'DM Sans', sans-serif;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none !important;
            white-space: nowrap;
            flex-shrink: 0;
            letter-spacing: 0.2px;
        }

        /* ═══════════════════════════════
           TEST PENDIENTE — ámbar suave
        ═══════════════════════════════ */
        .aprob-card--pending {
            background-color: #FFFBF0;
            border-color: #F0D080;
        }
        .aprob-card--pending .aprob-dot   { background: #D97706; }
        .aprob-card--pending .aprob-label { color: #92600A; }
        .aprob-card--pending .aprob-sep   { background: #D97706; }
        .aprob-card--pending .aprob-desc  { color: #7A5010; }
        .aprob-card--pending .aprob-btn   { background: #D97706; color: #fff !important; }

        /* ═══════════════════════════════
           MEMBRESÍA ACTIVA — verde
        ═══════════════════════════════ */
        .aprob-card--active {
            background-color: #F2FAF5;
            border-color: #A8D8B8;
        }
        .aprob-card--active .aprob-dot {
            background: #2E9E5B;
            box-shadow: 0 0 0 2px rgba(46,158,91,0.2);
            animation: aprob-pulse-green 2s infinite;
        }
        .aprob-card--active .aprob-label { color: #1A6B3C; }
        .aprob-card--active .aprob-sep   { background: #2E9E5B; }
        .aprob-card--active .aprob-meta  { color: #2E9E5B; }
        .aprob-card--active .aprob-value { color: #1A6B3C; }

        @keyframes aprob-pulse-green {
            0%, 100% { box-shadow: 0 0 0 2px rgba(46,158,91,0.20); }
            50%       { box-shadow: 0 0 0 5px rgba(46,158,91,0.08); }
        }

        /* ═══════════════════════════════
           MEMBRESÍA SUSPENDIDA — rojo
        ═══════════════════════════════ */
        .aprob-card--suspended {
            background-color: #FFF5F5;
            border-color: #F0B8B8;
        }
        .aprob-card--suspended .aprob-dot {
            background: #C0392B;
            box-shadow: 0 0 0 2px rgba(192,57,43,0.2);
            animation: aprob-pulse-red 2s infinite;
        }
        .aprob-card--suspended .aprob-label { color: #922020; }
        .aprob-card--suspended .aprob-sep   { background: #C0392B; }
        .aprob-card--suspended .aprob-desc  { color: #7A2020; }

        @keyframes aprob-pulse-red {
            0%, 100% { box-shadow: 0 0 0 2px rgba(192,57,43,0.20); }
            50%       { box-shadow: 0 0 0 5px rgba(192,57,43,0.08); }
        }

        /* ── Responsive ── */
        @media (max-width: 520px) {
            .aprob-card {
                flex-wrap: wrap;
                gap: 8px;
                padding: 12px 16px;
            }
            .aprob-sep   { display: none; }
            .aprob-label { flex-basis: 100%; }
            .aprob-value,
            .aprob-meta,
            .aprob-desc  { white-space: normal; word-break: break-word; }
            .aprob-btn   { width: 100%; text-align: center; margin-top: 4px; }
        }
    </style>
    <?php
    $styles = ob_get_clean();

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // VISTA A: Membresía activa
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if ( $estado_membresia === 'ACTIVO' ) {

        $question_test_ids = get_user_meta( $user_id, 'question_test_ids', true );

        // ── A1: Test pendiente ───────────────
        if ( empty( $question_test_ids ) ) {
            ob_start();
            echo $styles;
            ?>
            <div class="aprob-wrap">
                <div class="aprob-card aprob-card--pending">
                    <span class="aprob-dot"></span>
                    <span class="aprob-label">Test pendiente</span>
                    <span class="aprob-sep"></span>
                    <span class="aprob-desc">
                        Tu test de <strong>INSPIRA</strong> aún está pendiente. Complétalo para desbloquear el acceso a tu programa.
                    </span>
                    <a href="<?php echo esc_url( get_site_url() . '/test/?test-type=individual' ); ?>" class="aprob-btn">
                        Realizar test
                    </a>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        // ── A2: Membresía activa con test ────
        ob_start();
        echo $styles;
        ?>
        <div class="aprob-wrap">
            <div class="aprob-card aprob-card--active">
                <span class="aprob-dot"></span>
                <span class="aprob-label">Membresía activa</span>
                <span class="aprob-sep"></span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style="flex-shrink:0; opacity:0.6;">
                    <rect x="3" y="4" width="18" height="17" rx="3" stroke="#2E9E5B" stroke-width="1.8"/>
                    <path d="M3 9h18" stroke="#2E9E5B" stroke-width="1.8"/>
                    <path d="M8 2v3M16 2v3" stroke="#2E9E5B" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
                <span class="aprob-meta">Vence:</span>
                <span class="aprob-value"><?php echo esc_html( $fecha_expira ); ?></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // VISTA B: Membresía suspendida / inactiva
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ob_start();
    echo $styles;
    ?>
    <div class="aprob-wrap">
        <div class="aprob-card aprob-card--suspended">
            <span class="aprob-dot"></span>
            <span class="aprob-label">Membresía suspendida</span>
            <span class="aprob-sep"></span>
            <span class="aprob-desc">
                Tu acceso ha finalizado o está suspendido. Contacta al administrador para reactivarlo.
            </span>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode( 'view-user-membership-details', 'view_user_membership_details' );