<?php
add_shortcode('custom_forgot_password', 'custom_forgot_password_shortcode');
function custom_forgot_password_shortcode()
{
    if (isset($_POST['fp_email'])) {

        $email = sanitize_email($_POST['fp_email']);
        $user  = get_user_by('email', $email);

        if (!$user) {
            return '<p style="color:red;">No existe una cuenta con ese correo.</p>';
        }

        // Generar token
        $token = wp_generate_password(20, false);
        update_user_meta($user->ID, 'reset_password_token', $token);
        update_user_meta($user->ID, 'reset_password_expire', time() + 3600); // 1 hora

        // URL custom
        $reset_url = add_query_arg([
            'token' => $token,
            'uid'   => $user->ID,
        ], site_url('/restablecer-password'));

        // Forzar envío HTML
        add_filter('wp_mail_content_type', function () {
            return 'text/html';
        });

        $subject = 'Restablecer tu contraseña';

        // ===== EMAIL HTML =====
        $message = '
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<style>
@media only screen and (max-width:480px){
  .container{width:100%!important;border-radius:0!important}
  .content{padding:20px!important}
  h1{font-size:22px!important}
  p{font-size:14px!important}
  .btn{font-size:14px!important;padding:12px 18px!important}
}
</style>
</head>
<body style="margin:0;padding:0;background:#f2f2f2;font-family:Arial,Helvetica,sans-serif">

<table role="presentation" width="100%" cellspacing="0" cellpadding="0">
<tr>
<td align="center">

<table class="container" width="600" style="max-width:600px;background:#ffffff;border-radius:22px;overflow:hidden" cellspacing="0" cellpadding="0">

<!-- HEADER -->
<tr>
<td style="padding:24px 24px 8px;text-align:left">
<img src="http://aprobandome.com/wp-content/uploads/2025/12/Compras-Emails-Aprobandome.png" width="170" alt="Aprobándome" style="display:block;border:0">
</td>
</tr>

<!-- HERO -->
<tr>
<td align="center" style="padding:10px 24px 24px">
<img src="http://aprobandome.com/wp-content/uploads/2025/12/recuperar-contrasena.png" width="100%" style="max-width:360px;border-radius:26px;display:block" alt="Recuperar contraseña">
</td>
</tr>

<!-- CONTENIDO -->
<tr>
<td class="content" style="padding:0 32px 32px;color:#222;text-align:left">
<h1 style="margin:0 0 16px;font-size:28px;font-weight:bold">
Restablecer contraseña
</h1>

<p style="margin:0 0 16px;font-size:16px;line-height:1.6">
Hola <strong>' . esc_html($user->display_name) . '</strong>, recibimos una solicitud para restablecer la contraseña de tu cuenta en Aprobándome.
</p>

<p style="margin:0 0 24px;font-size:16px;line-height:1.6">
Si fuiste tú quien la solicitó, haz clic en el botón de abajo para crear una nueva contraseña.
</p>

<a href="' . esc_url($reset_url) . '" target="_blank" rel="noopener"
class="btn"
style="display:inline-block;background:#000;color:#fff;text-decoration:none;font-size:16px;padding:14px 26px;border-radius:30px">
Restablecer contraseña
</a>

<p style="margin:24px 0 0;font-size:14px;line-height:1.6;color:#555">
Este enlace expira en 1 hora.  
Si no solicitaste este cambio, puedes ignorar este correo con total tranquilidad.
</p>
</td>
</tr>

<!-- FOOTER -->
<tr>
<td style="background:#2e2b3a;padding:32px;color:#e6e6e6">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
<td valign="top" style="padding-bottom:20px">
<strong style="font-size:16px;color:#fff">Contacto</strong><br>
<span style="font-size:14px;line-height:1.6">
Cra. 14A #101-11<br>
Oficina 403<br>
Bogotá – Colombia<br>
<a href="mailto:info@aprobandome.com" style="color:#e6e6e6;text-decoration:none">
info@aprobandome.com
</a>
</span>
</td>

<td valign="top" style="padding-bottom:20px">
<strong style="font-size:16px;color:#fff">Síguenos</strong><br><br>
<a href="https://www.instagram.com/aprobandome" target="_blank">
<img src="https://aprobandome.com/wp-content/uploads/2025/12/Icon.png" width="24" style="border:0">
</a>
</td>

<td valign="top">
<strong style="font-size:16px;color:#fff">Grupo empresarial</strong><br>
<span style="font-size:14px;line-height:1.8">
<a href="https://efrenmartinezortiz.com/" target="_blank" style="color:#e6e6e6;text-decoration:none">Dr. Efren Martínez Ortiz</a><br>
<a href="https://wmslatam.com/" target="_blank" style="color:#e6e6e6;text-decoration:none">WMS</a><br>
<a href="https://terapiaunclick.com/" target="_blank" style="color:#e6e6e6;text-decoration:none">TClick</a><br>
<a href="https://colectivoaquiyahora.org/" target="_blank" style="color:#e6e6e6;text-decoration:none">Colectivo Aquí y Ahora</a><br>
<a href="https://saps-col.org/" target="_blank" style="color:#e6e6e6;text-decoration:none">SAPS</a>
</span>
</td>
</tr>
</table>

<p style="font-size:12px;color:#aaa;text-align:center;margin-top:24px">
© 2026 IDS. Todos los derechos reservados
</p>
</td>
</tr>

</table>

</td>
</tr>
</table>

</body>
</html>';

        wp_mail($email, $subject, $message);

        // Limpiar filtro
        remove_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');

        return '<p style="color:green;">Revisa tu correo para continuar con el proceso.</p>';
    }

    return '
    <form method="post">
        <label>Correo electrónico</label><br>
        <input type="email" name="fp_email" required>
        <br><br>
        <button type="submit">Recuperar contraseña</button>
    </form>
    ';
}
