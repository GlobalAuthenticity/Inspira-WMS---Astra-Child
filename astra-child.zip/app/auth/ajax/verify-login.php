<?php

/**
 * @description
 * Valida si el usuario se encuentra logueado
 */
if (!function_exists('is_user_logged_in')) {
  function is_user_logged_in() {
    if (defined( 'DOING_AJAX' ) && DOING_AJAX) {
      $user_id = get_current_user_id();
      
      echo json_encode($user_id);
      unset($_POST);
    }

    wp_die();
  }
}

// Ajax
add_action('wp_ajax_nopriv_is_user_logged_in', 'is_user_logged_in');
add_action('wp_ajax_is_user_logged_in', 'is_user_logged_in');