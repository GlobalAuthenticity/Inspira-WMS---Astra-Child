<?php

function couples_report_content_table_function() {
  if(!is_admin()) {
    wp_enqueue_style( 'content-table-styles', get_stylesheet_directory_uri() . '/components/shortcodes/report-content-table.css' );
    ob_start();
    ?>
      <div class="sistemadi-content-table">
        <a href="/mi-cuenta/resultados"
           style="display: flex; align-items: center; gap: 16px; text-decoration: none; margin-bottom: 32px; color: #000;"
        >
          <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/07/Arrow-left.svg">
          <span>Volver a resultados</span>
        </a>

        <ul class="sistemadi-content-table__items">
          <li class="sistemadi-content-table__item">
            <a href="#introduccion">Introducción</a>
          </li>

          <li class="sistemadi-content-table__item">
            <a href="#instrucciones">Instrucciones de uso</a>
          </li>

          <li class="sistemadi-content-table__item">
            <a href="#estrategias">Estrategias</a>
          </li>

          <li class="sistemadi-content-table__item">
            <a href="#amenazas">Amenazas</a>
          </li>

          <li class="sistemadi-content-table__item">
            <a href="#dolores">Dolores</a>
          </li>
        </ul>
      </div>
    <?php

    return ob_get_clean();
  }

  return;
}

add_shortcode('couples-report-content-table', 'couples_report_content_table_function');
