<p>&nbsp;</p>
<p>&nbsp;</p>
<p>@media only screen and (max-width:480px){ .container{width:100%!important;border-radius:0!important} .content{padding:20px!important} h1{font-size:22px!important} p{font-size:14px!important} .btn{font-size:14px!important;padding:12px 18px!important} }</p>
<table role="presentation" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center">
<table class="container" style="max-width: 600px;background: #ffffff;border-radius: 22px;overflow: hidden" role="presentation" width="600" cellspacing="0" cellpadding="0"><!-- HEADER -->
<tbody>
<tr>
<td style="padding: 24px 24px 8px;text-align: left"><img style="display: block;border: 0" src="http://aprobandome.com/wp-content/uploads/2025/12/Compras-Emails-Aprobandome.png" alt="Aprobándome" width="170" /></td>
</tr>
<!-- HERO -->
<tr>
<td style="padding: 10px 24px 24px" align="center"><img style="max-width: 360px;border-radius: 26px;display: block" src="http://aprobandome.com/wp-content/uploads/2025/12/recuperar-contrasena.png" alt="Recuperar contraseña" width="100%" /></td>
</tr>
<!-- CONTENIDO -->
<tr>
<td class="content" style="padding: 0 32px 32px;text-align: left;color: #222">
<h1 style="margin: 0 0 16px;font-size: 28px;font-weight: bold">Restablecer contraseña</h1>
<p style="margin: 0 0 16px;font-size: 16px;line-height: 1.6">Recibimos una solicitud para restablecer la contraseña de tu cuenta en Aprobándome.</p>
<p style="margin: 0 0 24px;font-size: 16px;line-height: 1.6">Si fuiste tú quien la solicitó, haz clic en el botón de abajo para crear una nueva contraseña.</p>
<a class="btn" style="display: inline-block;background: #000;color: #fff;text-decoration: none;font-size: 16px;padding: 14px 26px;border-radius: 30px" href="{password_reset_link}" target="_blank" rel="noopener"> Restablecer contraseña </a>
<p style="margin: 24px 0 0;font-size: 14px;line-height: 1.6;color: #555">Si no solicitaste este cambio, puedes ignorar este correo con total tranquilidad.</p>
</td>
</tr>
<!-- FOOTER -->
<tr>
<td style="background: #2e2b3a;padding: 32px;color: #e6e6e6">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding-bottom: 20px" valign="top"><strong style="font-size: 16px;color: #fff">Contacto</strong><br /><span style="font-size: 14px;line-height: 1.6">848 Brickell ave st 950<br />Miami – Florida<br /><a style="color: #e6e6e6;text-decoration: none" href="mailto:info@aprobandome.com"> info@aprobandome.com </a> </span></td>
<td style="padding-bottom: 20px" valign="top"><strong style="font-size: 16px;color: #fff">Síguenos</strong><br /><br /><a style="margin-right: 14px" href="https://www.instagram.com/aprobandome" target="_blank" rel="noopener"> <img style="display: inline-block;border: 0" src="https://aprobandome.com/wp-content/uploads/2025/12/Icon.png" width="24" /> </a></td>
<td valign="top"><strong style="font-size: 16px;color: #fff">Grupo empresarial</strong><br /><span style="font-size: 14px;line-height: 1.8"> <a style="color: #e6e6e6;text-decoration: none" href="https://efrenmartinezortiz.com/" target="_blank" rel="noopener"> Dr. Efren Martínez Ortiz </a><br /><a style="color: #e6e6e6;text-decoration: none" href="https://wmslatam.com/" target="_blank" rel="noopener"> WMS </a><br /><a style="color: #e6e6e6;text-decoration: none" href="https://terapiaunclick.com/" target="_blank" rel="noopener"> TClick </a><br /><a style="color: #e6e6e6;text-decoration: none" href="https://colectivoaquiyahora.org/" target="_blank" rel="noopener"> Colectivo Aquí y Ahora </a><br /><a style="color: #e6e6e6;text-decoration: none" href="https://saps-col.org/" target="_blank" rel="noopener"> SAPS </a> </span></td>
</tr>
</tbody>
</table>
<p style="font-size: 12px;color: #aaa;text-align: center;margin-top: 24px">© 2026 IDS. Todos los derechos reservados</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>