<?php
/**
 * Bloquea aplicar más de 1 cupón si el carrito contiene un producto específico.
 */
add_filter('woocommerce_coupon_is_valid', function ($is_valid, $coupon, $discount) {
    
    if (!$is_valid || !WC()->cart) {
        return $is_valid;
    }

    $target_product_id = 797; // ID del producto a proteger
    $applied_coupons = WC()->cart->get_applied_coupons();
    
    // Verificar si ya hay cupones aplicados y si es uno diferente
    if (empty($applied_coupons) || in_array($coupon->get_code(), $applied_coupons, true)) {
        return $is_valid;
    }

    // Verificar si el producto objetivo está en el carrito
    foreach (WC()->cart->get_cart() as $item) {
        if (in_array($target_product_id, [$item['product_id'] ?? 0, $item['variation_id'] ?? 0], true)) {
            wc_add_notice(
                __('Para este producto solo se permite aplicar un cupón por compra.', 'your-textdomain'),
                'error'
            );
            return false;
        }
    }

    return $is_valid;

}, 10, 3);
