<?php

/**
 * Función para enviar correo con enlace de bienvenida al curso.
 * 
 * @param string $user_email Correo del usuario.
 * @param string $account_url URL donde el usuario puede acceder a su cuenta.
 * 
 * @return void.
 */
function send_course_email($user_email, $account_url) {
    // Establecemos el destinatario y el asunto
    $recipient = $user_email;
    $subject = __("¡Bienvenido! Tu curso ya está disponible");

    // Obtenemos el HTML correspondiente
    $message = get_sitemadi_course_email();

    // Enviar el correo
    return send_email($recipient, $subject, $message);
}
?>
