<?php

add_action('rest_api_init', function () {
    register_rest_route('aprobandome/v1', '/actualizar-area', [
        'methods'  => 'POST',
        'callback' => 'aprobandome_actualizar_area_y_miembros',
        'permission_callback' => 'aprobandome_api_update_area_check_token'
    ]);
});

function aprobandome_api_update_area_check_token( WP_REST_Request $request ) {

    $auth_header = $request->get_header('authorization');

    if ( ! $auth_header || ! str_starts_with($auth_header, 'Bearer ') ) {
        return new WP_Error(
            'unauthorized',
            'Missing Authorization header',
            ['status' => 401]
        );
    }

    $token_received = trim(str_replace('Bearer', '', $auth_header));
    $valid_token    = get_option('aprobandome_update_area');

    if ( ! hash_equals($valid_token, $token_received) ) {
        return new WP_Error(
            'unauthorized',
            'Invalid API token',
            ['status' => 403]
        );
    }

    return true;
}

function aprobandome_actualizar_area_y_miembros(WP_REST_Request $request) {
    global $wpdb;

    $area_id          = intval($request->get_param('area_id'));
    $fecha_expiracion = sanitize_text_field($request->get_param('fecha_expiracion'));

    if (!$area_id || !$fecha_expiracion) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'area_id y fecha_expiracion son obligatorios'
        ], 400);
    }

    // Validar formato de fecha YYYY-MM-DD
    $date = DateTime::createFromFormat('Y-m-d', $fecha_expiracion);
    if (!$date) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Formato de fecha inválido. Use YYYY-MM-DD'
        ], 400);
    }

    $tabla_areas        = $wpdb->prefix . 'areas';
    $tabla_user_members = $wpdb->prefix . 'user_members';
    $tabla_users        = $wpdb->prefix . 'users';

    // 1️⃣ Verificar que el área existe
    $area = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $tabla_areas WHERE id = %d", $area_id)
    );

    if (!$area) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Área no encontrada'
        ], 404);
    }

    // 2️⃣ Obtener user_id afectados (ANTES del update)
    $user_ids = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT DISTINCT user_id FROM $tabla_user_members WHERE area_id = %d",
            $area_id
        )
    );

    // 3️⃣ Actualizar fecha_expiracion en wp_areas
    $wpdb->update(
        $tabla_areas,
        ['fecha_expiracion' => $fecha_expiracion],
        ['id' => $area_id],
        ['%s'],
        ['%d']
    );

    // Convertir fecha a dd-mm-yyyy
    $fecha_formateada = $date->format('d-m-Y');

    // 4️⃣ Actualizar user_members
    $registros_actualizados = 0;
    if (!empty($user_ids)) {
        $registros_actualizados = $wpdb->update(
            $tabla_user_members,
            [
                'status' => 'ACTIVO',
                'fecha_final_membresia' => $fecha_formateada
            ],
            ['area_id' => $area_id],
            ['%s', '%s'],
            ['%d']
        );
    }

    // 5️⃣ Obtener correos de los usuarios afectados
    $emails = [];

    if (!empty($user_ids)) {
        $placeholders = implode(',', array_fill(0, count($user_ids), '%d'));

        $emails = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT user_email FROM $tabla_users WHERE ID IN ($placeholders)",
                $user_ids
            )
        );
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Área y miembros actualizados correctamente',
        'area_id' => $area_id,
        'fecha_expiracion' => $fecha_expiracion,
        'fecha_final_membresia' => $fecha_formateada,
        'registros_actualizados' => $registros_actualizados,
        'emails_usuarios' => $emails
    ], 200);
}
