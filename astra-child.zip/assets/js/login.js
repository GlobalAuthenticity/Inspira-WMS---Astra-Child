jQuery(document).ready(function($) {
    const pageLogin = 'page-id-737';

    if($('body').hasClass(pageLogin)) {
        $('#sistemadi-login-form').on('submit', function(e) {
            e.preventDefault();
            $('.sistemadi-submit-button').attr('disabled', true);

            let errors = [];
            const emailRegexValidation = /^\S+@\S+\.\S+$/;

            const email = $('#sistemadi-email').val();
            const password = $('#sistemadi-password').val();

            if(!email) {
                errors.push({email: 'El campo de correo electrónico es obligatorio.'});
                handleErrors(errors);
                return;
            }

            if(!emailRegexValidation.test(email)) {
                errors.push({email: 'El formato del correo electrónico no es válido.'});
                handleErrors(errors);
                return;
            }

            if(!password) {
                errors.push({password: 'El campo de contraseña es obligatorio.'});
                handleErrors(errors);
                return;
            }

            $.ajax({
                url: code_scripts.ajaxurl,
                method: 'POST',
                data: {
                    action: 'custom_login',
                    email: email,
                    password: password,
                },
                success: function(response) {
                    const res = JSON.parse(response);
                    console.log(res);

                    if(!res.success) {
                        errors = [];
                        errors.push({login: res['message']});
                        handleErrors(errors);
                        return;
                    }
                    
                    // Redireccionar
                    window.location.href = res['data']['redirect_url'];
                },
                error: function() {
                    // Manejar errores de inicio de sesión y mostrarlos en el contenedor de errores
                    errors = [];
                    errors.push({login: 'Error al procesar la solicitud. Por favor, inténtalo de nuevo más tarde.'});
                    handleErrors(errors);
                    return;
                },
                complete: function() {
                    $('.sistemadi-submit-button').attr('disabled', false);
                }
            });
        });

        function handleErrors(errors) {
            let errorMessages = '';
            errors.forEach(error => {
                for (const key in error) {
                    if (error.hasOwnProperty(key)) {
                        errorMessages += `<p class="sistemadi-auth-error-message">&bull; ${error[key]}</p>`;
                    }
                }
            });
            $('#sistemadi-error-messages').html(errorMessages).show();
            $('.sistemadi-submit-button').attr('disabled', false);
        }
    
        function clearErrors() {
            $('#sistemadi-error-messages').html('').hide();
        }
    
        $('.sistemadi-password-toggle').on('click', function() { 
            const passwordInput = $('#sistemadi-password');
            const type = passwordInput.attr('type') === 'password' ? 'text' : 'password';
            passwordInput.attr('type', type);
        });
    
        $('#sistemadi-email, #sistemadi-password').on('input', function() {
            clearErrors();
        })
    }
});