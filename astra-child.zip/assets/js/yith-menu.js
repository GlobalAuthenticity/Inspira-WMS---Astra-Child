jQuery(document).ready(function($) {
  const pageMyAccount = 'page-id-1049';

  if ($('body').hasClass(pageMyAccount)) {
    $( ".yith-item-disabled, .yith-item-disabled a" ).css({
      "opacity": "0.4",
      "cursor": "not-allowed"
    });

    // Deshabilitar elementos del menú
    $( ".yith-item-disabled a" ).on('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
    });

    // Remover elementos del menú a los que el usuario no tiene acceso
    $( ".yith-item-hide").remove();
  }
});