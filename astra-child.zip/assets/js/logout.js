jQuery(document).ready(function($) {
    const pageLogout = 'page-id-740';
    const pageRegister = 'page-id-738';

    /**
       * @description
       * Sí se encuentra en la página de cerrar sesión, borrar el localstorage, las cookies y redirecciona.
      */
    if($('body').hasClass(pageLogout)) {
        $.ajax({
            url: code_scripts.ajaxurl,
            method: 'POST',
            data: {
                action: 'custom_logout',
            },
            success: function() {
                // Limpiar localStorage
                localStorage.removeItem('quiz-1');
                localStorage.removeItem('result');
                localStorage.removeItem('couples-result');

                // Limpiar cookies
                const cookies = document.cookie.split(";");
                cookies.forEach(cookie => {
                    const name = cookie.split("=")[0].trim();
                    document.cookie = `${name}=; Expires=Thu, 01 Jan 1970 00:00:00 UTC; Path=/;`;
                });

                // Redireccionar
                setTimeout(() => {
                    window.location.href = 'https://wmslatam.com';
                }, 3000);
            },
            error: function(err) {
                console.error('Error al cerrar sesión:', err);
            }
        });
    }
});