<?php

/*
add_shortcode('custom_reset_password', 'custom_reset_password_shortcode');
function custom_reset_password_shortcode()
{
    if (!isset($_GET['token'], $_GET['uid'])) {
        return '<p style="color:red;">Enlace inválido.</p>';
    }

    $user_id = intval($_GET['uid']);
    $token   = sanitize_text_field($_GET['token']);

    $saved_token  = get_user_meta($user_id, 'reset_password_token', true);
    $expire_time  = get_user_meta($user_id, 'reset_password_expire', true);

    if ($token !== $saved_token || time() > $expire_time) {
        return '<p style="color:red;">El enlace es inválido o ha expirado.</p>';
    }

    if (isset($_POST['new_pass'], $_POST['confirm_pass'])) {

        if ($_POST['new_pass'] !== $_POST['confirm_pass']) {
            return '<p style="color:red;">Las contraseñas no coinciden.</p>';
        }

        wp_set_password($_POST['new_pass'], $user_id);

        delete_user_meta($user_id, 'reset_password_token');
        delete_user_meta($user_id, 'reset_password_expire');

        $redirect_url = 'https://aprobandome.com/login/';
        $seconds = 4; // cambia a los segundos que quieras

        return '
        <div style="padding:14px 16px; border:1px solid #cfe8d5; background:#eefaf1; color:#1f6b2e; border-radius:8px; font-weight:600;">
            Contraseña actualizada correctamente. En ' . intval($seconds) . ' segundos serás redirigido al login...
        </div>
        <script>
            setTimeout(function () {
            window.location.href = ' . json_encode($redirect_url) . ';
            }, ' . (intval($seconds) * 1000) . ');
        </script>
        ';
    }  

    

    return '
    <form method="post">
        <label>Nueva contraseña</label><br>
        <input type="password" name="new_pass" required>
        <br><br>

        <label>Confirmar contraseña</label><br>
        <input type="password" name="confirm_pass" required>
        <br><br>

        <button type="submit">Cambiar contraseña</button>
    </form>
    ';
}
 */

add_shortcode('custom_reset_password', 'custom_reset_password_shortcode');
function custom_reset_password_shortcode() {

    if (!isset($_GET['token'], $_GET['uid'])) {
        return '<p style="color:red;">Enlace inválido.</p>';
    }

    $user_id = intval($_GET['uid']);
    $token   = sanitize_text_field($_GET['token']);

    $saved_token = get_user_meta($user_id, 'reset_password_token', true);
    $expire_time = get_user_meta($user_id, 'reset_password_expire', true);

    if ($token !== $saved_token || time() > intval($expire_time)) {
        return '<p style="color:red;">El enlace es inválido o ha expirado.</p>';
    }

    $error = '';

    if (isset($_POST['new_pass'], $_POST['confirm_pass'])) {

        // Nonce check (evita CSRF)
        if ( ! isset($_POST['_wpnonce_custom_reset']) || ! wp_verify_nonce($_POST['_wpnonce_custom_reset'], 'custom_reset_password') ) {
            return '<p style="color:red;">Sesión inválida. Recarga la página e inténtalo de nuevo.</p>';
        }

        $new_pass     = (string) $_POST['new_pass'];
        $confirm_pass = (string) $_POST['confirm_pass'];

        if ($new_pass !== $confirm_pass) {
            $error = '<p style="color:red;">Las contraseñas no coinciden.</p>';
        } else {

            wp_set_password($new_pass, $user_id);

            delete_user_meta($user_id, 'reset_password_token');
            delete_user_meta($user_id, 'reset_password_expire');

            $redirect_url = 'https://aprobandome.com/login/';
            $seconds = 4;

            return '
            <div style="padding:14px 16px; border:1px solid #cfe8d5; background:#eefaf1; color:#1f6b2e; border-radius:8px; font-weight:600;">
                Contraseña actualizada correctamente. En ' . intval($seconds) . ' segundos serás redirigido al login...
            </div>
            <script>
                setTimeout(function () {
                    window.location.href = ' . json_encode($redirect_url) . ';
                }, ' . (intval($seconds) * 1000) . ');
            </script>
            ';
        }
    }

    // Formulario (siempre se muestra cuando no fue exitoso)
    $form = '
    <form method="post">
        ' . wp_nonce_field('custom_reset_password', '_wpnonce_custom_reset', true, false) . '

        <label>Nueva contraseña</label><br>
        <input type="password" name="new_pass" required>
        <br><br>

        <label>Confirmar contraseña</label><br>
        <input type="password" name="confirm_pass" required>
        <br><br>

        <button type="submit">Cambiar contraseña</button>
    </form>
    ';

    return $error . $form;
}
