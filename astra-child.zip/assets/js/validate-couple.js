jQuery(document).ready(function($) {
  const pageValidateCouple = 'page-id-1774';

  if ($('body').hasClass(pageValidateCouple)) {
    // Detectar evento submit del formulario
    $( ".validate-couple-form" ).on('submit', function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      // Obtener el código de la primera pareja
      const coupleOneId = $('.validate-couple-form').find('input[name="couple_code"]').val();
      console.log(coupleOneId)

      data = {
        coupleOneId,
        action: 'validate_couple'
      };
    
      $.ajax({
        url: code_scripts.ajaxurl,
        type: 'POST',
        dataType: "JSON",
        data,
        success: function (response) {
          console.log(response)
          if (response['success']) {
            hideVerificationForm()
            showVerificationSuccessful()

            $('.couple-successful-validated').css({
              'display': 'block'
            });

            const coupleOneID = response['data']['couple_one']['data']['ID'];
            const coupleOneName = response['data']['couple_one']['data']['display_name'];
            const coupleOneCompletedTest = response['data']['completed_test'];

            $('.couple-successful-validated .couple-info').html(
              `
                <div class="couple-info__name">
                  <span>Nombre de tu pareja</span>
                  <span class="name">${coupleOneName}</span>
                </div>
                <div class="couple-info__test-status">
                  <span>Estado del test</span>
                  ${coupleOneCompletedTest ? 
                    '<span class="couple-test-state couple-test-state--completed">Completado</span>' : 
                    '<span class="couple-test-state couple-test-state--not-completed">No completado</span>'
                  }
                </div>
              `
            )
            
            $('.continue-couple-verification').data('couple-one', coupleOneID);
          } else {
            toastr["error"](response['message'], "Error");
          }
        },
        error: function (error) {
          toastr["error"](error.message, "Error");
        }
      })
    });

    // Hacer el match de parejas
    $(".continue-couple-verification").on('click',  function(e) {
      const coupleTwoId = $(this).data('couple-two');
      const coupleOneId = parseInt($(this).data('couple-one'), 10);

      data = {
        coupleTwoId,
        coupleOneId,
        action: 'match_couple'
      };

      $.ajax({
        url: code_scripts.ajaxurl,
        type: 'POST',
        dataType: "JSON",
        data,
        success: async function (response) {
          console.log(response)
          if (response['success']) {
            const result = await Swal.fire({
              icon: 'success',
              title: "¡Listo!",
              text: `${response['message']}`,
              confirmButtonText: "Continuar",
            });

            if (result.isConfirmed) {
              window.location.href = `${code_scripts.get_site_url}/test/?test-type=parejas&pareja2=true`;
            }

          } else {
            toastr["error"](response['message'], "Error");
          }
        },
        error: function (error) {
          toastr["error"](error.message, "¡Listo!");
        }
      })

      console.log(userId, coupleOneId)
    });

    // Probar otro código 
    $(".try-another-code").on('click',  function(e) {
      hideVerificationSuccessful()
      showVerificationForm()
    });

    function hideVerificationForm() {
      $('.validate-couple-form').css({
        'display': 'none'
      });

      $('.elementor-element-b8a32d5').css({
        'display': 'none'
      });

      $('.elementor-element-89f736f').css({
        'display': 'none'
      });

      $('.elementor-element-32ded1d').css({
        '--padding-left': '120px'
      });
    }

    function showVerificationForm() {
      $('.validate-couple-form').css({
        'display': 'block'
      });

      $('.elementor-element-b8a32d5').css({
        'display': 'block'
      });

      $('.elementor-element-89f736f').css({
        'display': 'block'
      });

      $('.elementor-element-32ded1d').css({
        '--padding-left': '240px'
      });
    }

    function showVerificationSuccessful() {
      $('.couple-successful-validated').css({
        'display': 'block'
      });
    }

    function hideVerificationSuccessful() {
      $('.couple-successful-validated').css({
        'display': 'none'
      });
    }
  }
});