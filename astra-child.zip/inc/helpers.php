<?php

if (!function_exists('process_answers')) {
    function process_answers(array $answers): array
    {
        // Rangos de clasificación por categoría
        $rules = [
            "insuficiencia" => ["minimum" => 2,  "medium" => 6,  "maximum" => 11],
            "rechazo"       => ["minimum" => 7,  "medium" => 16, "maximum" => 23],
            "desaprobacion" => ["minimum" => 14, "medium" => 25, "maximum" => 32],
            "obsesividad"   => ["minimum" => 1,  "medium" => 3,  "maximum" => 7],
            "dependencia"   => ["minimum" => 1,  "medium" => 3,  "maximum" => 5],
            "evitacion"     => ["minimum" => 5,  "medium" => 10, "maximum" => 13],
        ];

        $total = count($answers);

        // Preguntas por categoría
        $q_desaprobacion = [1, 2, 3, 4, 5, 6, 7, 8];
        $q_insuficiencia = [9, 10, 11];
        $q_rechazo       = [12, 13, 14, 15, 16];
        $q_obsesividad   = [17, 18];
        $q_dependencia   = [19, 20];
        $q_evitacion     = [21, 22, 23];

        // Acumuladores
        $v_desaprobacion = []; $s_desaprobacion = 0;
        $v_insuficiencia = []; $s_insuficiencia = 0;
        $v_rechazo       = []; $s_rechazo       = 0;
        $v_obsesividad   = []; $s_obsesividad   = 0;
        $v_dependencia   = []; $s_dependencia   = 0;
        $v_evitacion     = []; $s_evitacion     = 0;

        // Visibilidad condicional para preguntas 13, 16, 17, 18
        $visibility = [13 => 0, 16 => 0, 17 => 0, 18 => 0];

        // Procesar cada respuesta
        foreach ($answers as &$answer) {
            $qi = intval($answer["question"]) - 89;
            $av = intval($answer["answer"]);

            $answer["question"] = $qi;

            // Visibilidad: mostrar fragmento solo si respuesta > 1
            if (array_key_exists($qi, $visibility)) {
                $visibility[$qi] = $av > 1 ? 1 : 0;
            }

            if (in_array($qi, $q_desaprobacion, true)) { $s_desaprobacion += $av; $v_desaprobacion[] = $av; }
            if (in_array($qi, $q_insuficiencia, true)) { $s_insuficiencia += $av; $v_insuficiencia[] = $av; }
            if (in_array($qi, $q_rechazo,       true)) { $s_rechazo       += $av; $v_rechazo[]       = $av; }
            if (in_array($qi, $q_obsesividad,   true)) { $s_obsesividad   += $av; $v_obsesividad[]   = $av; }
            if (in_array($qi, $q_dependencia,   true)) { $s_dependencia   += $av; $v_dependencia[]   = $av; }
            if (in_array($qi, $q_evitacion,     true)) { $s_evitacion     += $av; $v_evitacion[]     = $av; }
        }
        unset($answer);

        // Totales por grupo
        $t_amenazas   = $s_desaprobacion;
        $t_dolores    = $s_insuficiencia + $s_rechazo;
        $t_estrategas = $s_obsesividad + $s_dependencia + $s_evitacion;

        // Vulnerabilidad dominante
        $vuln_alta = array_search(
            max(["insuficiencia" => $s_insuficiencia, "rechazo" => $s_rechazo]),
            ["insuficiencia" => $s_insuficiencia, "rechazo" => $s_rechazo],
            true
        );

        // Niveles por categoría
        $lvl_insuficiencia = get_lvl($s_insuficiencia, $rules["insuficiencia"]);
        $lvl_rechazo       = get_lvl($s_rechazo,       $rules["rechazo"]);
        $lvl_desaprobacion = get_lvl($s_desaprobacion, $rules["desaprobacion"]);
        $lvl_obsesividad   = get_lvl($s_obsesividad,   $rules["obsesividad"]);
        $lvl_dependencia   = get_lvl($s_dependencia,   $rules["dependencia"]);
        $lvl_evitacion     = get_lvl($s_evitacion,     $rules["evitacion"]);

        // Banderas de nivel por grupo (para Mustache)
        $dolores_alto    = $lvl_insuficiencia === "ALTO"  || $lvl_rechazo     === "ALTO";
        $dolores_medio   = $lvl_insuficiencia === "MEDIO" || $lvl_rechazo     === "MEDIO";
        $dolores_bajo    = $lvl_insuficiencia === "BAJO"  || $lvl_rechazo     === "BAJO";

        $amenazas_alto   = $lvl_desaprobacion === "ALTO";
        $amenazas_medio  = $lvl_desaprobacion === "MEDIO";
        $amenazas_bajo   = $lvl_desaprobacion === "BAJO";

        $estrat_alto     = $lvl_obsesividad === "ALTO"  || $lvl_dependencia === "ALTO"  || $lvl_evitacion === "ALTO";
        $estrat_medio    = $lvl_obsesividad === "MEDIO" || $lvl_dependencia === "MEDIO" || $lvl_evitacion === "MEDIO";
        $estrat_bajo     = $lvl_obsesividad === "BAJO"  || $lvl_dependencia === "BAJO"  || $lvl_evitacion === "BAJO";

        return [
            "question_visibility" => [
                "show_q13" => $visibility[13],
                "show_q16" => $visibility[16],
                "show_q17" => $visibility[17],
                "show_q18" => $visibility[18],
            ],

            "total"                      => $total,
            "result_vulnerabilidad_alta" => $vuln_alta,

            "results_general" => [
                "amenazas_total"    => $t_amenazas,
                "dolores_total"     => $t_dolores,
                "estrategias_total" => $t_estrategas,
            ],

            "results_promedio" => [
                "amenazas_prom"    => $t_amenazas   / count($q_desaprobacion),
                "dolores_prom"     => $t_dolores    / (count($q_insuficiencia) + count($q_rechazo)),
                "estrategias_prom" => $t_estrategas / (count($q_obsesividad) + count($q_dependencia) + count($q_evitacion)),
            ],

            "results_type" => [
                "insuficiencia" => $s_insuficiencia,
                "rechazo"       => $s_rechazo,
                "desaprobacion" => $s_desaprobacion,
                "obsesividad"   => $s_obsesividad,
                "dependencia"   => $s_dependencia,
                "evitacion"     => $s_evitacion,
            ],

            "result_type_value" => [
                // Grupos
                "dolores_has_alto"     => $dolores_alto,  "dolores_has_medio"     => $dolores_medio,  "dolores_has_bajo"     => $dolores_bajo,
                "amenazas_has_alto"    => $amenazas_alto, "amenazas_has_medio"    => $amenazas_medio, "amenazas_has_bajo"    => $amenazas_bajo,
                "estrategias_has_alto" => $estrat_alto,   "estrategias_has_medio" => $estrat_medio,   "estrategias_has_bajo" => $estrat_bajo,

                // Categorías individuales
                "insuficiencia" => ["type" => $lvl_insuficiencia, "is_alto" => $lvl_insuficiencia === "ALTO", "is_medio" => $lvl_insuficiencia === "MEDIO", "is_bajo" => $lvl_insuficiencia === "BAJO", "labels" => ["A","B","C","",""],              "value" => $v_insuficiencia],
                "rechazo"       => ["type" => $lvl_rechazo,       "is_alto" => $lvl_rechazo       === "ALTO", "is_medio" => $lvl_rechazo       === "MEDIO", "is_bajo" => $lvl_rechazo       === "BAJO", "labels" => ["A","B","C","D","E"],            "value" => $v_rechazo],
                "desaprobacion" => ["type" => $lvl_desaprobacion, "is_alto" => $lvl_desaprobacion === "ALTO", "is_medio" => $lvl_desaprobacion === "MEDIO", "is_bajo" => $lvl_desaprobacion === "BAJO", "labels" => ["A","B","C","D","E","F","G","H"], "value" => $v_desaprobacion],
                "obsesividad"   => ["type" => $lvl_obsesividad,   "is_alto" => $lvl_obsesividad   === "ALTO", "is_medio" => $lvl_obsesividad   === "MEDIO", "is_bajo" => $lvl_obsesividad   === "BAJO", "labels" => ["A","B","","",""],               "value" => $v_obsesividad],
                "dependencia"   => ["type" => $lvl_dependencia,   "is_alto" => $lvl_dependencia   === "ALTO", "is_medio" => $lvl_dependencia   === "MEDIO", "is_bajo" => $lvl_dependencia   === "BAJO", "labels" => ["A","B","","",""],               "value" => $v_dependencia],
                "evitacion"     => ["type" => $lvl_evitacion,     "is_alto" => $lvl_evitacion     === "ALTO", "is_medio" => $lvl_evitacion     === "MEDIO", "is_bajo" => $lvl_evitacion     === "BAJO", "labels" => ["A","B","C","",""],              "value" => $v_evitacion],
            ],

            "results" => $answers,
        ];
    }
}

if (!function_exists('get_lvl')) {
function get_lvl(int $score, array $rule): string
    {
        if ($score <= $rule["minimum"]) return "BAJO";
        if ($score <= $rule["medium"])  return "MEDIO";
        return "ALTO";
    }
}

if (!function_exists('get_results_user')) {
    function get_results_user(int $user_id): array
    {
        // Nombre del usuario
        $name = trim(
            get_user_meta($user_id, "first_name", true) . " " .
            get_user_meta($user_id, "last_name",  true)
        );

        // Respuestas guardadas en meta
        $raw     = get_user_meta($user_id, "question_test_ids", true);
        $answers = json_decode(stripslashes($raw), true);

        $results = process_answers($answers);

        return [
            "success"                    => true,
            "name"                       => $name,
            "result_complete"            => true,
            "total"                      => $results["total"],
            "result_vulnerabilidad_alta" => $results["result_vulnerabilidad_alta"],
            "results_general"            => $results["results_general"],
            "results_promedio"           => $results["results_promedio"],
            "results_type"               => $results["results_type"],
            "result_type_value"          => $results["result_type_value"],
            "results"                    => $results["results"],
            "question_visibility"        => $results["question_visibility"],
        ];
    }
}

if (!function_exists('get_results_area')) {
    function get_results_area(int $area_id): array
    {
        global $wpdb;

        // Nombre del área
        $area = $wpdb->get_row($wpdb->prepare(
            "SELECT nombre FROM wp_areas WHERE id = %d",
            $area_id
        ));

        $area_name = $area->nombre ?? "Área #{$area_id}";

        // Usuarios del área
        $user_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT um.user_id
             FROM wp_user_members um
             WHERE um.area_id = %d",
            $area_id
        ));

        if (empty($user_ids)) {
            return ["success" => false, "message" => "No hay usuarios en esta área."];
        }

        // Recopilar respuestas por pregunta de todos los usuarios
        $questions_map = []; // [question_id => ["answers" => [], "value" => ""]]

        foreach ($user_ids as $user_id) {
            $raw = get_user_meta($user_id, "question_test_ids", true);

            if (empty($raw)) continue;

            $user_answers = json_decode(stripslashes($raw), true);

            if (!is_array($user_answers)) continue;

            foreach ($user_answers as $item) {
                $q = $item["question"];
                $a = intval($item["answer"]);
                $v = $item["value"];

                if (!isset($questions_map[$q])) {
                    $questions_map[$q] = ["answers" => [], "value" => $v];
                }

                $questions_map[$q]["answers"][] = $a;
            }
        }

        if (empty($questions_map)) {
            return ["success" => false, "message" => "Ningún usuario del área ha completado el test."];
        }

        // Generar el formato promediado por pregunta
        ksort($questions_map);

        $answers = [];

        foreach ($questions_map as $question => $data) {
            $avg = round(array_sum($data["answers"]) / count($data["answers"]));

            $answers[] = [
                "question" => $question,
                "answer"   => $avg,
                "value"    => $data["value"],
            ];
        }

        // Procesar con la misma lógica del test individual
        $results = process_answers($answers);

        return [
            "success"                    => true,
            "name"                       => $area_name,
            "result_complete"            => true,
            "total"                      => $results["total"],
            "result_vulnerabilidad_alta" => $results["result_vulnerabilidad_alta"],
            "results_general"            => $results["results_general"],
            "results_promedio"           => $results["results_promedio"],
            "results_type"               => $results["results_type"],
            "result_type_value"          => $results["result_type_value"],
            "results"                    => $results["results"],
            "question_visibility"        => $results["question_visibility"],
            "is_area"                    => true,
        ];
    }
}