<?php
function get_sitemadi_welcome_email() {
    // Definir la URL del botón
    $account_url = get_site_url() . '/mi-cuenta/panel-usuario/';

    ob_start();
    ?>
    <!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bienvenido a Aprobándome</title>

<style>
@media only screen and (max-width:480px){
  .container{width:100%!important;border-radius:0!important}
  .content{padding:20px!important}
  h1{font-size:22px!important}
  p{font-size:14px!important}
  .btn{font-size:14px!important;padding:12px 18px!important}
}
</style>
</head>

<body style="margin:0;padding:0;background:#f3f3f3;font-family:Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td align="center">

<table class="container" width="600" cellpadding="0" cellspacing="0" role="presentation"
style="max-width:600px;background:#ffffff;border-radius:22px;overflow:hidden;">

<!-- HEADER -->
<tr>
<td style="padding:24px 24px 8px;text-align:left;">
  <img src="http://aprobandome.com/wp-content/uploads/2025/12/Compras-Emails-Aprobandome.png"
       alt="Aprobándome"
       width="170"
       style="display:block;border:0;">
</td>
</tr>

<!-- HERO -->
<tr>
<td align="center" style="padding:10px 24px 24px;">
  <img src="http://aprobandome.com/wp-content/uploads/2025/12/email-nuevo-registro.png"
       alt="Bienvenido"
       width="100%"
       style="max-width:360px;border-radius:26px;display:block;">
</td>
</tr>

<!-- CONTENIDO -->
<tr>
<td class="content" style="padding:0 32px 32px;text-align:left;color:#222;">
  
  <h1 style="margin:0 0 16px;font-size:28px;font-weight:700;">
    ¡Bienvenid@ a aprobándome!
  </h1>

  <p style="margin:0 0 16px;font-size:16px;line-height:1.6;">
    Gracias por unirte. Ahora formas parte de una comunidad que elige vivir con más
    autenticidad y vínculos más sanos.
  </p>

  <p style="margin:0 0 16px;font-size:16px;line-height:1.6;">
    Desde tu cuenta podrás acceder a tus test, cursos y herramientas que hemos creado
    para acompañarte en cada paso de tu proceso.
  </p>

  <p style="margin:0 0 24px;font-size:16px;line-height:1.6;">
    Este es tu espacio para conocerte, crecer y construir mejores relaciones.
  </p>

  <a href="<?php echo esc_url($account_url); ?>"
     target="_blank"
     class="btn"
     style="display:inline-block;background:#000;color:#fff;
            text-decoration:none;font-size:16px;
            padding:14px 26px;border-radius:30px;">
    Accede a tu cuenta aquí
  </a>

</td>
</tr>

<!-- FOOTER -->
<tr>
<td style="background:#2e2b3a;padding:32px;color:#e6e6e6;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation">

<tr>
<td valign="top" style="padding-bottom:20px;">
  <strong style="font-size:16px;color:#fff;">Contacto</strong><br>
  <span style="font-size:14px;line-height:1.6;">
    848 Brickell Ave<br>
    Suite 950 Miami<br>
    Fl. 33131<br>
    <a href="mailto:info@aprobandome.com" style="color:#e6e6e6;text-decoration:none;">
      info@aprobandome.com
    </a>
  </span>
</td>

<td valign="top" style="padding-bottom:20px;">
  <strong style="font-size:16px;color:#fff;">Síguenos</strong><br><br>

  <a href="https://www.instagram.com/aprobandome"
     target="_blank"
     style="margin-right:14px;">
    <img src="https://aprobandome.com/wp-content/uploads/2025/12/Icon.png"
         width="24" style="display:inline-block;border:0;">
  </a>

  

</td>

<td valign="top">
  <strong style="font-size:16px;color:#fff;">Grupo empresarial</strong><br>
  <span style="font-size:14px;line-height:1.8;">

    <a href="https://efrenmartinezortiz.com/" target="_blank" style="color:#e6e6e6;text-decoration:none;">
      Dr. Efren Martínez Ortiz
    </a><br>

    <a href="https://wmslatam.com/" target="_blank" style="color:#e6e6e6;text-decoration:none;">
      WMS
    </a><br>

    <a href="https://terapiaunclick.com/" target="_blank" style="color:#e6e6e6;text-decoration:none;">
      TClick
    </a><br>

    <a href="https://colectivoaquiyahora.org/" target="_blank" style="color:#e6e6e6;text-decoration:none;">
      Colectivo Aquí y Ahora
    </a><br>

    <a href="https://saps-col.org/" target="_blank" style="color:#e6e6e6;text-decoration:none;">
      SAPS
    </a>

  </span>
</td>
</tr>

</table>

<p style="font-size:12px;color:#aaa;text-align:center;margin-top:24px;">
  © 2026 IDS. Todos los derechos reservados
</p>

</td>
</tr>

</table>
</td>
</tr>
</table>

</body>
</html>
<?php
return ob_get_clean();
}
?>