<?php

function snackbar_couple_pending_test_function() {
    global $wpdb;

    // Consultar el id del usuario actual.
    $user_id = get_current_user_id();

    // Verificar si el usuario está logeado.
    if (!$user_id) {
      // Si no está logueado, se retorna un string vacío.
      return '';
    }

    // Verificar si el usuario ha comprado el test de pareja, y su pareja ha hecho el test
    $exists = UserQueries::user_bought_test($user_id, AppConstants::TEST_TYPE_PAREJAS);
    $user_paid = $exists[0]->pago;
    $couple_id = $exists[0]->pareja_id;
    $couple_email = "";

    // Si el usuario no ha pagado, se retorna un string vacío
    if (!$user_paid) {
      return '';
    }

    // Si el usuario pagó, ya se hizo el match y su pareja ya hizo el test, se retorna un string vacío
    if ($couple_id && UserQueries::user_completed_test($couple_id)) {
      return '';
    }

    // Obtener el correo de la pareja del usuario
    $args = array(
      'customer' => $user_id,
    );

    $orders = wc_get_orders( $args );
    if ($orders) {
      foreach ($orders as $order) {
        foreach ($order->get_items() as $item_id => $item) {
          // Verificar si el producto corresponde
          if ($item->get_product_id() == AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PAREJAS]) {
            $couple_email = get_post_meta($order->get_id(), '_couple_email', true);
            break;
          }
        }
      }
    } else {
      return '';
    }

    // Si la pareja no ha realizado el test, se muestra la advertencia.
    if(!is_admin()) {
      wp_enqueue_style( 'snackbar-pending-test-styles', get_stylesheet_directory_uri() . '/components/shortcodes/snackbar-pending-test.css' );

      ob_start();
      ?>
        <div class="snackbar snackbar--danger">
          <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/06/Alert-triangle.svg">

          <div class="text-container">
            <span class="title">Test de pareja pendiente</span>
            <span class="text" style="margin-bottom: 24px;">
              Tu pareja aún no ha completado el test. Invítale a hacerlo para obtener los resultados completos y avanzar juntos. ¡Anímale ahora!
            </span>

            <span style="font-size: 12px; font-weight: 600; margin-bottom: 4px;">Código de verificación</span>
            <span style="font-size: 36px; letter-spacing: 1.5px;"><?php echo $user_id; ?></span>
          </div>

          <div class="actions-container">
            <button class="resend-couple-link" data-couple-one="<?php echo $user_id; ?>" data-couple-email="<?php echo $couple_email; ?>">Reenviar test al correo</button>
            <button class="copy-link-code" data-link="<?php echo get_site_url() ?>/registro/?pareja2=true">
              <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/06/Link.svg">
              <span>Copiar link y código</span>
            </button>
          </div>
        </div>
      <?php
      return ob_get_clean();
    }
}
add_shortcode('couple_pending_test', 'snackbar_couple_pending_test_function');


