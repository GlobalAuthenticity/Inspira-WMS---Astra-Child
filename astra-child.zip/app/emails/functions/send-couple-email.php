<?php

/**
 * Función para enviar correos de pareja
 * 
 * coupleOneID -> ID de usuario de la pareja que compró el test
 * coupleTwoEmail -> Dirección de correo electrónico de la segunda pareja
 * 
 * @return void.
 */
function send_couple_email($couple_one_id, $couple_two_email) {
  // Establecemos el destinatario y el asunto
  $recipient = $couple_two_email;
  $subject = __("¡Tu pareja te espera en Sistemadi!");
  
  // Obtenemos el HTML correspondiente
  $message = get_couple_email_html($couple_one_id);

  // Enviar el correo
  return send_email($recipient, $subject, $message);
}
