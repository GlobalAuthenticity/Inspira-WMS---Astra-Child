<?php
/**
 * Edit account form
 *
 * @package WooCommerce\Templates
 * @version 8.7.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_edit_account_form' );

// ================== USUARIO ACTUAL ==================
$user    = wp_get_current_user();
$user_id = $user->ID;

// ================== USER META ==================
$user_age     = get_user_meta( $user_id, 'user_age', true );
$user_gender  = get_user_meta( $user_id, 'user_gender', true );
$country      = get_user_meta( $user_id, 'country', true );
$phone_number = get_user_meta( $user_id, 'phone_number', true );

// ================== OBTENER LISTADO DE PAÍSES ==================
$countries = [];

$curl = curl_init();
curl_setopt_array( $curl, [
    CURLOPT_URL            => 'https://api.countrystatecity.in/v1/countries',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
        'X-CSCAPI-KEY: aEtRREppVHJpcnlNWVNGcDVzZW9LZjhxcTk0U3A2Uno1Tkh2ZUNyYQ=='
    ],
]);

$response = curl_exec( $curl );
curl_close( $curl );

if ( $response ) {
    $decoded = json_decode( $response, true );
    if ( is_array( $decoded ) ) {
        $countries = $decoded;
    }
}
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');


/* BOTÓN GUARDAR CAMBIOS - FORZADO */
.woocommerce-account .woocommerce-EditAccountForm button.woocommerce-Button,
.woocommerce-account .woocommerce-EditAccountForm input.woocommerce-Button,
.woocommerce-account .woocommerce-EditAccountForm .button {
  background-color: #8867B0 !important;
  color: #ffffff !important;
  border: none !important;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.woocommerce-account .woocommerce-EditAccountForm button.woocommerce-Button:hover,
.woocommerce-account .woocommerce-EditAccountForm input.woocommerce-Button:hover,
.woocommerce-account .woocommerce-EditAccountForm .button:hover {
  background-color: #7553a3 !important;
}

.my-account-wrapper,
.my-account-wrapper * {
  font-family: 'Inter', sans-serif;
}

.my-account-wrapper {
  display: flex;
  gap: 40px;
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px;
}

.my-account-form-container {
  flex: 1;
}

.my-account-heading {
  font-size: 28px;
  font-weight: 600;
  margin-bottom: 24px;
}

.woocommerce-EditAccountForm .form-row {
  margin-bottom: 16px;
}

.woocommerce-EditAccountForm label {
  font-size: 14px;
  font-weight: 500;
  display: block;
  margin-bottom: 6px;
}

.woocommerce-EditAccountForm input,
.woocommerce-EditAccountForm select {
  width: 100%;
  padding: 12px 14px;
  font-size: 14px;
  border-radius: 6px;
  border: 1px solid #d1d5db;
}

.woocommerce-EditAccountForm input:focus,
.woocommerce-EditAccountForm select:focus {
  outline: none;
  border-color: #8867B0;
  box-shadow: 0 0 0 2px rgba(136,103,176,0.2);
}

/* BOTÓN GUARDAR CAMBIOS */
.woocommerce-Button.button {
  background-color: #8867B0;
  color: #ffffff;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.woocommerce-Button.button:hover {
  background-color: #7553a3;
}

.my-account-wrapper img {
  max-width: 420px;
  width: 100%;
  border-radius: 16px;
}

.description {
  font-size: 13px;
  color: #6b7280;
  margin-top: 8px;
}

/* RESPONSIVE */
@media (max-width: 768px) {
  .my-account-wrapper {
    flex-direction: column;
    padding: 16px;
  }

  .form-row-first,
  .form-row-last {
    width: 100% !important;
    float: none !important;
  }

  .my-account-wrapper img {
    display: none;
  }

  .my-account-heading {
    text-align: center;
    font-size: 24px;
  }

  .woocommerce-Button.button {
    width: 100%;
  }
}
</style>

<div class="my-account-wrapper">
  <div class="my-account-form-container">
    <h1 class="my-account-heading">Mi cuenta</h1>

    <form class="woocommerce-EditAccountForm edit-account"
          method="post"
          action="<?php echo esc_url( wc_get_account_endpoint_url( 'edit-account' ) ); ?>"
          <?php do_action( 'woocommerce_edit_account_form_tag' ); ?>>

      <?php do_action( 'woocommerce_edit_account_form_start' ); ?>

      <!-- display_name obligatorio -->
      <input type="hidden"
             name="account_display_name"
             value="<?php echo esc_attr( trim( $user->first_name . ' ' . $user->last_name ) ); ?>">

      <!-- DATOS PERSONALES -->
      <p class="form-row form-row-first">
        <label>Nombre *</label>
        <input type="text" name="account_first_name"
               value="<?php echo esc_attr( $user->first_name ); ?>" required>
      </p>

      <p class="form-row form-row-last">
        <label>Apellidos *</label>
        <input type="text" name="account_last_name"
               value="<?php echo esc_attr( $user->last_name ); ?>" required>
      </p>

      <div class="clear"></div>

      <p class="form-row form-row-first">
        <label>Edad *</label>
        <input type="number" name="user_age"
               value="<?php echo esc_attr( $user_age ); ?>" min="1" required>
      </p>

      <p class="form-row form-row-last">
        <label>Género *</label>
        <select name="user_gender" required>
          <option value="">Seleccione…</option>
          <?php foreach ( ['Masculino','Femenino','Otro'] as $g ) : ?>
            <option value="<?php echo esc_attr($g); ?>" <?php selected($user_gender,$g); ?>>
              <?php echo esc_html($g); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </p>

      <div class="clear"></div>

      <p class="form-row form-row-first">
        <label>País *</label>
        <select name="country" required>
          <option value="">Seleccione…</option>
          <?php foreach ( $countries as $c ) : ?>
            <option value="<?php echo esc_attr($c['name']); ?>" <?php selected($country,$c['name']); ?>>
              <?php echo esc_html($c['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </p>

      <p class="form-row form-row-last">
        <label>Teléfono *</label>
        <input type="text" name="phone_number"
               value="<?php echo esc_attr( $phone_number ); ?>" required>
      </p>

      <div class="clear"></div>

      <p class="form-row form-row-wide">
        <label>Email *</label>
        <input type="email" name="account_email"
               value="<?php echo esc_attr( $user->user_email ); ?>" required>
      </p>

      <!-- CAMBIO DE CONTRASEÑA -->
      <p class="form-row form-row-wide">
        <label for="password_current">Contraseña actual</label>
        <input type="password"
               name="password_current"
               id="password_current"
               autocomplete="current-password">
      </p>

      <p class="form-row form-row-first">
        <label for="password_1">Nueva contraseña</label>
        <input type="password"
               name="password_1"
               id="password_1"
               autocomplete="new-password">
      </p>

      <p class="form-row form-row-last">
        <label for="password_2">Confirmar nueva contraseña</label>
        <input type="password"
               name="password_2"
               id="password_2"
               autocomplete="new-password">
      </p>

      <div class="clear"></div>

      <p class="description">
        Para cambiar tu contraseña debes ingresar tu contraseña actual.
        Si dejas estos campos vacíos, la contraseña no se modificará.
      </p>

      <?php do_action( 'woocommerce_edit_account_form' ); ?>

      <p>
        <?php wp_nonce_field( 'save_account_details', 'save-account-details-nonce' ); ?>
        <button type="submit"
                class="woocommerce-Button button"
                name="save_account_details"
                value="1">
          Guardar cambios
        </button>
        <input type="hidden" name="action" value="save_account_details">
      </p>

      <?php do_action( 'woocommerce_edit_account_form_end' ); ?>
    </form>
  </div>

  <img src="<?php echo esc_url( get_site_url() . '/wp-content/uploads/2025/12/recuperar-contrasena.png' ); ?>"
       alt="Mi cuenta">
</div>

<?php do_action( 'woocommerce_after_edit_account_form' ); ?>
