<?php
/**
 * Thankyou page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/thankyou.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 8.1.0
 *
 * @var WC_Order $order
 */

defined( 'ABSPATH' ) || exit;

// Shortcode para mostrar los pasos del proceso
// TODO: Verificar si el usuario ya ha completado el test y si es necesario mostrar los pasos del proceso
// if (!$product_is_course) { 
// 	print do_shortcode('[process_steps]');
// }

global $wp, $wpdb;

// IDs de los productos de los tests
$padres = AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PADRES];
$parejas = AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PAREJAS];
$personal = AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PERSONAL];

if (is_checkout() && !empty( $wp->query_vars['order-received'])) {
	// Se obtiene el ID del usuario
	$user_id = get_current_user_id();
	$user_info = get_userdata($user_id);
	$user_email = $user_info->user_email;

	// Obtener fecha de la compra
	$fecha = new DateTime();
	$fecha->format('Y-m-d');

	// Obtener el objeto de instancia WC_Customer para el usuario actual
	$customer = new WC_Customer($user_id);

	// Obtener la última instancia del objeto WC_Order del cliente actual
	$last_order = $customer->get_last_order();
	$coupon = $last_order->get_coupon_codes();

	// Si es test de pareja, se obtiene el email de la pareja del usuario
	$couple_email = get_post_meta($last_order->get_id(), '_couple_email', true);

	// Variables para determinar el tipo de producto
	$product_is_course = false;
	$product_is_test = false;

	// Obtener el ID de la orden
	$order_id = $last_order->get_id();

	// Obtiene los ítems comprados
	$items = $last_order->get_items();
	$order_data = $last_order->get_data();
	$order_status = $last_order->get_status(); 

	$results_url = '';

	// Variables para enviar correo electrónico
	$is_send_email = false;

	// Envío de correo con el link donde puede ver los resultados.
	$link_send_email = '';

	foreach($items as $item) {
		$sentEmail = false;
		$product_id = $item->get_product_id();
		$test_type = array_search($product_id, AppConstants::TESTS_PRODUCTS_IDS);

		// Verificar si el producto es un curso o un test
		if (
			in_array($product_id, AppConstants::getCoursesProductsIds()) ||
			in_array($product_id, AppConstants::getCoursesBundlesIds())
		) {
			$product_is_course = true;
			//Enviar correo para acceder a la parte de cursos una vez comprado 
			$sentEmail = send_course_email($user_email, $course_url);
		} else if (in_array($product_id, AppConstants::TESTS_PRODUCTS_IDS)) {
			$product_is_test = true;
		}

		// Establecer página de resultados según el test adquirido
		if ($product_is_test) {
			switch ($product_id) {
				case AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PERSONAL]:
					$results_url = get_site_url() . '/resultado-test-personal-completo';
					break;
				case AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PADRES]:
					$results_url = get_site_url() . '/resultado-test-padres';
					break;
				case AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PAREJAS]:
					$results_url = get_site_url() . '/mi-cuenta/panel-usuario';
					break;
			}
		}

		// Lógica para la compra de cualquier test
		if (in_array($product_id, AppConstants::TESTS_PRODUCTS_IDS)) {
			$exist = UserQueries::user_bought_test($user_id, $test_type);
			
			// Link del resultado del test para enviar por correo
			$link_send_email = get_site_url().AppConstants::TEST_RESULT_URL_BY_TYPE[$test_type];

			if ($test_type == AppConstants::TEST_TYPE_PAREJAS) {
				// Enviar correo de compra a la segunda pareja
				$sentEmail = send_couple_email($user_id, $couple_email);

				// TODO: enviar el correo con el enlace de resutados a la primera pareja
				
			}

			// TODO: Armar correos de compra para enviar enlace de resultados
			if ($test_type == AppConstants::TEST_TYPE_PADRES || $test_type == AppConstants::TEST_TYPE_PERSONAL) {
				// Enviar correo con enlace de resultados al usuario
				$sentEmail = send_results_email($user_email, $results_url);
			}

			if (!$exist[0]->pago) {
				// Registrar el pago en la tabla
				$wpdb->insert('formularios_pagos', 
					array( 
						'user_id' => $user_id, 
						'resultados_id' => -1,
						'pago' => 1,
						'fecha_pago' => $fecha, 
						'tipo_resultado' => $test_type,
						'coupon' => $coupon[0],
						'correo_enviado' => $sentEmail ? 1 : 0,
					)
				);
			} else {
				// Editar correo enviado.
				$wpdb->update( 
					'formularios_pagos', 
					array( 
						'correo_enviado' => $sentEmail ? 1 : 0
					),
					array('ID' => $exist[0]->ID)
				);
			}
		}
	}
}
?>

<div class="thankyou-message-container  grid grid-col-2 grid-align-center">
	<div class="col">
		<?php if ( $product_is_test ) : ?>
		<div class="thankyou-wrapper">

			<h1 class="thankyou-title">
				¡Gracias y<br>
				felicidades por<br>
				completar tu <br>
				evaluacion de dependencia!
			</h1>

			<p class="thankyou-message">
				Ahora viene la mejor parte: conocer tus resultados y entender un poco más qué está pasando dentro de ti y en tus relaciones.
			</p>

			<p class="thankyou-message">
				Da clic y empieza a descubrir todo lo que esta evaluación tiene para contarte.
			</p>

			<a href="<?php echo esc_url( $results_url ); ?>" class="thankyou-button-link">
				<button class="thankyou-button">
					<img
						src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/pie-chart-white.svg"
						alt="Resultados"
					>
					<span>Mira aquí tus resultados</span>
				</button>
			</a>

	</div>
<?php endif; ?>




		<?php if ( $product_is_course ) : ?>
			<h1 class="thankyou-title">¡Gracias por<br>comprar tu curso!</h1>

			<p class="thankyou-message">
				Tu compra se ha completado con éxito. Ahora puedes acceder a tu(s) curso(s) y descubrir información valiosa para tu desarrollo.
			</p>

			<a href="<?php get_site_url(); ?>/mi-cuenta/cursos/">
				<button>
					<img
						style="margin-right: 4px; margin-bottom: 2px;"
						src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/06/video-white-svg.svg"
						alt="Ir a mis cursos">
					<span>Ir a mis cursos</span>
				</button>
			</a>
		<?php endif ?>
	</div>


	<div class="col">
		<img 
			class="thankyou-image"
			src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/12/thankyou-imagen.webp" 
			alt="Gracias por tu compra"
		>
	</div>
</div>

<div class="woocommerce-order">
	<?php
	if ( $order ) :
		do_action( 'woocommerce_before_thankyou', $order->get_id() );
		?>

	<?php if ( $order->has_status( 'failed' ) ) : ?>
		<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed"><?php esc_html_e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woocommerce' ); ?></p>

		<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
			<a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="button pay"><?php esc_html_e( 'Pay', 'woocommerce' ); ?></a>
			<?php if ( is_user_logged_in() ) : ?>
				<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button pay"><?php esc_html_e( 'My account', 'woocommerce' ); ?></a>
			<?php endif; ?>
		</p>
	<?php else : ?>
		<!-- <?php wc_get_template( 'checkout/order-received.php', array( 'order' => $order ) ); ?> -->

		<h3 class="thankyou-purchase-confirmation">Confirmación de compra</h3>

		<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">
			<li class="woocommerce-order-overview__order order">
				<span>Número de compra: </span>
				<strong><?php echo $order->get_order_number(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
			</li>

			<li class="woocommerce-order-overview__date date">
				<span>Fecha: </span>
				<strong><?php echo wc_format_datetime( $order->get_date_created() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
			</li>

			<?php if ( is_user_logged_in() && $order->get_user_id() === get_current_user_id() && $order->get_billing_email() ) : ?>
				<li class="woocommerce-order-overview__email email">
					<span>Correo electrónico: </span>
					<strong><?php echo $order->get_billing_email(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
				</li>
			<?php endif; ?>

			<li class="woocommerce-order-overview__total total">
				<span>Total: </span>
				<strong><?php echo $order->get_formatted_order_total(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
			</li>

			<?php if ( $order->get_payment_method_title() ) : ?>
				<li class="woocommerce-order-overview__payment-method method">
					<span>Método de pago: </span>
					<strong><?php echo wp_kses_post( $order->get_payment_method_title() ); ?></strong>
				</li>
			<?php endif; ?>
		</ul>
	<?php endif; ?>

	<?php do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id() ); ?>
	<?php do_action( 'woocommerce_thankyou', $order->get_id() ); ?>

	<?php if ( $product_is_test && $couple_email ) : ?>
		<section class="woocommerce-test-details">
			<h2 class="woocommerce-order-details__title">Datos para realizar el test</h2>

			<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
				<thead>
					<tr>
						<th class="woocommerce-table__product-name product-name">Datos de tu cuenta</th>
					</tr>
				</thead>

				<tbody>
					<tr>
						<td>
							<?php if ( is_user_logged_in() && $order->get_user_id() === get_current_user_id() && ($order->get_billing_first_name() && $order->get_billing_last_name()) ) : ?>
								<li class="woocommerce-order-overview__email email">
									<span><b>Nombre completo:</b></span>
									<?php echo $order->get_billing_first_name() . ' ' .$order->get_billing_last_name(); ?>
								</li>
							<?php endif; ?>

							<?php if ( is_user_logged_in() && $order->get_user_id() === get_current_user_id() && $order->get_billing_email() ) : ?>
								<li class="woocommerce-order-overview__email email">
									<span><b>Correo electrónico:</b></span>
									<?php echo $order->get_billing_email(); ?>
								</li>
							<?php endif; ?>
						</td>
					</tr>
				</tbody>

				<thead>
					<tr>
						<th class="woocommerce-table__product-name product-name">Datos de tu pareja para realizar el test</th>
					</tr>
				</thead>

				<tbody>
					<tr>
						<td>
							<?php if ( is_user_logged_in() && $order->get_user_id() === get_current_user_id() ) : ?>
								<li class="woocommerce-order-overview__email email">
									<span><b>Correo electrónico:</b></span>
									<?php echo $couple_email; ?>
								</li>
							<?php endif; ?>

							<span style="font-size: 14px; color: #47986d">
								<b>Nota:</b> se ha enviado un email al correo de tu pareja con la información necesaria para que pueda hacer su test.
							</span>
							<br>
							<span style="font-size: 14px; color: #e38f5b">
								<b>Importante:</b> Solo podrás ver el resultado del test cuando tu pareja lo complete.
							</span>
						</td>
					</tr>
				</tbody>
			</table>
		</section>
	<?php endif; ?>

	<div class="thankyou-go-profile">
		<a href="<?php get_site_url(); ?>/mi-cuenta/panel-usuario/">
			<button class="btn-primary" style="padding: 11px 67px;">Ir a mi perfil</button>
		</a>
	</div>

	<?php else : ?>
		<?php wc_get_template( 'checkout/order-received.php', array( 'order' => false ) ); ?>
	<?php endif; ?>
</div>
