<?php

/**
 * ------------------------------------------------------
 * Desasigna todos los cursos LearnDash de un usuario
 * ------------------------------------------------------
 *
 * @param int $user_id
 * @return bool
 */
function ld_remove_all_user_courses( int $user_id ): bool {

    // --------------------------------------------------
    // Validar usuario
    // --------------------------------------------------
    if ( empty( $user_id ) || ! get_user_by( 'id', $user_id ) ) {
        return false;
    }

    // --------------------------------------------------
    // Obtener cursos asignados al usuario
    // --------------------------------------------------
    $user_courses = learndash_user_get_enrolled_courses( $user_id );

    if ( empty( $user_courses ) ) {
        return true; // El usuario no tenía cursos asignados
    }

    // --------------------------------------------------
    // Desasignar cada curso
    // --------------------------------------------------
    foreach ( $user_courses as $course_id ) {
        ld_update_course_access( $user_id, $course_id, true );
    }

    return true;
}

/**
 * ------------------------------------------------------
 * Obtener resultados detallados del test
 * ------------------------------------------------------
 *
 * @param array $test_answers
 * @return array
 */
function get_user_test_detailed_results($test_answers)
{
    $test_answers = json_decode($test_answers, true);
    // --------------------------------------------------
    // Total de preguntas
    // --------------------------------------------------
    $total_questions = count($test_answers);

    // --------------------------------------------------
    // Definición de grupos de preguntas
    // --------------------------------------------------

    // -------- AMENAZAS --------
    $desaprobacion_questions = [1, 2, 3, 4, 5, 6, 7, 8];
    $desaprobacion_values    = [];
    $desaprobacion_sum       = 0;

    // -------- DOLORES --------
    $insuficiencia_questions = [9, 10, 11];
    $insuficiencia_values    = [];
    $insuficiencia_sum       = 0;

    $rechazo_questions       = [12, 13, 14, 15, 16];
    $rechazo_values          = [];
    $rechazo_sum             = 0;

    // -------- ESTRATEGIAS --------
    $obsesividad_questions   = [17, 18];
    $obsesividad_values      = [];
    $obsesividad_sum         = 0;

    $dependencia_questions   = [19, 20];
    $dependencia_values      = [];
    $dependencia_sum         = 0;

    $evitacion_questions     = [21, 22, 23];
    $evitacion_values        = [];
    $evitacion_sum           = 0;

    // --------------------------------------------------
    // Procesamiento de respuestas
    // --------------------------------------------------
    foreach ($test_answers as &$answer) {

        // Normalizar índice de pregunta
        $question_index = (int) $answer['question'] - 89;
        $answer_value   = (int) $answer['answer'];

        $answer['question'] = $question_index;

        // -------- AMENAZAS --------
        if (in_array($question_index, $desaprobacion_questions, true)) {
            $desaprobacion_sum      += $answer_value;
            $desaprobacion_values[] = $answer_value;
        }

        // -------- DOLORES --------
        if (in_array($question_index, $insuficiencia_questions, true)) {
            $insuficiencia_sum      += $answer_value;
            $insuficiencia_values[] = $answer_value;
        }

        if (in_array($question_index, $rechazo_questions, true)) {
            $rechazo_sum            += $answer_value;
            $rechazo_values[]       = $answer_value;
        }

        // -------- ESTRATEGIAS --------
        if (in_array($question_index, $obsesividad_questions, true)) {
            $obsesividad_sum        += $answer_value;
            $obsesividad_values[]   = $answer_value;
        }

        if (in_array($question_index, $dependencia_questions, true)) {
            $dependencia_sum        += $answer_value;
            $dependencia_values[]   = $answer_value;
        }

        if (in_array($question_index, $evitacion_questions, true)) {
            $evitacion_sum          += $answer_value;
            $evitacion_values[]     = $answer_value;
        }
    }

    unset($answer);

    // --------------------------------------------------
    // Totales agrupados
    // --------------------------------------------------
    $amenazas_total    = $desaprobacion_sum;
    $dolores_total     = $insuficiencia_sum + $rechazo_sum;
    $estrategias_total = $obsesividad_sum + $dependencia_sum + $evitacion_sum;

    // --------------------------------------------------
    // Vulnerabilidad dominante
    // --------------------------------------------------
    $vulnerabilidades = [
        'insuficiencia' => $insuficiencia_sum,
        'rechazo'       => $rechazo_sum,
    ];

    $vulnerabilidad_alta = array_search(
        max($vulnerabilidades),
        $vulnerabilidades,
        true
    );

    // --------------------------------------------------
    // Respuesta final
    // --------------------------------------------------
    return [

        'total' => $total_questions,
        'result_vulnerabilidad_alta' => $vulnerabilidad_alta,
        'results_general' => [
            'amenazas_total'    => $amenazas_total,
            'dolores_total'     => $dolores_total,
            'estrategias_total' => $estrategias_total,
        ],
        'results_promedio' => [
            'amenazas_prom'    => $amenazas_total / count($desaprobacion_questions),
            'dolores_prom'     => $dolores_total / (count($insuficiencia_questions) + count($rechazo_questions)),
            'estrategias_prom' => $estrategias_total / (count($obsesividad_questions) + count($dependencia_questions) + count($evitacion_questions)),
        ],
        'results_type' => [
            'insuficiencia' => $insuficiencia_sum,
            'rechazo'       => $rechazo_sum,
            'desaprobacion' => $desaprobacion_sum,
            'obsesividad'   => $obsesividad_sum,
            'dependencia'   => $dependencia_sum,
            'evitacion'     => $evitacion_sum,
        ],
        'result_type_value' => [
            'insuficiencia' => [
                'labels' => ['A', 'B', 'C', '', ''],
                'value'  => $insuficiencia_values,
            ],
            'rechazo' => [
                'labels' => ['A', 'B', 'C', 'D', 'E'],
                'value'  => $rechazo_values,
            ],
            'desaprobacion' => [
                'labels' => ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'],
                'value'  => $desaprobacion_values,
            ],
            'obsesividad' => [
                'labels' => ['A', 'B', '', '', ''],
                'value'  => $obsesividad_values,
            ],
            'dependencia' => [
                'labels' => ['A', 'B', '', '', ''],
                'value'  => $dependencia_values,
            ],
            'evitacion' => [
                'labels' => ['A', 'B', 'C', '', ''],
                'value'  => $evitacion_values,
            ],
        ],
        'results' => $test_answers,
    ];
}

function validate_result( $result ) {

    /**
     * ───── Reglas de evaluación ─────
     */
    $rules = [

        // ───── Amenazas ─────
        'desaprobacion' => [
            'minimum' => 14,
            'medium'  => 25,
            'maximum' => 32,
        ],

        // ───── Dolores ─────
        'insuficiencia' => [
            'minimum' => 2,
            'medium'  => 6,
            'maximum' => 11,
        ],
        'rechazo' => [
            'minimum' => 7,
            'medium'  => 16,
            'maximum' => 23,
        ],

        // ───── Estrategias ─────
        'dependencia' => [
            'minimum' => 1,
            'medium'  => 3,
            'maximum' => 5,
        ],
        'evitacion' => [
            'minimum' => 5,
            'medium'  => 10,
            'maximum' => 13,
        ],
        'obsesividad' => [
            'minimum' => 1,
            'medium'  => 3,
            'maximum' => 7,
        ],
    ];

    /**
     * ───── Mapeo dimensión → curso ─────
     */
    $course_map = [
        'desaprobacion' => 1526,
        'insuficiencia' => 1604,
        'rechazo'       => 1593,
        'dependencia'   => 1443,
        'evitacion'     => 1429,
        'obsesividad'   => 1471,
    ];

    $results = $result['results_type'] ?? [];
    $courses = [];

    /**
     * ─────────────────────────────
     * AMENAZAS
     * ─────────────────────────────
     * Medio o Máximo → asigna
     */
    if ( isset( $results['desaprobacion'] ) ) {
        $p = (int) $results['desaprobacion'];
        $r = $rules['desaprobacion'];

        if ( $p > $r['minimum'] ) {
            $courses[] = $course_map['desaprobacion'];
        }
    }

    /**
     * ─────────────────────────────
     * DOLORES
     * ─────────────────────────────
     */
    $dolores = ['insuficiencia', 'rechazo'];
    $niveles = [];

    foreach ( $dolores as $key ) {

        if ( ! isset( $results[ $key ] ) ) {
            continue;
        }

        $p = (int) $results[ $key ];
        $r = $rules[ $key ];

        if ( $p > $r['medium'] ) {
            $niveles[ $key ] = 'max';
        } elseif ( $p > $r['minimum'] ) {
            $niveles[ $key ] = 'med';
        } else {
            $niveles[ $key ] = 'low';
        }
    }

    // 1️⃣ Si hay MAX → asigna solo los MAX
    if ( in_array( 'max', $niveles, true ) ) {

        foreach ( $niveles as $key => $level ) {
            if ( $level === 'max' ) {
                $courses[] = $course_map[ $key ];
            }
        }

    // 2️⃣ Ambos en MEDIO → asigna ambos
    } elseif (
        count( $niveles ) === 2 &&
        count( array_unique( $niveles ) ) === 1 &&
        current( $niveles ) === 'med'
    ) {

        foreach ( $niveles as $key => $level ) {
            $courses[] = $course_map[ $key ];
        }

    // 3️⃣ MEDIO + BAJO → asigna solo el MEDIO
    } elseif ( in_array( 'med', $niveles, true ) ) {

        foreach ( $niveles as $key => $level ) {
            if ( $level === 'med' ) {
                $courses[] = $course_map[ $key ];
            }
        }
    }
    // 4️⃣ Ambos BAJO → no asigna nada

    /**
     * ─────────────────────────────
     * ESTRATEGIAS
     * ─────────────────────────────
     */
    $estrategias = ['dependencia', 'evitacion', 'obsesividad'];
    $niveles = [];

    foreach ( $estrategias as $key ) {

        if ( ! isset( $results[ $key ] ) ) {
            continue;
        }

        $p = (int) $results[ $key ];
        $r = $rules[ $key ];

        if ( $p > $r['medium'] ) {
            $niveles[ $key ] = 'max';
        } elseif ( $p > $r['minimum'] ) {
            $niveles[ $key ] = 'med';
        } else {
            $niveles[ $key ] = 'low';
        }
    }

    // 1️⃣ Todos MAX
    if (
        count( $niveles ) === 3 &&
        count( array_unique( $niveles ) ) === 1 &&
        current( $niveles ) === 'max'
    ) {

        foreach ( $niveles as $key => $level ) {
            $courses[] = $course_map[ $key ];
        }

    // 2️⃣ Todos MEDIO
    } elseif (
        count( $niveles ) === 3 &&
        count( array_unique( $niveles ) ) === 1 &&
        current( $niveles ) === 'med'
    ) {

        foreach ( $niveles as $key => $level ) {
            $courses[] = $course_map[ $key ];
        }

    // 3️⃣ Hay MAX (con o sin MEDIO) → solo MAX
    } elseif ( in_array( 'max', $niveles, true ) ) {

        foreach ( $niveles as $key => $level ) {
            if ( $level === 'max' ) {
                $courses[] = $course_map[ $key ];
            }
        }

    // 4️⃣ MEDIOS + BAJOS → solo MEDIOS
    } elseif ( in_array( 'med', $niveles, true ) ) {

        foreach ( $niveles as $key => $level ) {
            if ( $level === 'med' ) {
                $courses[] = $course_map[ $key ];
            }
        }
    }
    // 5️⃣ Todos BAJO → no asigna nada

    /**
     * ───── Limpieza y asignación final ─────
     */
    $courses = array_values( array_unique( $courses ) );
    assign_courses_to_logged_user( $courses );
}




/**
 * Asigna múltiples cursos de LearnDash al usuario logueado
 *
 * @param array $course_codes IDs de cursos LearnDash
 * @return bool
 */
function assign_courses_to_logged_user(array $course_codes): bool
{
    $user_id = get_current_user_id();

    if (!$user_id) {
        error_log('assign_courses_to_logged_user: Usuario no logueado');
        return false;
    }

    if (empty($course_codes)) {
        error_log('assign_courses_to_logged_user: course_codes vacío');
        return false;
    }

    // Eliminar duplicados por seguridad
    $course_codes = array_unique($course_codes);

    foreach ($course_codes as $course_id) {

        // Validar que sea un ID numérico
        $course_id = (int) $course_id;

        if ($course_id <= 0) {
            continue;
        }

        // Validar que el curso exista
        if (get_post_type($course_id) !== 'sfwd-courses') {
            error_log("Curso inválido: {$course_id}");
            continue;
        }

        // Asignar acceso al curso
        ld_update_course_access($user_id, $course_id, false);

        error_log("Curso asignado: {$course_id} al usuario {$user_id}");
    }

    return true;
}

/**
 * Asigna cursos adicionales de LearnDash a un usuario
 * sin afectar los cursos que ya tiene.
 */
function asignar_cursos_adicionales_learndash( int $user_id, array $course_ids ): bool {

    if ( ! function_exists('ld_update_course_access') ) {
        return false;
    }

    foreach ( $course_ids as $course_id ) {
        $course_id = (int) $course_id;

        if ( $course_id <= 0 ) {
            continue;
        }

        // Validar que sea un curso LearnDash
        if ( get_post_type( $course_id ) !== 'sfwd-courses' ) {
            continue;
        }

        // Evitar reasignar si ya tiene acceso
        if ( ld_course_check_user_access( $course_id, $user_id ) ) {
            continue;
        }

        // Asignar acceso (curso adicional)
        ld_update_course_access( $user_id, $course_id, false );
    }

    return true;
}

/**
 * ------------------------------------------------------
 * Evento post-pago para producto 797 (robusto e idempotente)
 * ------------------------------------------------------
 *
 * @param int $order_id
 * @return void
 */
function ms_evento_producto_797_post_pago( int $order_id ): void {

    // --------------------------------------------------
    // Validaciones iniciales
    // --------------------------------------------------
    if ( empty( $order_id ) ) {
        return;
    }

    $order = wc_get_order( $order_id );
    if ( ! $order || ! $order->is_paid() ) {
        return;
    }

    // --------------------------------------------------
    // Evitar ejecución doble (idempotencia)
    // --------------------------------------------------
    if ( $order->get_meta( '_ms_evento_797_ejecutado' ) === 'yes' ) {
        return;
    }

    // --------------------------------------------------
    // Verificar si la orden contiene el producto objetivo
    // --------------------------------------------------
    $target_product_id = 797;
    $contains_product  = false;

    foreach ( $order->get_items( 'line_item' ) as $item ) {
        $product_id   = (int) $item->get_product_id();
        $variation_id = (int) $item->get_variation_id();

        if ( $product_id === $target_product_id || $variation_id === $target_product_id ) {
            $contains_product = true;
            break;
        }
    }

    if ( ! $contains_product ) {
        return;
    }

    // --------------------------------------------------
    // Logger profesional (WooCommerce > Status > Logs)
    // --------------------------------------------------
    wc_get_logger()->info(
        "Evento 797 ejecutado para la orden #{$order_id}",
        [ 'source' => 'ms_evento_797' ]
    );

    // --------------------------------------------------
    // Lógica de negocio
    // --------------------------------------------------
    $user_id = (int) $order->get_user_id();

    if ( $user_id ) {

        // Recuperar resultados temporales del test
        $question_test_ids_temp = get_user_meta( $user_id, 'question_test_ids_temp', true );

        if ( ! empty( $question_test_ids_temp ) ) {

            // Guardar resultados definitivos
            update_user_meta( $user_id, 'question_test_ids', $question_test_ids_temp );

            // Limpiar metadata temporal
            delete_user_meta( $user_id, 'question_test_ids_temp' );

            // Resetear cursos del usuario (LearnDash)
            ld_remove_all_user_courses( $user_id );

            // Informacion detallada del test.
            $test_results = get_user_test_detailed_results($question_test_ids_temp);
            validate_result($test_results);
        }

        // Asignacion de cursos adicionales.
        $additional_course_ids = [3045];
        asignar_cursos_adicionales_learndash( $user_id, $additional_course_ids );
    }

    // --------------------------------------------------
    // Marcar evento como ejecutado
    // --------------------------------------------------
    $order->update_meta_data( '_ms_evento_797_ejecutado', 'yes' );
    $order->save();
}

/**
 * Hooks del evento post-pago
 */
add_action( 'woocommerce_payment_complete',        'ms_evento_producto_797_post_pago', 10, 1 );
add_action( 'woocommerce_order_status_processing', 'ms_evento_producto_797_post_pago', 10, 1 );
add_action( 'woocommerce_order_status_completed',  'ms_evento_producto_797_post_pago', 10, 1 );
