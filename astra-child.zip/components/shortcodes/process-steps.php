<?php
function process_steps_function() {
	// Determinar si el usuario está logeado
	$is_user_logged_in = is_user_logged_in();
	if (!$is_user_logged_in) {
		return "";
	}

  // TODO: revisar proceso después
  return "";

	// Obtener el tipo de test
	$test_type = "individual";
	if (isset($_GET['test-type'])) {
		$test_type = $_GET['test-type'];
	}

	// Obtener el ID del usuario logueado y las respuestas del test
	$user_id = get_current_user_id();
	$question_test_ids = get_user_meta( $user_id, 'question_test_ids', true );

	// Obtener el estado de pago del test
  $order_key = $_GET['key'];
  $wc_order_id = wc_get_order_id_by_order_key($order_key);
  $order = wc_get_order($wc_order_id);
  // $order_is_processing_or_completed = $order->has_status('processing') OR $order->has_status('completed');
  $order_is_processing_or_completed = true;

	// Obtener estado de resultados del test

  if(!is_admin()) {
    wp_enqueue_style( 'process-steps-styles', get_stylesheet_directory_uri() . '/components/shortcodes/process-steps.css' );

    ob_start();
    ?>
    <div class="process-steps">
      <div class="process-step process-step--completed">
        <div class="process-step__img-container">
          <img
						src="<?php echo get_site_url(); ?>/wp-content/uploads/2026/01/CheckStepsResultados.png"
						class="process-step__img"
						alt="check"
					>
        </div>
        <p class="process-step__description">
          Registro y Creación de Cuenta
        </p>
      </div>

      <div class="process-step <?php echo $question_test_ids ? 'process-step--completed' : ''; ?>">
        <div class="process-step__img-container">
          <img
						src="<?php echo $question_test_ids ? get_site_url() . '/wp-content/uploads/2026/01/CheckStepsResultados.png' : get_site_url() . '/wp-content/uploads/2025/03/file-text.svg'; ?>"
						class="process-step__img"
						alt="test"
					>
        </div>
        <p class="process-step__description">
          Realiza la evaluación de dependencia
        </p>
      </div>

      <div class="process-step <?php echo $order_is_processing_or_completed ? 'process-step--completed' : ''; ?>">
        <div class="process-step__img-container"> 
          <img 
            src="<?php echo $order_is_processing_or_completed ? get_site_url() . '/wp-content/uploads/2025/03/check.svg' : get_site_url(); '/wp-content/uploads/2025/03/credit-card.svg'; ?>" 
            class="process-step__img">
        </div>
        <p class="process-step__description">
          Pago de la evaluación
					<br>
					<span>
						<b>
							<?php
								if ($test_type == "individual") {
									echo '$167 USD';
								}
							?>
						</b>
					</span>
        </p>
      </div>

      <div class="process-step">
        <div class="process-step__img-container">
          <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/pie-chart.svg" class="process-step__img">
        </div>
        <p class="process-step__description">
          Se Generan los Resultados
        </p>
      </div>
    </div>
    <?php
    return ob_get_clean();
  }
}
add_shortcode('process_steps', 'process_steps_function');



/* Pasos para la paginacion de preguntas */


add_action('wp_enqueue_scripts', function () {

  wp_enqueue_style('my-watupro-style', get_stylesheet_uri(), array(), null);
  wp_enqueue_script('jquery');

  // ===== CONFIG =====
  $QUIZ_ID = 3;          // Quiz ID
  $TOTAL_PAGES = 3;      // 23 preguntas / 10 por página = 3
  $COLOR = '#7a5af8';    // color

  // ===== CSS =====
  $css = "
  :root{ --my-progress-color: {$COLOR}; --my-progress-line:#bdbdbd; }
   #watupro-progress-container-3{ display:none !important; }

  form#quiz-{$QUIZ_ID} .my-watupro-steps{
    display:flex; justify-content:space-between; align-items:center;
    position:relative; gap:14px; padding:14px 6px; margin:0 0 14px 0; max-width:720px;
  }
  form#quiz-{$QUIZ_ID} .my-watupro-steps:before{
    content:''; position:absolute; left:6px; right:6px; top:50%;
    height:2px; background:var(--my-progress-line); transform:translateY(-50%); z-index:0;
  }
  form#quiz-{$QUIZ_ID} .my-watupro-steps .step{
    width:24px; height:24px; border-radius:999px;
    border:2px solid var(--my-progress-line); background:#fff; color:#444;
    display:inline-flex; align-items:center; justify-content:center;
    font-size:12px; line-height:1; position:relative; z-index:1; box-sizing:border-box;
  }
  form#quiz-{$QUIZ_ID} .my-watupro-steps .step.is-active{
    background:var(--my-progress-color); border-color:var(--my-progress-color); color:#fff;
  }
  form#quiz-{$QUIZ_ID} .my-watupro-steps .step.is-done{
    border-color:var(--my-progress-color);
  }

  /* Opcional: ocultar barra original */
  /* #watupro-progress-container-{$QUIZ_ID}{ display:none !important; } */
  ";
  wp_add_inline_style('my-watupro-style', $css);

  // ===== JS =====
  $js = "
  (function($){
    var QUIZ_ID = {$QUIZ_ID};
    var TOTAL_PAGES = {$TOTAL_PAGES};

    function formEl(){
      return document.getElementById('quiz-' + QUIZ_ID);
    }

    function ensureBar(){
      var f = formEl();
      if(!f) return null;

      var bar = f.querySelector(':scope > .my-watupro-steps');
      if(bar) return bar;

      bar = document.createElement('div');
      bar.className = 'my-watupro-steps';
      f.insertBefore(bar, f.firstChild);
      return bar;
    }

    // LA CLAVE: detectar cuál catDiv está visible (paginación real)
    function currentPage(){
      // WatuPRO usa divs con class watupro_catpage: catDiv1, catDiv2, catDiv3 (lo ves en tu inspector)
      var pages = document.querySelectorAll('form#quiz-' + QUIZ_ID + ' .watupro_catpage');
      if(!pages.length) return 1;

      for(var i=0;i<pages.length;i++){
        var st = window.getComputedStyle(pages[i]);
        if(st.display !== 'none' && st.visibility !== 'hidden'){
          // i es 0-based -> página 1..N
          return i + 1;
        }
      }
      return 1;
    }

    function render(){
      var bar = ensureBar();
      if(!bar) return;

      var cp = currentPage();
      if(cp < 1) cp = 1;
      if(cp > TOTAL_PAGES) cp = TOTAL_PAGES;

      bar.innerHTML = '';
      for(var i=1;i<=TOTAL_PAGES;i++){
        var d = document.createElement('div');
        d.className = 'step' + (i < cp ? ' is-done' : '') + (i === cp ? ' is-active' : '');
        d.textContent = i;
        bar.appendChild(d);
      }
    }

    $(function(){
      render();

      // Botones siguiente/atrás
      $(document).on('click', '#next-question, #prev-question', function(){
        setTimeout(render, 80);
      });

      // Si navega por AJAX (común en WatuPRO)
      $(document).ajaxComplete(function(){
        setTimeout(render, 30);
      });

      // Respaldo
      setInterval(function(){
        if(formEl()) render();
      }, 800);
    });
  })(jQuery);
  ";
  wp_add_inline_script('jquery', $js, 'after');
});
