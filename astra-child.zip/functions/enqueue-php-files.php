<?php

// Incluir archivos necesarios
require_once get_stylesheet_directory() . '/functions/enqueue-scripts.php';
require_once get_stylesheet_directory() . '/functions/actions.php';
require_once get_stylesheet_directory() . '/functions/filters.php';
require_once get_stylesheet_directory() . '/functions/helpers.php';

// Archivos del módulo AUTH
require_once get_stylesheet_directory() . '/app/auth/ajax/verify-login.php';
require_once get_stylesheet_directory() . '/app/auth/ajax/custom-login.php';
require_once get_stylesheet_directory() . '/app/auth/ajax/custom-signup.php';
require_once get_stylesheet_directory() . '/app/auth/ajax/custom-logout.php';
require_once get_stylesheet_directory() . '/app/auth/routes-protection.php';

/**
 *  
 * Archivos del módulo de envío de correos
 * 
**/
// HTML
require_once get_stylesheet_directory() . '/app/emails/html/couple-email-html.php';
require_once get_stylesheet_directory() . '/app/emails/html/welcome-email-html.php';
require_once get_stylesheet_directory() . '/app/emails/html/results-email-html.php';
require_once get_stylesheet_directory() . '/app/emails/html/course-email-html.php';
// AJAX
require_once get_stylesheet_directory() . '/app/emails/ajax/ajax-send-couple-email.php';
// Funciones reutilizables para llamar desde cualquier parte del código
require_once get_stylesheet_directory() . '/app/emails/functions/send-couple-email.php';
require_once get_stylesheet_directory() . '/app/emails/functions/send-welcome-email.php';
require_once get_stylesheet_directory() . '/app/emails/functions/send-results-email.php';
require_once get_stylesheet_directory() . '/app/emails/functions/send-course-email.php';

// Archivo de validaciones generales sobre diferentes rutas
require_once get_stylesheet_directory() . '/functions/routes-validations.php';

// Archivos del módulo Test
require_once get_stylesheet_directory() . '/app/test/ajax/save-test.php';

// Archivos del módulo de parejas
require_once get_stylesheet_directory() . '/app/couples/ajax/match-couple.php';
require_once get_stylesheet_directory() . '/app/couples/ajax/validate-couple.php';

// Archivo para validar el menú lateral izquierdo del dashboard (YITH)
require_once get_stylesheet_directory() . '/app/yith/my-account-menu.php';

// Archivos del módulo de resultados
require_once get_stylesheet_directory() . '/app/results/ajax/get-test-results.php';

// Asignacion de cursos.
require_once get_stylesheet_directory() . '/app/courses/ajax/assign-course-ids-to-users.php';

// Visulizar items del menu si hizo el test
require_once get_stylesheet_directory() . '/app/item-menu/ajax/view-item-menu.php';

// Archivos del módulo de productos
require_once get_stylesheet_directory() . '/app/products/ajax/add-course-to-cart.php';
require_once get_stylesheet_directory() . '/app/products/ajax/add-all-courses-to-cart.php';
require_once get_stylesheet_directory() . '/app/products/ajax/validate-user-bought-tests.php';

// Archivos de queries personalizados
require_once get_stylesheet_directory() . '/app/queries/user-queries.php';

// Archivo de constantes globalizadas
require_once get_stylesheet_directory() . '/app/constants.php';
