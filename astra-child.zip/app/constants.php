<?php

class AppConstants {
  // tipos de test particulares
  public const TEST_TYPE_PADRES   = 'padres';
  public const TEST_TYPE_PAREJAS  = 'pareja';
  public const TEST_TYPE_PERSONAL = 'personal';

  // Clases CSS de las páginas de los resultados (deben in sin puntos)
  public const PAGE_RESULT_PADRES   = 'page-id-1120';
  public const PAGE_RESULT_PAREJAS  = 'page-id-1757';
  public const PAGE_RESULT_PERSONAL = 'page-id-811';

  // tipos de test para búsqueda con in_array
  public const TESTS_TYPES = [
    self::TEST_TYPE_PADRES,
    self::TEST_TYPE_PAREJAS,
    self::TEST_TYPE_PERSONAL,
  ];

  // IDs de los productos de los tests
  public const TESTS_PRODUCTS_IDS = [
    'padres'   => 1118,
    'pareja'   => 1382,
    'personal' =>  797,
  ];

  // Enlaces de las páginas de resultados
  public const PAGE_RESULT_PADRES_URL = "/resultado-test-padres";
  public const PAGE_RESULT_PAREJAS_URL = "/resultado-test-parejas";
  public const PAGE_RESULT_PERSONAL_URL = "/resultado-test-personal-completo";

  // Enlaces de las páginas de resultados por tipo de test
  public const TEST_RESULT_URL_BY_TYPE = [
    'padres'   => self::PAGE_RESULT_PADRES_URL,
    'pareja'  => self::PAGE_RESULT_PAREJAS_URL,
    'personal' => self::PAGE_RESULT_PERSONAL_URL
  ];

  // ID del producto que contiene todos los cursos de estrategias
  public const ALL_STRATEGIES_COURSES_PRODUCT_ID = 1658;

  // ID del producto que contiene todos los cursos de amenazas
  public const ALL_THREATS_COURSES_PRODUCT_ID = 1662;

  // ID del producto que contiene todos los cursos de oportunidades de mejora
  public const ALL_OPPORTUNITIES_COURSES_PRODUCT_ID = 1661;

  // IDs del producto que contiene todos los cursos del IDP
  public const ALL_COURSES_PRODUCT_ID = 1664;

  // IDs de los productos de los cursos de estrategias
  public const STRATEGIES_COURSES_PRODUCTS_IDS = [
    1635, // La estrategia obsesiva
    1650, // La estrategia narcisista
    1651, // La estrategia dependiente
    1652, // La estrategia evitativa
    1653, // La estrategia histriónica
    1655, // La estrategia paranóica
    1636, // La estrategia antisocial
  ];

  // IDs de los productos de los cursos de amenazas
  public const THREATS_COURSES_PRODUCTS_IDS = [
    1641, // La amenaza de la ineficiencia
    1645, // La amenaza de la exposición social
    1644, // La amenaza de la traición
    1643, // La amenaza de la desaprobación
    1642, // La amenaza de la descalificación
    1648, // La amenaza de la indiferencia
    1646, // La amenaza de la subestimación
    1649, // La amenaza de la coercion
  ];

  // IDs de los productos de los cursos de oportunidades de mejora
  public const OPPORTUNITIES_COURSES_PRODUCTS_IDS = [
    1640, // Alcanzar la suficiencia
    1638, // Del rechazo a la aceptación
    1659, // Del desamor al amor
    1657, // Trabajar el aprecio
  ];

  // ID del producto del módulo de matrícula
  public const ENROLLMENT_MODULE_PRODUCT_ID = [
    1663 // Módulo de matrícula
  ];

  public static function getCoursesProductsIds() {
    return array_merge(
      self::ENROLLMENT_MODULE_PRODUCT_ID,
      self::STRATEGIES_COURSES_PRODUCTS_IDS,
      self::THREATS_COURSES_PRODUCTS_IDS,
      self::OPPORTUNITIES_COURSES_PRODUCTS_IDS
    );
  }

  public static function getCoursesBundlesIds() {
    return array(
      self::ALL_STRATEGIES_COURSES_PRODUCT_ID,
      self::ALL_THREATS_COURSES_PRODUCT_ID,
      self::ALL_OPPORTUNITIES_COURSES_PRODUCT_ID,
      self::ALL_COURSES_PRODUCT_ID
    );
  }

  public static function urlComprarTestByType($test_type) {
    // Recuperar el ID del producto que se va a agregar al carrito
    $product_id = self::TESTS_PRODUCTS_IDS[$test_type];
    return wc_get_checkout_url() . '?add-to-cart=' . $product_id . '&quantity=1';
  }

  public static function urlComprarTestById($product_id) {
    // Recuperar el tipo de test a partir del ID del producto
    return wc_get_checkout_url() . '?add-to-cart=' . $product_id . '&quantity=1';
  }
}

new AppConstants();
