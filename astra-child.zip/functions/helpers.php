<?php

/**
 * Función general para enviar respuestas en formato JSON.
 * 
 * @param boolen $success Establece si la respuesta es de error de éxito (false, true).
 * @param string $code Código de identificación de la respuesta para posteriores validaciones.
 * @param message $message Mensaje de la respuesta para mostrar en el frontend.
 * @param array $data Información adicional que se desee retornar en la respuesta.
 * 
 * @return void.
 */
function send_json_response($success = false, $code = '', $message = '', $data = []) {
    $response = [
        'success' => $success, 
        'code' => $code,
        'message' => $message,
        'data' => $data
    ];

    // Enviar la respuesta en formato JSON
    echo json_encode($response);
    
    // Limpiar los datos POST si es necesario
    unset($_POST);

    // Detener la ejecución para evitar que el script continúe
    wp_die();
}

/**
 * Función general para enviar correos.
 * 
 * @param string $recipient la dirección de correo electrónico del destinatario.
 * @param string $subject asunto del correo.
 * @param string $message el cuerpo del mensaje en formato HTML.
 * 
 * @return void.
 */
function send_email($recipient, $subject, $message) {
    // Obtiene el objeto WC_Emails
    $mailer = WC()->mailer();

    // Establecemos los headers
    $headers = "Content-Type: text/html\r\n";

    // Envía el mensaje al correo electrónico de la segunda pareja
    return $mailer->send($recipient, $subject, $message, $headers);
}
