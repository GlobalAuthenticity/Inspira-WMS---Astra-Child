<?php

/**
 * @description
 * Registra un nuevo usuario mediante Ajax.
 */
if (!function_exists('custom_signup_user')) {
  function custom_signup_user() {
    if (defined( 'DOING_AJAX' ) && DOING_AJAX) {
        $fields = $_POST['fields'];

        // Verificar si el correo ya está registrado
        $user = get_user_by('email', sanitize_email($fields['email']));
        if ($user) {
            send_json_response(false, 'error', 'El correo electrónico ya está registrado.');
            return;
        }

        // Extraer datos del formulario
        $email = sanitize_email($fields['email']);
        $name = sanitize_text_field($fields['name']);
        $phone = sanitize_text_field($fields['phone']);
        $country = sanitize_text_field($fields['country']);
        $children = sanitize_text_field($fields['children']);
        $password = $fields['password'];
        $last_name = sanitize_text_field($fields['lastname']);
        $marital_status = sanitize_text_field($fields['maritalStatus']);

        // Extraer tipo de test y pareja2 de los datos enviados
        $test_type = isset($_POST['test_type']) ? sanitize_text_field($_POST['test_type']) : 'individual';

        $userdata = array(
            'user_login' => $email,
            'user_email' => $email,
            'user_pass'  => $password,
            'first_name' => $name,
            'last_name'  => $last_name,
            'role'       => 'subscriber'
        );

        // Remover TODOS los hooks de user_register temporalmente
        global $wp_filter;
        $original_filters = isset($wp_filter['user_register']) ? $wp_filter['user_register'] : null;
        unset($wp_filter['user_register']);

        // Crear el usuario
        $user_id = wp_insert_user($userdata);

        // Restaurar los hooks
        if ($original_filters) {
            $wp_filter['user_register'] = $original_filters;
        }

        // Capturar y descartar cualquier output que se haya generado
        $unwanted_output = ob_get_clean();
        if (!empty($unwanted_output)) {
            error_log('Output capturado y descartado: ' . $unwanted_output);
        }

        if (is_wp_error($user_id)) {
            send_json_response(false, 'error', 'Error al crear el usuario. Por favor, inténtelo más tarde.');
            return;
        }

        // Agregar metadatos del usuario
        update_user_meta($user_id, 'user_phone_number', $phone);
        update_user_meta($user_id, 'country', $country);
        update_user_meta($user_id, 'user_marital_status', $marital_status);
        update_user_meta($user_id, 'user_has_children', $children);

        // Auto loguear al usuario
        wp_clear_auth_cookie();
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);

        // Obtener la URL de redirección
        $redirect_url = get_site_url() . '/test/?test-type=' . $test_type;

        // Enviar respuesta exitosa con la URL de redirección
        send_json_response(true, 'success', 'Usuario registrado exitosamente.', array('redirect_url' => $redirect_url));
    }
  }
}

// Ajax
add_action('wp_ajax_nopriv_custom_signup_user', 'custom_signup_user');
add_action('wp_ajax_custom_signup_user', 'custom_signup_user');