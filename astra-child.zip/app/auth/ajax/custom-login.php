<?php

// Ajax
add_action('wp_ajax_nopriv_custom_login', 'custom_login');
add_action('wp_ajax_custom_login', 'custom_login');

/**
 * @description
 * Valida si el usuario se encuentra logueado
 */
if (!function_exists('custom_login')) {
  function custom_login() {
    if (defined( 'DOING_AJAX' ) && DOING_AJAX) {
      $email = sanitize_email($_POST['email']);
      $password = sanitize_text_field($_POST['password']);

      $creds = array(
        'user_login'    => $email,
        'user_password' => $password,
        'remember'      => true
      );

      $user = get_user_by('email', $email);

      if (!$user || !wp_check_password($password, $user->data->user_pass, $user->ID)) {
        send_json_response(false, 'error', 'Correo electrónico o contraseña incorrectos.');
      } else {
        wp_clear_auth_cookie();
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true, is_ssl());

        update_user_meta($user->ID, 'last_login', current_time('mysql'));

        $data = array(
          'redirect_url' => get_site_url() . '/mi-cuenta/panel-usuario/panel-usuario/',
        );
        
        send_json_response(true, 'success', 'Inicio de sesión exitoso.', $data);
      }
    }
  }
}

