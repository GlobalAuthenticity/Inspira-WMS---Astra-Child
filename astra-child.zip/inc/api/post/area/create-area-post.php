<?php

add_action('rest_api_init', function () {
    register_rest_route('aprobandome/v1', '/areas', [
        'methods'             => 'POST',
        'callback'            => 'aprobandome_create_area',
        'permission_callback' => 'aprobandome_api_create_area_check_token', // luego puedes protegerlo
    ]);
});

/**
 * Validación del token Bearer
 */
function aprobandome_api_create_area_check_token( WP_REST_Request $request ) {

    $auth_header = $request->get_header('authorization');

    if ( ! $auth_header || ! str_starts_with($auth_header, 'Bearer ') ) {
        return new WP_Error(
            'unauthorized',
            'Missing Authorization header',
            ['status' => 401]
        );
    }

    $token_received = trim(str_replace('Bearer', '', $auth_header));
    $valid_token    = get_option('aprobandome_create_area');

    if ( ! hash_equals($valid_token, $token_received) ) {
        return new WP_Error(
            'unauthorized',
            'Invalid API token',
            ['status' => 403]
        );
    }

    return true;
}

function aprobandome_create_area( WP_REST_Request $request ) {
    global $wpdb;

    $table = $wpdb->prefix . 'areas';
    $data  = $request->get_json_params();

    // Validar campos obligatorios
    $required_fields = ['nombre', 'cupo', 'estado', 'grupo_id'];

    foreach ($required_fields as $field) {
        if ( empty($data[$field]) ) {
            return new WP_REST_Response([
                'success' => false,
                'message' => "El campo '{$field}' es obligatorio"
            ], 400);
        }
    }

    // Preparar datos para insertar
    $insert_data = [
        'nombre'           => sanitize_text_field($data['nombre']),
        'cupo'             => intval($data['cupo']),
        'estado'           => sanitize_text_field($data['estado']),
        'tipo'             => !empty($data['tipo']) ? sanitize_text_field($data['tipo']) : null,
        'grupo_id'         => intval($data['grupo_id']),
        'fecha_expiracion' => !empty($data['fecha_expiracion'])
            ? sanitize_text_field($data['fecha_expiracion'])
            : null,
    ];

    $formats = [
        '%s', // nombre
        '%d', // cupo
        '%s', // estado
        '%s', // tipo
        '%d', // grupo_id
        '%s', // fecha_expiracion
    ];

    // Insertar en la BD
    $result = $wpdb->insert($table, $insert_data, $formats);

    if ( $result === false ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Error al crear el área',
            'error'   => $wpdb->last_error
        ], 500);
    }

    // Retornar ID creado
    return new WP_REST_Response([
        'success' => true,
        'message' => 'Área creada correctamente',
        'area_id' => $wpdb->insert_id
    ], 201);
}
