<?php
function get_sitemadi_results_email( $results_url ) {

    ob_start();
    ?>
   <!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
@media only screen and (max-width:480px){
  .container{width:100%!important;border-radius:0!important}
  .content{padding:20px!important}
  h1{font-size:22px!important}
  p{font-size:14px!important}
  .btn{font-size:14px!important;padding:12px 18px!important}
}
</style>
</head>

<body style="margin:0;padding:0;background:#f3f3f3;font-family:Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td align="center">

<table class="container" width="600" cellpadding="0" cellspacing="0" role="presentation"
style="max-width:600px;background:#ffffff;border-radius:26px;overflow:hidden;">

<!-- HEADER -->
<tr>
<td style="padding:20px 24px;text-align:left;">
  <img src="http://aprobandome.com/wp-content/uploads/2025/12/Compras-Emails-Aprobandome.png"
       alt="Aprobándome"
       width="150"
       style="display:block;border:0;">
</td>
</tr>

<!-- HERO CON CURVA -->
<tr>
<td style="padding:0;">
  <img src="http://aprobandome.com/wp-content/uploads/2025/12/Test-dependencia.png"
       alt="Resultados del test"
       width="450"
       style="
         display:block;
         margin:0 auto;
         width:100%;
         max-width:450px;
         border-radius:0 0 120px 0;
       ">
</td>
</tr>

<!-- CONTENIDO -->
<tr>
<td class="content" style="padding:28px 32px;color:#111;">

  <!-- TITULO -->
  <h1 style="margin:0 0 12px;font-size:26px;font-weight:700;">
    ¡Ya puedes ver tu evaluación! 🧠
  </h1>

  <!-- TEXTO -->
  <p style="margin:0 0 16px;font-size:16px;line-height:1.6;color:#333;">
    Gracias por completar tu evaluación.
    Tu informe ya está listo y contiene información esencial sobre ti,
    tus vínculos y los patrones que influyen en tu forma de relacionarte.
  </p>

  <!-- BLOQUE DESTACADO -->
  <table width="100%" cellpadding="0" cellspacing="0" role="presentation"
         style="background:#8867B0;border-radius:18px;margin:20px 0;">
    <tr>
      <td style="padding:18px;font-size:15px;line-height:1.6;color:#ffffff;">
        Tómate un momento para leerlo con calma,
        dejar que cada idea aterrice y conectar con lo que resuena contigo.
        Este es un paso importante en tu proceso.
      </td>
    </tr>
  </table>

  <!-- BOTON -->
  <a href="https://aprobandome.com/resultado-test-personal-completo/"
     target="_blank"
     class="btn"
     style="
       display:inline-block;
       background:#000;
       color:#fff;
       text-decoration:none;
       font-size:16px;
       padding:14px 28px;
       border-radius:30px;
     ">
    Ver mis resultados
  </a>

</td>
</tr>

<!-- FOOTER (MISMO QUE EMAIL ANTERIOR) -->
<tr>
<td style="background:#2e2b3a;padding:32px;color:#e6e6e6;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation">

<tr>
<td valign="top" style="padding-bottom:20px;">
  <strong style="font-size:16px;color:white;">Contacto</strong><br>
  <span style="font-size:14px;line-height:1.6;">
    848 Brickell Ave<br>
    Suite 950 Miami<br>
    Fl. 33131<br>
    <a href="mailto:info@aprobandome.com" style="color:#e6e6e6;text-decoration:none;">
      info@aprobandome.com
    </a>
  </span>
</td>

<td valign="top" style="padding-bottom:20px;">
  <strong style="font-size:16px;color:#fff;">Síguenos</strong><br><br>

  <a href="https://www.instagram.com/aprobandome" target="_blank" style="margin-right:14px;">
    <img src="http://aprobandome.com/wp-content/uploads/2025/12/Icon.png"
         width="24" style="display:inline-block;border:0;">
  </a>

</td>

<td valign="top">
  <strong style="font-size:16px;color:#fff;">Grupo empresarial</strong><br>
  <span style="font-size:14px;line-height:1.8;">
    <a href="https://efrenmartinezortiz.com/" target="_blank" style="color:#e6e6e6;text-decoration:none;">Dr. Efren Martínez Ortiz</a><br>
    <a href="https://wmslatam.com/" target="_blank" style="color:#e6e6e6;text-decoration:none;">WMS</a><br>
    <a href="https://terapiaunclick.com/" target="_blank" style="color:#e6e6e6;text-decoration:none;">TClick</a><br>
    <a href="https://colectivoaquiyahora.org/" target="_blank" style="color:#e6e6e6;text-decoration:none;">Colectivo Aquí y Ahora</a><br>
    <a href="https://saps-col.org/" target="_blank" style="color:#e6e6e6;text-decoration:none;">SAPS</a>
  </span>
</td>
</tr>

</table>

<p style="font-size:12px;color:#aaa;text-align:center;margin-top:24px;">
  © 2026 Global Authenticity LLC Todos los derechos reservados
</p>

</td>
</tr>

</table>
</td>
</tr>
</table>

</body>
</html>
<?php
return ob_get_clean();
}
?>