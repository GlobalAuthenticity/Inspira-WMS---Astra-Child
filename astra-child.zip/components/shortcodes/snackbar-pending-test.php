<?php

function snackbar_pending_test_function($atts) {
    global $wpdb;

    // Consultar el id del usuario actual.
    $user_id = get_current_user_id();

    // Verificar si el usuario está logeado.
    if (!$user_id) {
      return '';
    }

    // Solo mostrar a usuarios con rol subscriber.
    $user = wp_get_current_user();
    if ( ! in_array( 'subscriber', (array) $user->roles, true ) ) {
      return '';
    }

    // Verificar si el usuario ha realizado el test.
    $question_test_ids = get_user_meta($user_id, 'question_test_ids', true);

    if ($question_test_ids) {
      // Si ya se realizó el test, se retorna un string vacío.
      return '';
    }

    // Si no se ha realizado el test, se muestra la advertencia.
    if(!is_admin()) {
      wp_enqueue_style( 'snackbar-pending-test-styles', get_stylesheet_directory_uri() . '/components/shortcodes/snackbar-pending-test.css' );

      $text = '';
      if ($atts && $atts["size"] == 'lg') {
        $text = 'Aún no has hecho tu test de dependencia. Postergarlo es seguir dejándote para después. Este test es el primer paso para entender por qué te cuesta elegirte y por qué repites ciertos patrones. Hazlo ahora, no para cambiarte, sino para dejar de abandonarte.';
      } else if ($atts && $atts["size"] == 'sm' || !$atts) {
        $text = 'Es necesario para comenzar tu programa de desarrollo personal.';
      }

      ob_start();
      ?>
        <div class="snackbar snackbar--danger">
          <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2024/09/Alert-triangle.svg" alt="">

          <div class="text-container">
            <span class="title">Test de dependencia pendiente</span>
            <span class="text">
              <?php echo $text; ?>
            </span>
          </div>

          <a 
            class="pending-test-link" 
            href="https://aprobandome.wmslatam.com/test/?test-type=individual"
            onclick="window.location.href=this.href; return true;"
          >
            Realizar test
          </a>
        </div>
      <?php
      return ob_get_clean();
    }
}
add_shortcode('pending_test', 'snackbar_pending_test_function');


