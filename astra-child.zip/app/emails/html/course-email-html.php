<?php

/**
 * Función para generar el HTML del correo de bienvenida.
 * 
 * @param string $account_url URL donde el usuario puede acceder a su cuenta.
 * 
 * @return string HTML del correo.
 */
function get_sitemadi_course_email() {
    // Definir la URL del botón
    $course_url = get_site_url() . '/mi-cuenta/cursos/';

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="es">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style type="text/css">
          /* Reset predeterminado en móviles */
          @media only screen and (max-width:480px) {
            .container { width:100% !important; padding:0 !important; border-radius:0 !important; }
            .header img.logo { float:none !important; margin:0 auto 16px !important; }
            .header div.clearfix { display:none !important; }
            /* Imagen de la chica más grande en móvil */
            .header img.hero { width:90% !important; max-width:300px !important; margin:16px auto !important; }
            .content { padding:16px !important; }
            .content h1 { font-size:24px !important; }
            .content p { font-size:14px !important; }
            .btn { padding:10px 16px !important; font-size:14px !important; }
            .footer td { display:block !important; width:100% !important; padding:12px 0 !important; }
          }
        </style>
      </head>
      <body style="margin:0; padding:0; background-color:#f2f2f2;">
        <div class="container" style="max-width:600px; margin:0 auto; background-color:#EFEEE7; border-radius:16px; overflow:hidden; font-family:Arial,sans-serif; color:#333;">

          <!-- HEADER: logo alineado a la izquierda, imagen centrada -->
          <div class="header" style="background-color:#EFEEE7; padding:24px;">
            <img
              src="https://sistemadi.wpenginepowered.com/wp-content/uploads/2025/03/logo-ids-black.svg"
              alt="Interpersonal Development System"
              width="180"
              class="logo"
              style="display:block; margin:0; float:left;"
            >
            <div class="clearfix" style="clear:both;"></div>
            <img
              src="https://sistemadi.wpenginepowered.com/wp-content/uploads/2025/06/email3.png"
              alt="Curso Disponible"
              class="hero"
              style="display:block; margin:24px auto 0; width:80%; max-width:600px; height:auto;"
            >
          </div>
      
          <!-- CUERPO con texto alineado a la izquierda -->
          <div class="content" style="padding:32px 24px; text-align:left;">
            <h1 style="margin:0 0 16px; font-size:28px; color:#000;">
              ¡Gracias por tu compra! Tu curso ya está disponible<span style="font-size:24px;">🎓</span>
            </h1>
            <p style="margin:0 0 16px; font-size:16px;">
              Hemos confirmado tu inscripción al curso. Estás en un paso de seguir creciendo y transformar tu forma de relacionarte contigo y con los demás.
            </p>
            <p style="margin:0 0 24px; font-size:16px; line-height:1.5;">
              Tu curso ya está disponible, puedes empezar ahora mismo desde tu cuenta de Sitemadi.
            </p>
            <a
              href="<?php echo $course_url; ?>"
              target="_blank"
              class="btn"
              style="display:inline-block; padding:12px 24px; background-color:#F76C5E; color:#ffffff; text-decoration:none; font-size:16px; border-radius:20px;"
            >
              Iniciar mi curso
            </a>
          </div>
      
          <!-- FOOTER -->
          <div class="footer" style="background-color:#2A2732; color:#E0E0E0; padding:24px;">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <!-- Contacto -->
                <td valign="top" style="padding-right:16px;">
                  <p style="margin:0 0 8px; font-size:18px; font-weight:bold; color:#ffffff;">Contacto</p>
                  <p style="margin:4px 0; font-size:14px; line-height:1.4;">
                    848 Brickell Ave<br>
                    Suite 950 Miami<br>
                    Fl. 33131<br>
                    <a href="mailto:info@wmslatam.com" style="color:#E0E0E0; text-decoration:none;">info@wmslatam.com</a>
                  </p>
                </td>
        
                <!-- Síguenos -->
                <td valign="top" style="padding-right:16px;">
                  <p style="margin:0 0 8px; font-size:18px; font-weight:bold; color:#ffffff;">Síguenos</p>
                  <p style="margin:4px 0;">
                    <a href="https://www.instagram.com/sistemadin?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank" style="display:inline-block; margin-right:8px;">
                      <img
                        src="https://sistemadi.wpenginepowered.com/wp-content/uploads/2025/03/Instagram.svg"
                        alt="Instagram"
                        width="24" height="24"
                        style="display:block; border:0;"
                      >
                    </a>
                  </p>
                </td>
        
                <!-- Grupo empresarial -->
                <td valign="top">
                  <p style="margin:0 0 8px; font-size:18px; font-weight:bold; color:#ffffff;">Grupo empresarial</p>
                  <p style="margin:4px 0; font-size:14px; line-height:1.4;">
                    <a href="https://efrenmartinezortiz.com/" target="_blank" style="color:#E0E0E0; text-decoration:none;">Dr. Efren Martínez Ortiz</a><br>
                    <a href="https://wmslatam.com/" target="_blank" style="color:#E0E0E0; text-decoration:none;">WMS</a><br>
                    <a href="https://terapiaunclick.com/" target="_blank" style="color:#E0E0E0; text-decoration:none;">TClick</a><br>
                    <a href="https://colectivoaquiyahora.org/" target="_blank" style="color:#E0E0E0; text-decoration:none;">Colectivo Aquí y Ahora</a><br>
                    <a href="https://saps-col.org/" target="_blank" style="color:#E0E0E0; text-decoration:none;">SAPS</a>
                  </p>
                </td>
              </tr>
            </table>
        
            <p style="font-size:12px; color:#AAA; text-align:center; margin-top:24px;">
              © 2025 IDS, Todos los derechos reservados
            </p>
          </div>
      
        </div>
      </body>
    </html>
    <?php
    return ob_get_clean();
}
?>
