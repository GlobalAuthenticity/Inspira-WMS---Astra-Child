<?php 

function personal_result_review_function() {
  wp_enqueue_style( 'result-review-styles', get_stylesheet_directory_uri() . '/components/shortcodes/personal-result-review.css' );

  if (!is_admin()) {
    ob_start();

    if (is_page('resultado-test-personal-completo')) {
      ?>
      <section class="header-charts">

        <div class="ids-col-test-general"></div>

        <div class="right">
          <h2>Resumen de tus resultados</h2>
          <hr>

          <h3>Dolores</h3>

<div class="areas-wrapper">

  <div class="areas-container areas-alto-container">
    <h4>Alto</h4>
    <div class="areas-items">
      <span class="area-high" id="insuficiencia-alto">Insuficiencia</span>
      <span class="area-high" id="rechazo-alto">Rechazo</span>
    </div>
  </div>

  <div class="areas-container areas-medio-container">
    <h4>Medio</h4>
    <div class="areas-items">
      <span class="area-mid" id="insuficiencia-medio">Insuficiencia</span>
      <span class="area-mid" id="rechazo-medio">Rechazo</span>
    </div>
  </div>

  <div class="areas-container areas-bajo-container">
    <h4>Bajo</h4>
    <div class="areas-items">
      <span class="area-low" id="insuficiencia-bajo">Insuficiencia</span>
      <span class="area-low" id="rechazo-bajo">Rechazo</span>
    </div>
  </div>

</div>

<!-- ===================== -->
<!-- Amenazas -->
<!-- ===================== -->
<h3>Amenazas</h3>

<div class="areas-wrapper">

  <div class="areas-container areas-alto-container">
    <h4>Alto</h4>
    <div class="areas-items">
      <span class="area-high" id="desaprobacion-alto">Desaprobación</span>
    </div>
  </div>

  <div class="areas-container areas-medio-container">
    <h4>Medio</h4>
    <div class="areas-items">
      <span class="area-mid" id="desaprobacion-medio">Desaprobación</span>
    </div>
  </div>

  <div class="areas-container areas-bajo-container">
    <h4>Bajo</h4>
    <div class="areas-items">
      <span class="area-low" id="desaprobacion-bajo">Desaprobación</span>
    </div>
  </div>

</div>

<!-- ===================== -->
<!-- Estrategias -->
<!-- ===================== -->
<h3>Estrategias</h3>

<div class="areas-wrapper">

  <div class="areas-container areas-alto-container">
    <h4>Alto</h4>
    <div class="areas-items">
      <span class="area-high" id="obsesividad-alto">Control obsesivo</span>
      <span class="area-high" id="dependencia-alto">Búsqueda de aprobación</span>
      <span class="area-high" id="evitacion-alto">Evitación social</span>
    </div>
  </div>

  <div class="areas-container areas-medio-container">
    <h4>Medio</h4>
    <div class="areas-items">
      <span class="area-mid" id="obsesividad-medio">Control obsesivo</span>
      <span class="area-mid" id="dependencia-medio">Búsqueda de aprobación</span>
      <span class="area-mid" id="evitacion-medio">Evitación social</span>
    </div>
  </div>

  <div class="areas-container areas-bajo-container">
    <h4>Bajo</h4>
    <div class="areas-items">
      <span class="area-low" id="obsesividad-bajo">Control obsesivo</span>
      <span class="area-low" id="dependencia-bajo">Búsqueda de aprobación</span>
      <span class="area-low" id="evitacion-bajo">Evitación social</span>
    </div>
  </div>

</div>


        </div>
      </section>
      <?php
    }

    return ob_get_clean();
  }
}

add_shortcode('personal_result_review', 'personal_result_review_function');
