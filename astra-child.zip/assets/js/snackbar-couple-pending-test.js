jQuery(document).ready(function($) {
  // Copiar código al clipboard
  $('.snackbar .copy-link-code').on('click', function() {
    const link = $(this).data('link');
    navigator.clipboard.writeText(link)
      .then(() => toastr["success"]("Tu enlace se copió correctamente.", "¡Listo!"));
  });

  // Reenviar correo a la pareja
  $('.snackbar .resend-couple-link').on('click', function() {
    const coupleOneId = $(this).data('couple-one');
    const coupleTwoEmail = $(this).data('couple-email');

    data = {
      coupleOneId,
      coupleTwoEmail,
      action: 'ajax_send_couple_email'
    };
    
    $.ajax({
			url: code_scripts.ajaxurl,
			type: 'POST',
			dataType: "JSON",
			data,
			success: function (response) {
        if (response['success']) {
          toastr["success"](response['message'], "¡Listo!");
        } else {
          throw new Error(response['message']);
        }
			},
			error: function (error) {
        toastr["error"](error.message, "¡Listo!");
			}
		})
  });
});