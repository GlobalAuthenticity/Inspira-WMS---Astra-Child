jQuery(document).ready(function($) {
    const pageSignup = 'page-id-738';
    if($('body').hasClass(pageSignup)) {
        const testType = new URLSearchParams(window.location.search).get('test-type');
    
        $('select').selectize({
            sortField: 'text'
        });

        $('#sistemadi-signup-form').on('submit', function(e) {
            e.preventDefault();

            let errors = [];
            $('.sistemadi-submit-button').attr('disabled', true);
            const { validationSatus, fields } = validateFields();

            if(!validationSatus) {
                return;
            }

            $.ajax({
                url: code_scripts.ajaxurl,
                method: 'POST',
                data: {
                    action: 'custom_signup_user',
                    fields: fields,
                    test_type: testType
                },
                success: function(response) {
                    try {
                        const res = JSON.parse(response);

                        if(!res.success) {
                            errors = [];
                            errors.push({login: res['message']});
                            handleErrors(errors);
                            return;
                        }

                        // Redirigir a la URL proporcionada en la respuesta
                        if (res.data && res.data.redirect_url) {
                            window.location.href = res.data.redirect_url;
                        }
                        
                    } catch (error) {
                        console.log('Error parsing JSON response:', error);
                    }
                },
                error: function() {
                    // Manejar errores de inicio de sesión y mostrarlos en el contenedor de errores
                    errors = [];
                    errors.push({login: 'Error al procesar la solicitud. Por favor, inténtalo de nuevo más tarde.'});
                    handleErrors(errors);
                    return;
                },
                complete: function() {
                    $('.sistemadi-submit-button').attr('disabled', false);
                }
            });
        });

        function validateFields() {
            let errors = [];
            let validationSatus = true;
            const emailRegexValidation = /^\S+@\S+\.\S+$/;

            const name = $('#sistemadi-name').val();
            const lastname = $('#sistemadi-lastname').val();
            const country = $('#sistemadi-country').val();
            const phone = $('#sistemadi-phone').val();
            const maritalStatus = $('#sistemadi-marital-status').val();
            const children = $('#sistemadi-children').val();
            const email = $('#sistemadi-email').val();
            const password = $('#sistemadi-password').val();
            const passwordConfirm = $('#sistemadi-password-confirm').val();

            if(!name) {
                errors.push({name: 'El campo de nombre es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!lastname) {
                errors.push({lastname: 'El campo de apellido es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!country) {
                errors.push({country: 'El campo de país es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!phone) {
                errors.push({phone: 'El campo de número de contacto es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!maritalStatus) {
                errors.push({maritalStatus: 'El campo de estado civil es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!children) {
                errors.push({children: 'El campo de de hijos es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!email) {
                errors.push({email: 'El campo de correo electrónico es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!emailRegexValidation.test(email)) {
                errors.push({email: 'El formato del correo electrónico no es válido.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(!password) {
                errors.push({password: 'El campo de contraseña es obligatorio.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(password.length < 6) {
                errors.push({password: 'La contraseña debe tener al menos 6 caracteres.'});
                handleErrors(errors);
                validationSatus = false;
            }

            if(password !== passwordConfirm) {
                errors.push({passwordConfirm: 'Las contraseñas no coinciden.'});
                handleErrors(errors);
                validationSatus = false;
            }

            return {
                validationSatus, 
                fields: {
                    name,
                    lastname,
                    country,
                    phone,
                    maritalStatus,
                    children,
                    email,
                    password
                }
            };
        }

        function handleErrors(errors) {
            let errorMessages = '';
            errors.forEach(error => {
                for (const key in error) {
                    if (error.hasOwnProperty(key)) {
                        errorMessages += `<p class="sistemadi-auth-error-message">&bull; ${error[key]}</p>`;
                    }
                }
            });
            $('#sistemadi-error-messages').html(errorMessages).show();
            $('.sistemadi-submit-button').attr('disabled', false);

            // Scroll to error messages
            $('html, body').animate({
                scrollTop: $('#sistemadi-error-messages').offset().top - 100
            }, 500);
        }
    
        function clearErrors() {
            $('#sistemadi-error-messages').html('').hide();
        }
    
        $('.sistemadi-password-toggle').on('click', function() { 
            const passwordInput = $('#sistemadi-password');
            const passwordConfirmInput = $('#sistemadi-password-confirm');
            let type = passwordInput.attr('type') === 'password' ? 'text' : 'password';

            passwordInput.attr('type', type);
            passwordConfirmInput.attr('type', type);
        });
    
        $('#sistemadi-signup-form').on('input', function() {
            clearErrors();
        })
    }
});