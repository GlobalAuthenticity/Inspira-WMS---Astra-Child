<?php
/**
 * The header for Astra Theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Astra
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?><!DOCTYPE html>
<?php astra_html_before(); ?>
<html <?php language_attributes(); ?>>
<head>
<?php astra_head_top(); ?>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php 
if ( apply_filters( 'astra_header_profile_gmpg_link', true ) ) {
	?>
	 <link rel="profile" href="https://gmpg.org/xfn/11"> 
	 <?php
} 
?>
<?php wp_head(); ?>
<?php astra_head_bottom(); ?>
</head>

<body <?php astra_schema_body(); ?> <?php body_class(); ?>>
<?php astra_body_top(); ?>
<?php wp_body_open(); ?>

<a
	class="skip-link screen-reader-text"
	href="#content"
	role="link"
	title="<?php echo esc_attr( astra_default_strings( 'string-header-skip-link', false ) ); ?>">
		<?php echo esc_html( astra_default_strings( 'string-header-skip-link', false ) ); ?>
</a>

<div
<?php
	echo astra_attr(
		'site',
		array(
			'id'    => 'page',
			'class' => 'hfeed site',
		)
	);
	?>
>
	<?php
	astra_header_before();

  $user = wp_get_current_user();

  // Para usuarios con rol "subscriber": si tienen first_name y last_name en
  // wp_usermeta, mostrar el nombre completo; si no, mostrar el user_login.
  $sistemadi_desktop_name = $user->first_name;
  $sistemadi_mobile_name  = trim( $user->first_name . ' ' . $user->last_name );

  if ( is_user_logged_in() && in_array( 'subscriber', (array) $user->roles, true ) ) {
    $sistemadi_subscriber_name = ( $user->first_name && $user->last_name )
      ? trim( $user->first_name . ' ' . $user->last_name )
      : $user->user_login;

    $sistemadi_desktop_name = $sistemadi_subscriber_name;
    $sistemadi_mobile_name  = $sistemadi_subscriber_name;
  }

  $menu_items = wp_get_nav_menu_items('Main Header');

  // Verificar si se obtuvieron elementos de menú
  if (!$menu_items) {
      return;
  }

  // Crear un array para organizar los elementos del menú por su relación padre-hijo
  $menu = array();

  // Recorremos cada ítem del menú
  foreach ($menu_items as $menu_item) {
    // Si el ítem no tiene un padre (es un ítem principal)
    if ($menu_item->menu_item_parent == 0) {
        // Lo añadimos como un ítem principal
        $menu[$menu_item->ID] = array(
            'item' => $menu_item,
            'children' => array()
        );
    } else {
        // Si tiene un padre, lo añadimos como hijo del ítem correspondiente
        $menu[$menu_item->menu_item_parent]['children'][] = $menu_item;
    }
  }

  ?>

    <header class="sistemadi-header">
      <a class="sistemadi-header__logo" href="<?php echo get_home_url(); ?>">
        <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2026/01/LogoHomeHeader.png" alt="Logo de Sistemadi">
      </a>

      <nav class="sistemadi-header__navigation-container">
        <ul class="sistemadi-header__navigation">
          <?php
            foreach ( $menu as $m ) {
              ?>
              <li class="sistemadi-header__navigation-item">
             
              
                <?php
                // Si tiene hijos, los imprimimos
                if (!empty($m['children'])) {
                  ?>
                  <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/chevron-down.svg" class="sistemadi-header__navigation-item-arrow">
                  <ul class="sistemadi-header__submenu">
                    <?php
                    foreach ($m['children'] as $child_item) {
                      ?>
                      <li class="sistemadi-header__submenu-item">
                        <a href="<?php echo $child_item->url; ?>">
                          <?php echo $child_item->title; ?>
                        </a>
                      </li>
                      <?php
                    }
                    ?>
                  </ul>
                  <?php
                }
                ?>
              </li>
              <?php
            }
          ?>
        </ul>
      </nav>

      <div class="sistemadi-header__actions">
        <!-- Condición 1: Mostrar el primer div si no hay usuario logueado -->
        <div class="sistemadi-header__login <?php echo (!is_user_logged_in() ? 'sistemadi-show-flex' : 'sistemadi-hide'); ?>">
          <a class="btn" href="/login">
            <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/my-account.svg">
            <span>Mi cuenta</span>
          </a>
        </div>

        <!-- Condición 2: Mostrar este div si el usuario está logueado -->
        <div class="sistemadi-header__actions-container <?php echo (is_user_logged_in() ? 'sistemadi-show-flex' : 'sistemadi-hide'); ?>">
          <a class="sistemadi-header__user-info" href="/mi-cuenta/panel-usuario/panel-usuario">
            <span class="sistemadi-header__username"><?php echo esc_html( $sistemadi_desktop_name ); ?></span>
            <span class="sistemadi-header__email"><?php echo $user->user_email; ?></span>
          </a>
          <a href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjEwOTEiLCJ0b2dnbGUiOmZhbHNlfQ%3D%3D"">
            <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/logout.svg">
          </a>
        </div>
      </div>

       <!-- new movile -->
            <!-- Comienza el contenido del menú móvil -->
      <div class="sistemadi-header__mobile-actions">
        <div class="sistemadi-header__actions-container">
          <button class="sistemadi-header__mobile-menu-toggle">
            <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/menu.svg">
          </button>
        </div>
      </div>
      
      <div class="sistemadi-header__mobile-overlay sistemadi-hide"></div>
      <div class="sistemadi-header__mobile-menu sistemadi-hide">
        <div class="sistemadi-header__mobile-toggle-container">
          <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/12/Aprobandome-Logo.webp" class="sistemadi-header__mobile-menu-logo">

        

          <!-- <a href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjEwOTEiLCJ0b2dnbGUiOmZhbHNlfQ%3D%3D">-->
            <button class="sistemadi-header__mobile-menu-close" style="background-color: transparent;">
              <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/close.svg">
            </button>
          </a>
        </div>

        <h2 class="menu-titulo">Menú</h2>
      
        <!-- Condición 1: Mostrar el primer div si no hay usuario logueado -->
        <div class="sistemadi-header__mobile-actions-container <?php echo (!is_user_logged_in() ? 'sistemadi-show-flex' : 'sistemadi-hide'); ?> ">
          <a class="btn btn-secondary" href="/login">
            <span>Mi cuenta</span>
            <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/my-account.svg">
          </a>
        </div>

        



        <!-- Condición 2: Mostrar este div si el usuario está logueado pero no está en la página 'mi-cuenta' -->
        <!-- <div class="sistemadi-header__mobile-actions-container <?php echo (is_user_logged_in() && !is_page('mi-cuenta') ? 'sistemadi-show' : 'sistemadi-hide'); ?>">
          <a class="btn btn-secondary" href="/mi-cuenta/panel-usuario">
            <span>Ir a mi cuenta</span>
            <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2024/08/User.png">
          </a>
        </div> -->

        <!-- Condición 3: Mostrar este div si el usuario está logueado y está en la página 'mi-cuenta' -->
        <!-- <div class="sistemadi-header__mobile-actions-container <?php echo (is_user_logged_in() && is_page('mi-cuenta') ? 'sistemadi-show' : 'sistemadi-hide'); ?>">-->
         <div class="sistemadi-header__mobile-actions-container <?php echo (is_user_logged_in() ? 'sistemadi-show' : 'sistemadi-hide'); ?>"> 
          <a id="sistemadi-header__mobile-logout-btn" class="btn btn-secondary" href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE1NzQiLCJ0b2dnbGUiOmZhbHNlfQ%3D%3D">
            <div class="sistemadi-panel__logout">
              <span class="sistemadi-panel__user-name"><?php echo esc_html( $sistemadi_mobile_name ); ?></span>
              <span class="sistemadi-panel__user-email"><?php echo $user->user_email; ?></span>
            </div>
            <!--<img width="20px" src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/logout.svg">-->
          </a>
        </div>

        <?php if ( is_user_logged_in() ) : ?>
        <!-- MI CUENTA -->
        <div class="sistemadi-header__mobile-actions-container sistemadi-show">
          <a class="btn btn-secondary" href="/mi-cuenta/panel-usuario/panel-usuario">
            <span>Mi cuenta</span>
            <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/my-account.svg">
          </a>
        </div>

        <?php if ( function_exists( 'mi_sso_user_has_access' ) && mi_sso_user_has_access( 'wmslatam' ) ) : ?>
        <!-- PROGRAMAS DE LIDERAZGO (solo si tiene acceso SSO a WMS Latam) -->
        <div class="sistemadi-header__mobile-actions-container sistemadi-show">
          <a class="btn btn-secondary" href="/sso-to-wmslatam-default">
            <span>Programas de Liderazgo</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 28 32">
              <path d="M26 6 Q26 2 20 2 L8 2 Q2 2 2 8 L2 18 Q2 24 8 24 L18 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>
              <polyline points="13,18 18,24 13,30" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></polyline>
            </svg>
          </a>
        </div>
        <?php endif; ?>

        <?php if ( function_exists( 'mi_sso_user_has_access' ) && mi_sso_user_has_access( 'octagono' ) ) : ?>
        <!-- PROGRAMAS DE SENTIDO Y PROPÓSITO (solo si tiene acceso SSO a Octágono) -->
        <div class="sistemadi-header__mobile-actions-container sistemadi-show">
          <a class="btn btn-secondary" href="/sso-to-octagono">
            <span>Programas de Sentido y Propósito</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 28 32">
              <path d="M26 6 Q26 2 20 2 L8 2 Q2 2 2 8 L2 18 Q2 24 8 24 L18 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>
              <polyline points="13,18 18,24 13,30" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></polyline>
            </svg>
          </a>
        </div>
        <?php endif; ?>

        <!-- SALIR / CERRAR SESIÓN -->
         <div class="sistemadi-header__mobile-actions-container sistemadi-show">
            <a class="btn btn-danger"
              href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjEwOTEiLCJ0b2dnbGUiOmZhbHNlfQ%3D%3D">

              <span>Salir</span>
              <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/logout.svg">
            </a>
          </div>
        <?php endif; ?>
       

        <hr class="sistemadi-header__mobile-menu-separator">  

        <nav class="sistemadi-header__mobile-navigation-container">
          <ul class="sistemadi-header__mobile-navigation">
            <?php
              foreach ( $menu as $m ) {
                // Ocultar "areas admin" del menú móvil.
                if ( false !== strpos( $m['item']->url, 'areas-admin' ) ) {
                  continue;
                }
                ?>
                <li class="sistemadi-header__navigation-item">
                  <a href="<?php echo $m['item']->url; ?>"><?php echo $m['item']->title; ?></a>

                  <?php
                  // Si tiene hijos, los imprimimos
                  if (!empty($m['children'])) {
                    ?>
                    <img src="<?php echo get_site_url(); ?>/wp-content/uploads/2025/03/chevron-down.svg" class="sistemadi-header__navigation-item-arrow">
                    <ul class="sistemadi-header__submenu">
                      <?php
                      foreach ($m['children'] as $child_item) {
                        ?>
                        <li class="sistemadi-header__submenu-item">
                          <a href="<?php echo $child_item->url; ?>">
                            <?php echo $child_item->title; ?>
                          </a>
                        </li>
                        <?php
                      }
                      ?>
                    </ul>
                    <?php
                  }
                  ?>
                </li>
                <?php
              }
            ?>
          </ul>
        </nav>
      </div>
      <!-- Termina el contenido del menú móvil -->
    </header>


      <!-- final movile  -->



  <?php

	astra_header_after();

	astra_content_before();
	?>
	<div id="content" class="site-content">
		<div class="ast-container">
		<?php astra_content_top(); ?>
