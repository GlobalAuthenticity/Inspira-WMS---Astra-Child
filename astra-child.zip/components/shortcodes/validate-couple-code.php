<?php

function validate_couple_code_function($atts) {
    global $wpdb;

    // Consultar el id del usuario actual.
    $couple_two_id = get_current_user_id();
    $couple_one_id = "";

    if (isset($_GET['couple-one-id'])) {
      $couple_one_id = $_GET['couple-one-id'];
    }
    
    // Se muestra el formulario
    if(!is_admin()) {
      wp_enqueue_style( 'validate-couple-code-styles', get_stylesheet_directory_uri() . '/components/shortcodes/validate-couple-code.css' );

      ob_start();
      ?>
        <form id="auth-form" class="validate-couple-form">

          <div>
            <p class="form-row form-row-wide" id="couple_code_field">
              <label for="couple_code">
                Código de verificación: <span class="required">*</span>
              </label>
              <br>
              <span class="woocommerce-input-wrapper">
                <input 
                  type="number" 
                  class="input-text" 
                  name="couple_code" 
                  id="couple_code" 
                  placeholder="00000" 
                  value="<? echo $couple_one_id; ?>"
                  aria-required="true"  
                  required>
              </span>
            </p>
          </div>

          <input type="submit" value="Validar código">

          <span class="validate-couple-form-error"></span>
        </form>

        <div class="couple-successful-validated">
          <h2>¡Código Verificado!</h2>

          <div>
            <span style="font-size: 16px;"><b>Hemos encontrado que tu pareja es:</b></span>

            <div class="couple-info">
            </div>

            <span>Confirma si esta es la persona correcta y avanza con tu parte del test para seguir creciendo juntos.</span>
          </div>

          <div class="validate-couple-buttons">
            <button class="try-another-code">Intentar otro código</button>
            <button class="continue-couple-verification" data-couple-two="<?php echo $couple_two_id; ?>" data-couple-one="<?php echo $couple_one_id; ?>">Sí, continuar</button>
          </div>
        </div>
      <?php
      return ob_get_clean();
    }
}
add_shortcode('validate_couple_code', 'validate_couple_code_function');


