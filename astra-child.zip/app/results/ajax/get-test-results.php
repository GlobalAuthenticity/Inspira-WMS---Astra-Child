<?php

/**
 * ======================================================
 * PROCESAR RESPUESTAS DEL TEST
 * ======================================================
 */
function proccess_test_answers(array $test_answers)
{
    // --------------------------------------------------
    // REGLAS DE CLASIFICACIÓN (ALTO / MEDIO / BAJO)
    // --------------------------------------------------
    $rules = [
        'insuficiencia' => ['minimum' => 2,  'medium' => 6,  'maximum' => 11],
        'rechazo'       => ['minimum' => 7,  'medium' => 16, 'maximum' => 23],
        'desaprobacion' => ['minimum' => 14, 'medium' => 25, 'maximum' => 32],
        'obsesividad'   => ['minimum' => 1,  'medium' => 3,  'maximum' => 7],
        'dependencia'   => ['minimum' => 1,  'medium' => 3,  'maximum' => 5],
        'evitacion'     => ['minimum' => 5,  'medium' => 10, 'maximum' => 13],
    ];

    // --------------------------------------------------
    // TOTAL DE PREGUNTAS
    // --------------------------------------------------
    $total = count($test_answers);
    // --------------------------------------------------
    // DEFINICIÓN DE GRUPOS DE PREGUNTAS
    // --------------------------------------------------

    // -------- AMENAZAS --------
    $desprobacion_questions = [1, 2, 3, 4, 5, 6, 7, 8];
    $desprobacion_value     = [];
    $desprobacion_sum       = 0;

    // -------- DOLORES --------
    $insuficiencia_questions    = [9, 10, 11];
    $insuficiencia_value        = [];
    $insuficiencia_sum          = 0;

    $rechazo_questions  = [12, 13, 14, 15, 16];
    $rechazo_value      = [];
    $rechazo_sum        = 0;

    // -------- ESTRATEGIAS --------
    $obsesividad_questions  = [17, 18];
    $obsesividad_value      = [];
    $obsesividad_sum        = 0;

    $dependencia_questions  = [19, 20];
    $dependencia_value      = [];
    $dependencia_sum        = 0;

    $evitacion_questions    = [21, 22, 23];
    $evitacion_value        = [];
    $evitacion_sum          = 0;


    //aqui paso las preguntas 13 16 17 18 para ocultar los fragmentos de textos internos cuando se responde 0 o 1 

    $visibility_questions = [
        13 => 0,
        16 => 0,
        17 => 0,
        18 => 0,
    ];

    // --------------------------------------------------
    // PROCESAMIENTO DE RESPUESTAS
    // --------------------------------------------------
    foreach ($test_answers as &$test_answer) {

        // Normalizar índice de la pregunta
        $question_index = intval($test_answer['question']) - 89;
        $answer_value   = intval($test_answer['answer']);

        $test_answer['question'] = $question_index;

        // VISIBILIDAD PARA MUSTACHE (13,16,17,18)
        if (array_key_exists($question_index, $visibility_questions)) {
            // Mostrar solo si la respuesta es > 1
            $visibility_questions[$question_index] = ($answer_value > 1) ? 1 : 0;
        }


        // -------- AMENAZAS --------
        if (in_array($question_index, $desprobacion_questions, true)) {
            $desprobacion_sum += $answer_value;
            $desprobacion_value[] = $answer_value;
        }

        // -------- DOLORES --------
        if (in_array($question_index, $insuficiencia_questions, true)) {
            $insuficiencia_sum      += $answer_value;
            $insuficiencia_value[]  = $answer_value;
        }

        if (in_array($question_index, $rechazo_questions, true)) {
            $rechazo_sum            += $answer_value;
            $rechazo_value[]        = $answer_value;
        }

        // -------- ESTRATEGIAS --------
        if (in_array($question_index, $obsesividad_questions, true)) {
            $obsesividad_sum        += $answer_value;
            $obsesividad_value[]    = $answer_value;
        }

        if (in_array($question_index, $dependencia_questions, true)) {
            $dependencia_sum        += $answer_value;
            $dependencia_value[]    = $answer_value;
        }

        if (in_array($question_index, $evitacion_questions, true)) {
            $evitacion_sum          += $answer_value;
            $evitacion_value[]      = $answer_value;
        }
    }

    unset($test_answer);

    // --------------------------------------------------
    // TOTALES AGRUPADOS
    // --------------------------------------------------
    $amenazas_total    = $desprobacion_sum;
    $dolores_total     = $insuficiencia_sum + $rechazo_sum;
    $estrategias_total = $obsesividad_sum + $dependencia_sum + $evitacion_sum;

    // --------------------------------------------------
    // VULNERABILIDAD DOMINANTE
    // --------------------------------------------------
    $vulnerabilidades = [
        'insuficiencia' => $insuficiencia_sum,
        'rechazo'       => $rechazo_sum,
    ];

    $vulnerabilidad_alta = array_search(
        max($vulnerabilidades),
        $vulnerabilidades,
        true
    );

    // --------------------------------------------------
    // RESPUESTA FINAL
    // --------------------------------------------------
    $insuficiencia_type = get_level($insuficiencia_sum, $rules['insuficiencia']);
    $rechazo_type       = get_level($rechazo_sum, $rules['rechazo']);
    $desprobacion_type  = get_level($desprobacion_sum, $rules['desaprobacion']);
    $obsesividad_type   = get_level($obsesividad_sum, $rules['obsesividad']);
    $dependencia_type   = get_level($dependencia_sum, $rules['dependencia']);
    $evitacion_type     = get_level($evitacion_sum, $rules['evitacion']); 
    
    // --------------------------------------------------
    // BANDERAS PARA MUSTACHE Dolores  (ALTO / MEDIO / BAJO)
    // --------------------------------------------------
    $dolores_has_alto = (
    $insuficiencia_type === 'ALTO' ||
    $rechazo_type === 'ALTO'
    );

    $dolores_has_medio = (
        $insuficiencia_type === 'MEDIO' ||
        $rechazo_type === 'MEDIO'
    );

    $dolores_has_bajo = (
        $insuficiencia_type === 'BAJO' ||
        $rechazo_type === 'BAJO'
    );

    $amenazas_has_alto  = ($desprobacion_type === 'ALTO');
    $amenazas_has_medio = ($desprobacion_type === 'MEDIO');
    $amenazas_has_bajo  = ($desprobacion_type === 'BAJO');

    $estrategias_has_alto = (
    $obsesividad_type === 'ALTO' ||
    $dependencia_type === 'ALTO' ||
    $evitacion_type === 'ALTO'
    );

    $estrategias_has_medio = (
        $obsesividad_type === 'MEDIO' ||
        $dependencia_type === 'MEDIO' ||
        $evitacion_type === 'MEDIO'
    );

    $estrategias_has_bajo = (
        $obsesividad_type === 'BAJO' ||
        $dependencia_type === 'BAJO' ||
        $evitacion_type === 'BAJO'
    );




    
   

    return [

        'question_visibility' => [
        'show_q13' => $visibility_questions[13],
        'show_q16' => $visibility_questions[16],
        'show_q17' => $visibility_questions[17],
        'show_q18' => $visibility_questions[18],
         ],

        'total' => $total,

        'result_vulnerabilidad_alta' => $vulnerabilidad_alta,

        'results_general' => [
            'amenazas_total'    => $amenazas_total,
            'dolores_total'     => $dolores_total,
            'estrategias_total' => $estrategias_total,
        ],

        'results_promedio' => [
            'amenazas_prom'    => $amenazas_total / count($desprobacion_questions),
            'dolores_prom'     => $dolores_total / (count($insuficiencia_questions) + count($rechazo_questions)),
            'estrategias_prom' => $estrategias_total / (count($obsesividad_questions) + count($dependencia_questions) + count($evitacion_questions)),
        ],

        'results_type' => [
            'insuficiencia' => $insuficiencia_sum,
            'rechazo'       => $rechazo_sum,
            'desaprobacion'  => $desprobacion_sum,
            'obsesividad'   => $obsesividad_sum,
            'dependencia'   => $dependencia_sum,
            'evitacion'     => $evitacion_sum,
        ],
        
        'result_type_value' => [

            // DOLORES
            'dolores_has_alto'  => $dolores_has_alto,
            'dolores_has_medio' => $dolores_has_medio,
            'dolores_has_bajo'  => $dolores_has_bajo,

            // AMENAZAS
            'amenazas_has_alto'  => $amenazas_has_alto,
            'amenazas_has_medio' => $amenazas_has_medio,
            'amenazas_has_bajo'  => $amenazas_has_bajo,

            // ESTRATEGIAS
            'estrategias_has_alto'  => $estrategias_has_alto,
            'estrategias_has_medio' => $estrategias_has_medio,
            'estrategias_has_bajo'  => $estrategias_has_bajo,


            

            'insuficiencia' => [
                'type'      => $insuficiencia_type,
                'is_alto'   => ($insuficiencia_type === 'ALTO'),
                'is_medio'  => ($insuficiencia_type === 'MEDIO'),
                'is_bajo'   => ($insuficiencia_type === 'BAJO'),
                'labels' => ['A','B','C','',''],
                'value'  => $insuficiencia_value,
            ],
            
            'rechazo' => [
                'type'   => $rechazo_type,
                'is_alto'   => ($rechazo_type === 'ALTO'),
                'is_medio'  => ($rechazo_type === 'MEDIO'),
                'is_bajo'   => ($rechazo_type === 'BAJO'),
                'labels' => ['A','B','C','D','E'], 
                'value'  => $rechazo_value,
            ],
            
            'desaprobacion' => [
                'type'   => $desprobacion_type,
                'is_alto'   => ($desprobacion_type === 'ALTO'),
                'is_medio'  => ($desprobacion_type === 'MEDIO'),
                'is_bajo'   => ($desprobacion_type === 'BAJO'),
                'labels' => ['A','B','C','D','E','F','G','H'],
                'value'  => $desprobacion_value,
            ],
            
            'obsesividad' => [
                'type'   => $obsesividad_type,
                'is_alto'   => ($obsesividad_type === 'ALTO'),
                'is_medio'  => ($obsesividad_type === 'MEDIO'),
                'is_bajo'   => ($obsesividad_type === 'BAJO'),
                'labels' => ['A','B','','',''],
                'value'  => $obsesividad_value,
            ],
            
            'dependencia' => [
                'type'   => $dependencia_type,
                'is_alto'   => ($dependencia_type === 'ALTO'),
                'is_medio'  => ($dependencia_type === 'MEDIO'),
                'is_bajo'   => ($dependencia_type === 'BAJO'),
                'labels' => ['A','B','','',''],
                'value'  => $dependencia_value,
            ],
            
            'evitacion' => [
                'type'   => $evitacion_type,
                'is_alto'   => ($evitacion_type === 'ALTO'),
                'is_medio'  => ($evitacion_type === 'MEDIO'),
                'is_bajo'   => ($evitacion_type === 'BAJO'),
                'labels' => ['A','B','C','',''],
                'value'  => $evitacion_value,
            ],
        ],


        'results' => $test_answers,
    ];
}


/**
 * ------------------------------------------------------
 * OBTENER NIVEL (ALTO / MEDIO / BAJO)
 * ------------------------------------------------------
 */
function get_level($score, array $rule)
{
    if ($score <= $rule['minimum']) {
        return 'BAJO';
    }

    if ($score <= $rule['medium']) {
        return 'MEDIO';
    }

    return 'ALTO';
}



/**
 * ======================================================
 * OBTENER RESULTADOS DEL TEST (AJAX)
 * ======================================================
 */
if (!function_exists('get_test_results')) {

    function get_test_results()
    {
        if (!defined('DOING_AJAX') || !DOING_AJAX) {
            return;
        }

        // --------------------------------------------------
        // USUARIO
        // --------------------------------------------------
        $post_user_id = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
        $user_id      = $post_user_id > 0 ? $post_user_id : get_current_user_id();

        if (!$user_id) {
            send_json_response(false, 'error', 'El usuario no está logueado.');
        }

        // --------------------------------------------------
        // VALIDAR COMPRA DEL TEST
        // --------------------------------------------------
        $test_type_personal = AppConstants::TEST_TYPE_PERSONAL;

        $exist_test_personal = UserQueries::user_bought_test(
            $user_id,
            $test_type_personal
        );

        // --------------------------------------------------
        // DATOS DEL USUARIO
        // --------------------------------------------------
        $first_name = get_user_meta($user_id, 'first_name', true);
        $last_name  = get_user_meta($user_id, 'last_name', true);
        $name       = trim($first_name . ' ' . $last_name);

        // --------------------------------------------------
        // RESPUESTAS DEL TEST
        // --------------------------------------------------
        $question_test_ids  = get_user_meta($user_id, 'question_test_ids', true);
        $test_answers       = json_decode(stripslashes($question_test_ids), true);

        $test_results       = proccess_test_answers($test_answers);

        // --------------------------------------------------
        // RESPUESTA AJAX
        // --------------------------------------------------
        $data = [
            'success'                    => true,
            'name'                       => $name,
            'result_complete'            => $exist_test_personal[0]->pago ?? 0,
            'total'                      => $test_results['total'],
            'result_vulnerabilidad_alta' => $test_results['result_vulnerabilidad_alta'],
            'results_general'            => $test_results['results_general'],
            'results_promedio'           => $test_results['results_promedio'],
            'results_type'               => $test_results['results_type'],
            'result_type_value'          => $test_results['result_type_value'],
            'results'                    => $test_results['results'],
            'question_visibility'        => $test_results['question_visibility'],

        ];

        send_json_response(true, 'success', 'Resultados obtenidos correctamente', $data);
    }
}


/**
 * ======================================================
 * HOOKS AJAX
 * ======================================================
 */
add_action('wp_ajax_get_test_results', 'get_test_results');
add_action('wp_ajax_nopriv_get_test_results', 'get_test_results');
