<?php

function addModalWaiting() {
  wp_enqueue_style( 'modal-waiting-styles', get_stylesheet_directory_uri() . '/components/modals/modal-waiting.css' );
  ?>

  <!-- Código HTML del modal -->
  <div class="sistemadi-modal-waiting">
      <div class="modal" id="customModalWaiting">
        <div class="modal-content">
          <div class="sistemadi-modal-waiting-header">
              <img class="imgg" src="<?php echo get_site_url(); ?>/wp-content/uploads/2026/01/output-onlinegiftools.gif">              
          </div>
          <div class="sistemadi-modal-waiting-body">
              <h3>¡Espera un momento!</h3>
              <p class="modal-waiting-text"></p>
          </div>
        </div>
      </div>
  </div>

  <?php
}

add_action('wp_footer', 'addModalWaiting');
