<?php

/**
 * Función para enviar correos de pareja
 * 
 * En la petición POST deben incluirse los siguientes campos
 * 
 * coupleOneID -> ID de usuario de la pareja que compró el test
 * coupleTwoEmail -> Dirección de correo electrónico de la segunda pareja
 * 
 * @return void.
 */
function ajax_send_couple_email() {
  // Recuperar parámetros POST
  $couple_one_id = $_POST['coupleOneId'];
  $couple_two_email = $_POST['coupleTwoEmail'];

  // Enviar el correo a la segunda pareja
  $emailSent = send_couple_email($couple_one_id, $couple_two_email);

  if ($emailSent) {
    send_json_response(true, 'success', 'El correo se reenvió correctamente a tu pareja.');
  } else {
    send_json_response(
      false, 
      'error', 
      'Hubo un error al enviar el correo. Por favor, intente más tarde.'
    );
  }
}

add_action('wp_ajax_nopriv_ajax_send_couple_email', 'ajax_send_couple_email');
add_action('wp_ajax_ajax_send_couple_email', 'ajax_send_couple_email');
