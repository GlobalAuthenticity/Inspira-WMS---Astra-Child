jQuery(document).ready(function($) {
    if ($("body").hasClass(code_scripts.page_result_padres) ||
        $("body").hasClass(code_scripts.page_result_parejas) ||
        $("body").hasClass(code_scripts.page_result_individual)) 
    {    
        let $toc = $(".sistemadi-content-table:first"); // Tabla de contenido
        let $hr = $("#report-last-divider"); // Elemento antes del footer
    
        let isFixed = true; // Indica si la tabla debe seguir fija
        let lastScrollTop = $(window).scrollTop(); // Guarda la última posición de scroll
    
        // 📌 Observador de intersección
        let observer = new IntersectionObserver(
            (entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        // 📌 Fijamos la tabla en su posición actual
                        $toc.css({
                            position: "absolute",
                            top: $toc.offset().top + "px"
                        });
                        
                        isFixed = false;
                    }
                });
            },
            { root: null, threshold: 0 }
        );
    
        observer.observe($hr[0]);
    
        // 🔄 Detectar el scroll
        $(window).on("scroll", function () {
            let currentScroll = $(this).scrollTop();
    
            // Si el usuario hace scroll hacia arriba y pasó el hr, vuelve a ser fixed
            if (currentScroll < lastScrollTop && $(window).scrollTop() + $(window).height() < $hr.offset().top) {
                if (!isFixed) {
                    $toc.css({
                        position: "fixed",
                        top: "94px" // Ajusta según el diseño
                    });
                    
                    isFixed = true;
                }
            }
    
            lastScrollTop = currentScroll; // Actualiza la última posición de scroll
        });
    }
});