jQuery(document).ready(function($) {

    const pageTest = 'page-id-1049';

    if ($('body').hasClass(pageTest)) {

        const data = {};
        data['action'] = 'get_item_view_menu';

        $.ajax({
            url: code_scripts.ajaxurl,
            type: 'post',
            dataType: "json",
            data,
            success: function (response) {
                const items = response['data']['view_options'];

                items.forEach(id => {
                    const el = document.getElementById(id);
                    if (!el) return;

                    el.style.pointerEvents = 'none';
                    el.style.opacity = '0.5';
                });
                
            },
            error: function (error) {
                console.log('Error en la petición AJAX: ', error);
            },
            complete: function () {

            }
        });

    }

});
