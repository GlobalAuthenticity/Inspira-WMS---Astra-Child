<?php

add_action('rest_api_init', function () {
    register_rest_route('aprobandome/v1', '/create-user', [
        'methods'               => 'POST',
        'callback'              => 'aprobandome_api_create_user',
        'permission_callback'   => 'aprobandome_api_check_token',
    ]);
});

/**
 * Validación del token Bearer
 */
function aprobandome_api_check_token( WP_REST_Request $request ) {

    $auth_header = $request->get_header('authorization');

    if ( ! $auth_header || ! str_starts_with($auth_header, 'Bearer ') ) {
        return new WP_Error(
            'unauthorized',
            'Missing Authorization header',
            ['status' => 401]
        );
    }

    $token_received = trim(str_replace('Bearer', '', $auth_header));
    $valid_token    = get_option('aprobandome_create_admin_user');

    if ( ! hash_equals($valid_token, $token_received) ) {
        return new WP_Error(
            'unauthorized',
            'Invalid API token',
            ['status' => 403]
        );
    }

    return true;
}

/**
 * Crear usuario vía API
 */
function aprobandome_api_create_user( WP_REST_Request $request ) {

    $data = $request->get_json_params();

    if ( empty($data['user']) || empty($data['meta']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Invalid payload'
        ], 400);
    }

    $user_data = $data['user'];
    $meta_data = $data['meta'];
    $roles     = $data['roles'] ?? [];
    $migration = $data['migration'] ?? [];

    // ----------------------------------
    // Validaciones
    // ----------------------------------
    if ( empty($user_data['user_email']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Missing user_email'
        ], 400);
    }

    if ( email_exists($user_data['user_email']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'User already exists'
        ], 409);
    }

    // ----------------------------------
    // 1. Crear usuario
    // ----------------------------------
    $user_id = wp_insert_user([
        'user_login' => sanitize_email($user_data['user_email']),
        'user_pass'  => $user_data['user_pass'] ?? wp_generate_password(18, true),
        'user_email' => sanitize_email($user_data['user_email']),
        'nickname'   => sanitize_text_field($user_data['display_name'] ?? ''),
        'first_name' => sanitize_text_field($user_data['display_name'] ?? '')
    ]);

    if ( is_wp_error($user_id) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $user_id->get_error_message()
        ], 500);
    }

    // ----------------------------------
    // 2. Metadatos
    // ----------------------------------
    $meta_data['nombre_encargado'] = $meta_data['first_name'] ?? '';
    $meta_data['phone_number']    = $meta_data['contacto'] ?? '';
    $meta_data['occupation']      = $meta_data['ocupacion'] ?? '';
    $meta_data['grupo']           = 'true';
    $meta_data['membresia_activa']= 'true';

    foreach ( $meta_data as $key => $value ) {
        update_user_meta($user_id, $key, $value);
    }

    update_user_meta($user_id, 'migrated', 1);
    update_user_meta($user_id, 'migrated_source', $migration['source'] ?? '');
    update_user_meta($user_id, 'migrated_external_id', $migration['external_id'] ?? '');

    // ----------------------------------
    // 3. Rol
    // ----------------------------------
    $wp_user = new WP_User($user_id);
    $wp_user->set_role('empresa_admin');

    // ----------------------------------
    // 4. Token de autologin (15 min)
    // ----------------------------------
    $autologin_token = wp_generate_password(40, false, false);

    update_user_meta($user_id, 'mi_autologin_token', $autologin_token);
    update_user_meta($user_id, 'mi_autologin_expires', time() + 900);

    $autologin_url = add_query_arg([
        'mi_autologin' => 1,
        'uid'          => $user_id,
        'token'        => $autologin_token,
    ], home_url('/'));

    // ----------------------------------
    // 5. Respuesta
    // ----------------------------------
    return new WP_REST_Response([
        'success'       => true,
        'user_id'       => $user_id,
        'roles'         => $wp_user->roles,
        'autologin_url' => $autologin_url
    ], 201);
}
