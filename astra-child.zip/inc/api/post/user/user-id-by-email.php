<?php

add_action( 'rest_api_init', function () {

    register_rest_route( 'aprobandome/v1', '/user-id-by-email', [
        'methods'  => 'POST',
        'callback' => 'aprobandome_user_id_by_email_api',
        'permission_callback' => 'aprobandome_api_user_by_email_check_token', // ⚠️ Cambiar en producción
    ]);

});

/**
 * Validación del token Bearer
 */
function aprobandome_api_user_by_email_check_token( WP_REST_Request $request ) {

    $auth_header = $request->get_header('authorization');

    if ( ! $auth_header || ! str_starts_with($auth_header, 'Bearer ') ) {
        return new WP_Error(
            'unauthorized',
            'Missing Authorization header',
            ['status' => 401]
        );
    }

    $token_received = trim(str_replace('Bearer', '', $auth_header));
    $valid_token    = get_option('aprobandome_user_id_by_email');

    if ( ! hash_equals($valid_token, $token_received) ) {
        return new WP_Error(
            'unauthorized',
            'Invalid API token',
            ['status' => 403]
        );
    }

    return true;
}

/**
 * Callback del endpoint
 */
function aprobandome_user_id_by_email_api( WP_REST_Request $request ) {

    // Obtener y sanitizar email
    $email = sanitize_email( $request->get_param( 'email' ) );

    // Validar email
    if ( empty( $email ) || ! is_email( $email ) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Email inválido'
        ], 400);
    }

    // Buscar usuario por email (WordPress nativo)
    $user = get_user_by( 'email', $email );

    if ( ! $user ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Usuario no encontrado'
        ], 404);
    }

    // Éxito
    return new WP_REST_Response([
        'success' => true,
        'user_id' => (int) $user->ID,
        'email'   => $user->user_email
    ], 200);
}