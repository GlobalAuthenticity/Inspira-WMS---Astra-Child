/**
 * Autorrelleno aleatorio para el test de WatuPRO (form#quiz-3)
 *
 * Atajo de teclado: Alt + Shift + R
 * (En macOS la tecla Alt es "Option", pero el navegador reporta altKey=true
 * igual que en Windows/Linux, así que el mismo atajo funciona sin cambios
 * en los 3 sistemas operativos).
 *
 * Diferencias de ESTE formulario (quiz_id=3) respecto a los anteriores:
 *   - Tiene 3 páginas (catDiv1, catDiv2, catDiv3 — "Page X of 3"), igual
 *     de ocultas con display:none salvo la activa, así que un solo pase
 *     del script sigue cubriendo las 23 preguntas sin necesidad de
 *     navegar página por página.
 *   - Antes de la barra de progreso hay un indicador visual de pasos
 *     (.my-watupro-steps > .step, con .is-active en el paso actual). El
 *     script no lo toca: solo se actualiza cuando WatuPRO cambia de
 *     página al pulsar "Continuar"/"Anterior" de categoría.
 *   - El botón para avanzar de página se llama "Continuar"
 *     (#watuproNextCatButton), no "Siguiente" como en quiz-4. El botón
 *     final de envío es "Ver resultados" (#action-button), oculto hasta
 *     la última página.
 *   - Escala de 6 opciones (0 a 5) por pregunta, igual que en quiz-4.
 *   - Hay un bloque oculto final (aquí id="question-24") que es solo el
 *     "Loading..." de WatuPRO, no una pregunta real: no tiene
 *     .question-choices, así que el script lo ignora automáticamente.
 *
 * Cómo usarlo:
 *   1) Pega este script en la consola del navegador estando en la página
 *      del test, o guárdalo como snippet en DevTools > Sources > Snippets
 *      para no tener que pegarlo cada vez.
 *   2) Pulsa Alt+Shift+R. Puedes volver a pulsarlo para re-randomizar
 *      antes de enviar.
 *
 * Si quieres tenerlo siempre disponible mientras pruebas, te recomiendo
 * encenderlo solo en staging o detrás de algo como `?qa=1`, para que un
 * usuario real del test no pueda usarlo en producción.
 */
(function () {
  'use strict';

  if (window.__watuproAutoFillLoaded) {
    // console.log('[auto-test] Ya estaba cargado, solo pulsa Alt+Shift+R.');
    return;
  }
  window.__watuproAutoFillLoaded = true;

  // ---- Atajo configurable: cámbialo aquí si choca con algo ----
  const NEEDS_ALT = true;
  const NEEDS_SHIFT = true;
  const TRIGGER_LETTER = 'r';

  // ---- Selector del formulario objetivo ----
  // Este test es form#quiz-3. Si en algún momento cambia el id del quiz
  // (por ejemplo lo duplican como quiz-5, quiz-6...) el fallback genérico
  // de abajo sigue funcionando igual.
  const FORM_SELECTOR = '#quiz-3, .quiz-form';

  function matchesShortcut(e) {
    return (
      e.altKey === NEEDS_ALT &&
      e.shiftKey === NEEDS_SHIFT &&
      !e.ctrlKey &&
      !e.metaKey &&
      e.key.toLowerCase() === TRIGGER_LETTER
    );
  }

  function getAnswerBlocks() {
    const form = document.querySelector(FORM_SELECTOR);
    const scope = form || document;

    let blocks = scope.querySelectorAll('.question-choices');
    if (!blocks.length) {
      // Fallback por si en algún momento cambia la estructura del form
      blocks = document.querySelectorAll('.question-choices');
    }
    return blocks;
  }

  function fillAllQuestionsRandomly() {
    const blocks = getAnswerBlocks();

    if (!blocks.length) {
      console.warn('[auto-test] No encontré preguntas en esta página.');
      return;
    }

    let answered = 0;

    blocks.forEach(function (block) {
      // En quiz-3 solo hay radios (escala 0-5), pero dejamos checkbox
      // también por robustez ante futuros tests.
      const options = block.querySelectorAll('input[type="radio"], input[type="checkbox"]');
      if (!options.length) return;

      const choice = options[Math.floor(Math.random() * options.length)];

      // .click() marca la opción Y dispara 'click'/'change' de forma nativa,
      // igual que un clic real, para que la barra de progreso
      // (#watupro-progress-bar-3) y el paso activo (.my-watupro-steps)
      // se actualicen con normalidad al avanzar de página.
      choice.click();
      choice.dispatchEvent(new Event('change', { bubbles: true }));

      answered++;
    });

    console.log('[auto-test] ' + answered + ' preguntas marcadas al azar de ' + blocks.length + ' encontradas.');
  }

  document.addEventListener('keydown', function (e) {
    if (matchesShortcut(e)) {
      e.preventDefault();
      fillAllQuestionsRandomly();
    }
  });
})();