jQuery(document).ready(function($) {
    const currentPaht = window.location.pathname;
    isPageEstudiante = currentPaht.includes('cursos');

    /**
     * @description
     * Añadir curso al carrito.
     */
    $(document).on('click', '.ids-js-add-course-to-cart', function (event) {
        const productId = $(this).attr('data-product');
        const categoryId = $(this).attr('data-category');

        let countEstrategias = 0;
        let countEstrategiasAnadidos = 0;
        $('.ids__cursos__item[data-category=estrategias]:visible').each(function( index ) {
            countEstrategias++;
            if( $(this).find('.ids__cursos__item__button__comprar__red').length || $(this).find('.ids__cursos__item__button__ver').length ){
                countEstrategiasAnadidos++;
            }
        });

        console.log("countEstrategias: ", countEstrategias);
        console.log("countEstrategiasAnadidos: ", countEstrategiasAnadidos);
        if(categoryId == 'amenazas' && countEstrategias && countEstrategias != countEstrategiasAnadidos){
            Swal.fire({
                html: 'Debes terminar todos los cursos de <b>estrategias</b> para empezar con los cursos de <b>amenazas</b>',
                confirmButtonText: 'Aceptar',
                confirmButtonColor: '#F25A60',
            });
            return;
        }

        let countAmenazas = 0;
        let countAmenazasAnadidos = 0;
        $('.ids__cursos__item[data-category=amenazas]:visible').each(function( index ) {
            countAmenazas++;
            if( $(this).find('.ids__cursos__item__button__comprar__red').length || $(this).find('.ids__cursos__item__button__ver').length ){
                countAmenazasAnadidos++;
            }
        });

        console.log("countAmenazas: ", countAmenazas);
        console.log("countAmenazasAnadidos: ", countAmenazasAnadidos);
        if(categoryId == 'dolores' && ((countEstrategias && countEstrategias != countEstrategiasAnadidos) || (countAmenazas && countAmenazas != countAmenazasAnadidos))){
            Swal.fire({
                html: 'Debes terminar todos los cursos de <b>estrategias</b> y <b>amenazas</b> para empezar con los cursos de los <b>dolores</b>',
                confirmButtonText: 'Aceptar',
                confirmButtonColor: '#F25A60',
            });
            return;
        }

        // $(this).append(`<img src="${code_scripts.code_url}${urlImageLoader}" class="loading loading-submit-test" style="width: 20px; height: 20px !important;"/>`);
        // $('.loading-submit-test').show();

        $.ajax({
            url : code_scripts.ajaxurl,
            type: 'post',
            data: {
                action : 'ids_wc_add_product_to_cart',
                product_id : productId,
            },
            beforeSend: function(){
                // code...
            },
            success: function(result){
                // Obtenemos Respuesta
                let respond = JSON.parse(result.substring(0, result.length - 1));
                // Mostramos una respuesta
                if ( respond.status == 'success' ) {
                    console.log( respond.message );
                } else {
                    console.log( respond.message );
                }

                $(`.ids-js-content-button-${productId}`).html(`
                    <a href="${code_scripts.get_url_cart}" class="ids__cursos__item__button ids__cursos__item__button__comprar__red">
                        Comprar
                    </a>
                `);
            }
        });
        // ids_wc_add_product_to_cart
    });

    /**
     * @description
     * Función para determinar los cursos comprados, cambiar precios para las categorías, etc...
     */
    function cursosCompradosFunction() {
        if (!isPageEstudiante) return;

        const cursosComprados = $('.ids__cursos__item:not(.ids-introduccion) .ids__cursos__item__button__ver:visible').length;
        const cursosPropios = $('.ids__cursos__item__comprado:not(.ids-introduccion):visible').length;
        const cursosPagos = $('.ids__cursos__item:not(.ids-introduccion):visible').length;
        const cursosCompradosAmenazas = $('.ids__cursos__item__button__ver[data-category=amenazas]:visible').length;
        const cursosCompradosDolores = $('.ids__cursos__item__button__ver[data-category=dolores]:visible').length;
        
        const cursosCompradosEstrategias = $('.ids__cursos__item__button__ver[data-category=estrategias]:visible').length;
        
        //  Variables para la validacion de cursos comprados  
        const todosCursosCompradosEstrategias = $('.ids__cursos__item__button__ver[data-category=estrategias]:visible').length;
        const todosCursosCompradosAmenazas = $('.ids__cursos__item__button__ver[data-category=amenazas]:visible').length;
        const todosCursosCompradosDolores = $('.ids__cursos__item__button__ver[data-category=dolores]:visible').length;
        
        console.log("cursosCompradosEstrategias: ", cursosCompradosEstrategias);
        console.log("cursosCompradosAmenazas: ", cursosCompradosAmenazas);
        console.log("cursosCompradosDolores: ", cursosCompradosDolores);

        let countTotales100 = 0;
        $('.ids__cursos__item:not(.ids-introduccion):visible .ld-progress-bar-percentage').each(function() {
            const percentage = $(this).width() / $(this).parent().width() * 100;
            if (percentage >= 100) {
                countTotales100++;
            }
        });

        if (cursosPagos) {
            const totalPercentage = countTotales100 / cursosPagos * 100;
            $('.ids-progress-bar-percentage').css({ width: totalPercentage + '%' });
            $('.ids-progress-percentage').html(`${totalPercentage.toFixed(0)}% Completado`);
        }
    
        $('.ld-profile-stat-courses strong').html(cursosPropios);

        if (cursosComprados) {
            $('.ids-seccion-comprar-todos').hide();
        }

        if (cursosCompradosEstrategias) {
            $('.js-curso-todos-estrategias').hide();
        }

        if (cursosCompradosAmenazas) {
            $('.js-curso-todos-amenazas').hide();
        }

        if (cursosCompradosDolores) {
            $('.js-curso-todos-dolores').hide();
        }

        console.log("cursosComprados: ", cursosComprados)

        if (true) {
            let precioIntroduccion = 0;  
            $('.ids__cursos__item[data-category=Introducción]:visible').each(function () {
                const element = $(this).find('.ld-progress-bar-percentage');
                const percentage = element.width() / element.parent().width() * 100;

                console.log("Porcentaje:" +percentage);
                if (percentage >= 0) {
                    precioIntroduccion ++;
                }
            });

            console.log(precioIntroduccion)
            
            $('.js-todos-cursos').hide();

            let priceTotal = 0;
            $('.ids__cursos__item[data-category=estrategias]:visible').each(function(index) {
                let price = $(this).attr('data-price');
                priceTotal += Number(price.replace(/\D/g,''));
            });

            
            priceTotal = (priceTotal - (43 * todosCursosCompradosEstrategias)).toFixed(0);
            
            //amenazas 
            let priceTotalAmenazas = 0;
            $('.ids__cursos__item[data-category=amenazas]:visible').each(function( index ) {
                let price = $(this).attr('data-price');
                priceTotalAmenazas += Number(price.replace(/\D/g,''));
            });

            //dolores
            let priceTotalDolores = 0;
            $('.ids__cursos__item[data-category=dolores]:visible').each(function( index ) {
                let price = $(this).attr('data-price');
                priceTotalDolores += Number(price.replace(/\D/g,''));
            });

            //estretegias
            const priceEstrategias = (priceTotal-(priceTotal*.1)).toFixed(0);
            
            // 1
            //amenazas
            priceTotalAmenazas = (priceTotalAmenazas - (39 * todosCursosCompradosAmenazas)).toFixed(0);
            const priceAmenazas = (priceTotalAmenazas-(priceTotalAmenazas*.1)).toFixed(0); 
            
            // 2
            //dolores
            priceTotalDolores = (priceTotalDolores - (29 * todosCursosCompradosDolores)).toFixed(0);
            const priceDolores = (priceTotalDolores-(priceTotalDolores*.1)).toFixed(0); 

            // 3
            if (precioIntroduccion > 0) {
                const priceprueba = Number(priceEstrategias) + Number(priceAmenazas) + Number(priceDolores);
                if(priceprueba !=0){

                console.log("priceprueba: ", priceprueba);

                $('.js-todos-cursos').show();
                $('.js-todos-cursos .price').html(priceprueba);

                }
            } else {
                const priceprueba = Number(priceEstrategias) + Number(priceAmenazas) + Number(priceDolores);
                if (priceprueba !=0) {
                    $('.js-todos-cursos').show();
                    $('.js-todos-cursos .price').html(priceprueba);
                }
            } 

            console.log("cursosComprados: ", cursosComprados)
            if (!cursosComprados) {
                let priceTotal = 0;
                $('.ids__cursos__item[data-category=estrategias]:visible').each(function() {
                    let price = $(this).attr('data-price');
                    priceTotal += Number(price.replace(/\D/g,''));
                });
                
                if (priceTotal !=0) $('.js-curso-todos-estrategias').show();
                
                const priceEstrategias = (priceTotal-(priceTotal*.1)).toFixed(0);
                $('.js-curso-todos-estrategias .price').html(priceEstrategias);
            }
    
            let countEstrategias = 0;
            let countEstrategiasCompletados = 0;
            $('.ids__cursos__item[data-category=estrategias]:visible').each(function() {
                countEstrategias++;
                const element = $(this).find('.ld-progress-bar-percentage');
                const percentage = element.width() / element.parent().width() * 100;
                if (percentage >= 100) {
                    countEstrategiasCompletados++;
                }
            });

            let countAmenazas = 0;
            let countAmenazasCompletados = 0;
            $('.ids__cursos__item[data-category=amenazas]:visible').each(function() {
                countAmenazas++;
                const element = $(this).find('.ld-progress-bar-percentage');
                const percentage = element.width() / element.parent().width() * 100;
                if (percentage >= 100) {
                    countAmenazasCompletados++;
                }
            });           

            let countDolores = 0;
            let countDoloresCompletados = 0;
            $('.ids__cursos__item[data-category=dolores]:visible').each(function() {
                countDolores++;
                const element = $(this).find('.ld-progress-bar-percentage');
                const percentage = element.width() / element.parent().width() * 100;
                if (percentage >= 100) {
                    countDoloresCompletados++;
                }
            });

            if(/*countEstrategias == countEstrategiasCompletados && */!cursosCompradosAmenazas){
                let priceTotalAmenazas = 0;
                $('.ids__cursos__item[data-category=amenazas]:visible').each(function() {
                    let price = $(this).attr('data-price');
                    priceTotalAmenazas += Number(price.replace(/\D/g,''));
                });
                if (priceTotalAmenazas !=0)  $('.js-curso-todos-amenazas').show();
                
                const priceAmenazas = (priceTotalAmenazas-(priceTotalAmenazas*.1)).toFixed(0);
                $('.js-curso-todos-amenazas .price').html(priceAmenazas);
            }
        
            if(/*countEstrategias == countEstrategiasCompletados && countAmenazas == countAmenazasCompletados && */ !cursosCompradosDolores){
                let priceTotalDolores = 0;
                $('.ids__cursos__item[data-category=dolores]:visible').each(function() {
                    let price = $(this).attr('data-price');
                    priceTotalDolores += Number(price.replace(/\D/g,''));
                });

                if (priceTotalDolores !=0) $('.js-curso-todos-dolores').show();

                const priceDolores = (priceTotalDolores-(priceTotalDolores*.1)).toFixed(0);
                $('.js-curso-todos-dolores .price').html(priceDolores);
            }
        }
    }
    cursosCompradosFunction();

    /**
     * @description
     * Añadir todos los cursos de la categoría estrategias al carrito
     */
    $(document).on('click', '.js-comprar-cursos-estrategias', function() {
        const price = $(this).find('.price').html();
        addCategoryCourse(code_scripts.all_estrategies_courses_product_id, price);
    });

    /**
     * @description
     * Comprar todos los cursos
     */
    $(document).on('click', '.js-comprar-todos-cursos', function() {
        const price = $(this).find('.price').html();
        console.log(price)
        addCategoryCourse(code_scripts.all_courses_product_id, price);
    });

    /**
     * @description
     * Añadir todos los cursos de la categoría amenazas al carrito
     */
    $(document).on('click', '.js-comprar-cursos-amenazas', function() {
        const price = $(this).find('.price').html();
        addCategoryCourse(code_scripts.all_threats_courses_product_id, price);
    });

    /**
     * @description
     * Añadir todos los cursos de la categoría dolores al carrito
     */
    $(document).on('click', '.js-comprar-cursos-dolores', function(event){
        const price = $(this).find('.price').html();
        addCategoryCourse(code_scripts.all_opportunities_courses_product_id, price);
    });

    /**
     * @description
     * Añadir todos los cursos de la categoría al carrito
     * @param {number} product_id
     * @param {number} price
     */
    function addCategoryCourse(product_id, price) {
        // $('.loading-course-categories').show();
        $.ajax({
            url : code_scripts.ajaxurl,
            type: 'post',
            data: {
                action : 'ids_wc_add_category_all_to_cart',
                product_id,
                price
            },
            beforeSend: function(){
                // code...
            },
            success: function(result){
                // Obtenemos Respuesta
                // $('.loading-course-categories').hide();
                $(location).prop('href', code_scripts.get_site_url + '/finalizar-compra' );
            }
        });
    }
    // ids_wc_add_category_all_to_cart
});