<?php

function sistemadi_signup_function($atts) {
    if(!is_admin()) {
        global $woocommerce;

        wp_enqueue_style( 'auth-styles', get_stylesheet_directory_uri() . '/components/shortcodes/login-signup.css' );

        $countries = WC()->countries->get_countries();
        $marital_statuses = array(
            'soltero' => 'Soltero',
            'casado' => 'Casado',
            'divorciado' => 'Divorciado',
            'viudo' => 'Viudo',
            'union_libre' => 'Unión libre'
        );

        ob_start();
        ?>
            <div>
                <form class="sistemadi-auth-form" id="sistemadi-signup-form">
                    <div id="sistemadi-error-messages"></div>
                    <div class="sistemadi-row">
                        <div class="sistemadi-form-group">
                            <label for="sistemadi-name">Nombre *</label>
                            <input type="text" id="sistemadi-name" name="sistemadi-name" required>
                        </div>
                        <div class="sistemadi-form-group">
                            <label for="sistemadi-lastname">Apellidos *</label>
                            <input type="text" id="sistemadi-lastname" name="sistemadi-lastname" required>
                        </div>
                    </div>

                    <div class="sistemadi-row">
                        <div class="sistemadi-form-group">
                            <label for="sistemadi-country">País *</label>
                            <select name="sistemadi-country" id="sistemadi-country" required>
                                <option value="">Seleccione...</option>
                                <?php
                                    foreach ($countries as $code => $name) {
                                    ?>
                                        <option value="<?php echo $code; ?>"> 
                                            <?php echo $name;?>
                                        </option>
                                    <?php
                                    }
                                ?>
                            </select>
                        </div>

                        <div class="sistemadi-form-group">
                            <label for="sistemadi-phone">Número de contacto *</label>
                            <input type="tel" id="sistemadi-phone" name="sistemadi-phone" required>
                        </div>
                    </div>

                    <div class="sistemadi-row">
                        <div class="sistemadi-form-group">
                            <label for="sistemadi-marital-status">Estado civil *</label>
                            <select name="sistemadi-marital-status" id="sistemadi-marital-status" required>
                                <option value="">Seleccione...</option>
                                <?php
                                    foreach ($marital_statuses as $key => $value) {
                                    ?>
                                        <option value="<?php echo $key; ?>"> 
                                            <?php echo $value;?>
                                        </option>
                                    <?php
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="sistemadi-form-group">
                            <label for="sistemadi-children">¿Tiene hijos? *</label>
                            <select name="sistemadi-children" id="sistemadi-children" required>
                                <option value="">Seleccione...</option>
                                <option value="si">Sí</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                    </div>

                    <div class="sistemadi-form-group">
                        <label for="sistemadi-email">Correo electrónico *</label>
                        <input type="email" id="sistemadi-email" name="sistemadi-email" required>
                    </div>

                    <div class="sistemadi-row">
                        <div class="sistemadi-form-group">
                            <label for="sistemadi-password">Contraseña *</label>
                            <input type="password" id="sistemadi-password" name="sistemadi-password" required>
                            <button class="sistemadi-password-toggle" type="button">
                                <img src="<?php print get_site_url() . '/wp-content/uploads/2026/01/Eye.svg'; ?>">
                            </button>
                        </div>
                        <div class="sistemadi-form-group">
                            <label for="sistemadi-password-confirm">Contraseña *</label>
                            <input type="password" id="sistemadi-password-confirm" name="sistemadi-password-confirm" required>
                            <button class="sistemadi-password-toggle" type="button">
                                <img src="<?php print get_site_url() . '/wp-content/uploads/2026/01/Eye.svg'; ?>">
                            </button>
                        </div>
                    </div>

                    <button type="submit" class="sistemadi-submit-button">Registrarse</button>
                </form>
            </div>
        <?php
        return ob_get_clean();
    }
}
add_shortcode('sistemadi_signup', 'sistemadi_signup_function');
