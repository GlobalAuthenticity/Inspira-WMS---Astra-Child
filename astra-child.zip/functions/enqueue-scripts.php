<?php

function sistemadi_enqueue_assets() {
    /**
     * Encolar estilos de Sistemadi  
     */
    wp_enqueue_style('layout-styles', get_stylesheet_directory_uri() . '/assets/css/layout.css');
    wp_enqueue_style('watu-styles', get_stylesheet_directory_uri() . '/assets/css/watu.css');
    wp_enqueue_style('header-styles', get_stylesheet_directory_uri() . '/assets/css/header.css');
    wp_enqueue_style('forms-styles', get_stylesheet_directory_uri() . '/assets/css/forms.css');

    // Estilos de WooCommerce
    wp_enqueue_style('woocommerce-checkout-styles', get_stylesheet_directory_uri() . '/assets/css/woocommerce/woocommerce-checkout.css');
    wp_enqueue_style('woocommerce-thankyou-styles', get_stylesheet_directory_uri() . '/assets/css/woocommerce/woocommerce-thankyou.css');
    wp_enqueue_style('woocommerce-my-account-styles', get_stylesheet_directory_uri() . '/assets/css/woocommerce/woocommerce-my-account.css');

    /** 
     * Encolar scripts de Sistemadi  
     */
    $js_dir = get_stylesheet_directory_uri() . '/assets/js/';

    // Nombre del usuario logueado (first_name + last_name, o user_login si no están cargados)
    $current_user  = wp_get_current_user();
    $user_full_name = trim( $current_user->first_name . ' ' . $current_user->last_name );
    if ( empty( $user_full_name ) ) {
        $user_full_name = $current_user->user_login;
    }

    // Data para scripts
    $data = array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'user_full_name' => $user_full_name,
        'page_result_padres' => AppConstants::PAGE_RESULT_PADRES, 
        'page_result_parejas' => AppConstants::PAGE_RESULT_PAREJAS,
        'page_result_individual' => AppConstants::PAGE_RESULT_PERSONAL,
        'all_courses_product_id' => AppConstants::ALL_COURSES_PRODUCT_ID,
        'all_threats_courses_product_id' => AppConstants::ALL_THREATS_COURSES_PRODUCT_ID,
        'all_estrategies_courses_product_id' => AppConstants::ALL_STRATEGIES_COURSES_PRODUCT_ID,
        'all_opportunities_courses_product_id' => AppConstants::ALL_OPPORTUNITIES_COURSES_PRODUCT_ID,
        'get_site_url' => get_site_url(), 
        'get_url_account' => get_permalink( get_option('woocommerce_myaccount_page_id') ), 
        'get_url_cart' => get_site_url().'/carrito',
        'url_comprar_personal' => AppConstants::urlComprarTestByType(AppConstants::TEST_TYPE_PERSONAL),
        'url_comprar_parejas' => AppConstants::urlComprarTestByType(AppConstants::TEST_TYPE_PAREJAS),
        'url_comprar_padres' => AppConstants::urlComprarTestByType(AppConstants::TEST_TYPE_PADRES),
        'url_my_id' => get_permalink( get_option('woocommerce_myaccount_page_id') ) . '/mi-id',
        'url_result_pareja' => get_site_url().'/resultado-test-pareja',
        'code_url' => content_url(), 
        'form_nonce' => wp_create_nonce( 'add_ids_form' ),
        'form_nonce_signup' => wp_create_nonce( 'add_ids_form_signup' ),
        'form_nonce_signup_completed' => wp_create_nonce( 'add_ids_form_completed' ),
        'form_nonce_signup_complement' => wp_create_nonce( 'add_ids_form_signup_complement' ),
        'form_nonce_signin' => wp_create_nonce( 'add_ids_form_signin' ),
        'form_nonce_personal' => wp_create_nonce( 'add_saved_form_personal' ),
        'form_nonce_test_result' => wp_create_nonce( 'add_saved_test_results' ),
        //Url para llevar al carrito de compras al usuario con el producto de padres. ID: 84974
    );

    // Librerías de terceros
    wp_register_script(
        'selectize_js', 
        'https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js'
    );
    wp_enqueue_script('selectize_js');
    wp_enqueue_style('selectize_js-styles', 'https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css');

    wp_register_script(
        'ids_charts', 
        'https://cdn.jsdelivr.net/npm/chart.js@4.0.0-release/dist/chart.umd.min.js'
    );
    wp_enqueue_script('ids_charts');

    wp_register_script(
        'ids_sweetalert2', 
        'https://cdn.jsdelivr.net/npm/sweetalert2@11'
    );
    wp_enqueue_script('ids_sweetalert2');

    wp_register_script(
        'ids_toastr', 
        'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js'
    );
    wp_enqueue_script('ids_toastr');
    wp_enqueue_style('ids_toastr-styles', 'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css');

    wp_register_script(
        'ids_jquery_browser', 
        'https://cdnjs.cloudflare.com/ajax/libs/jquery-browser/0.1.0/jquery.browser.min.js'
    );
    wp_enqueue_script('ids_jquery_browser');

    // Scripts propios
    wp_enqueue_script(
        'sistemadi-results-js',
        $js_dir . 'results-ids.js', 
        array('jquery', 'ids_charts', 'ids_sweetalert2', 'ids_jquery_browser'), 
        '1.0', 
        true
    );
    wp_enqueue_script('watu-autophill-js', $js_dir . 'watu-autophill.js', NULL, '1.0', true);
    wp_enqueue_script('sistemadi-header-js', $js_dir . 'header.js', NULL, '1.0', true);
    wp_enqueue_script('sistemadi-test-js', $js_dir . 'test-ids.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-login-js', $js_dir . 'login.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-signup-js', $js_dir . 'signup.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-logout-js', $js_dir . 'logout.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-buy-courses-js', $js_dir . 'buy-courses.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-pending-test-js', $js_dir . 'pending-test.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-yith-menu-js', $js_dir . 'yith-menu.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-validate-couple-js', $js_dir . 'validate-couple.js', array('jquery'), '1.0', true);
    wp_enqueue_script('sistemadi-snackbar-couple-pending-test-js', $js_dir . 'snackbar-couple-pending-test.js', array('jquery'), '1.0', true);
    wp_enqueue_script('download-results-js', $js_dir . 'download-results.js', array('jquery'), '1.0', true);
    wp_enqueue_script('report-content-table-js', $js_dir . 'report-content-table.js', array('jquery'), '1.0', true);
    wp_enqueue_script('reset-password', $js_dir . 'reset-password.js', array('jquery'), '1.0', true);
    wp_enqueue_script('view-courses', $js_dir . 'view-courses.js', array('jquery'), '1.0', true);
    wp_enqueue_script('item-movile', $js_dir . 'item-movile.js', array('jquery'), '1.0', true);

    /**
     * Localizar variables de PHP en JS
     */
    wp_localize_script('sistemadi-test-js', 'code_scripts', $data);
    wp_localize_script('sistemadi-login-js', 'code_scripts', $data);
    wp_localize_script('sistemadi-signup-js', 'code_scripts', $data);
    wp_localize_script('sistemadi-logout-js', 'code_scripts', $data);
    wp_localize_script('sistemadi-results-js', 'code_scripts', $data);
    wp_localize_script('sistemadi-buy-courses-js', 'code_scripts', $data);
    wp_localize_script('sistemadi-snackbar-couple-pending-test-js', 'code_scripts', $data);
    wp_localize_script('download-results-js', 'code_scripts', $data);
    wp_localize_script('report-content-table-js', 'code_scripts', $data);
    wp_localize_script('reset-password', 'code_scripts', $data);
    wp_localize_script('item-movile', 'code_scripts', $data);
}
add_action('wp_enqueue_scripts', 'sistemadi_enqueue_assets');
