<?php

if ( !function_exists('sistemadi_validate_menu_elements') ) {
  /**
   * 
   *  Deshabilitar/remover opciones en el menú lateral izquierdo del dashboard:
   *  
   *  - Resultados: si el usuario no ha completado el test
   *  - Cursos: si la empresa adquirió los cursos pero el usuario no completó el test
   *  - Cursos: si la empresa NO adquirió los cursos
   *  - Sentido y Propósito: se remueve del menú si el usuario no tiene acceso a Octágono (SSO)
   *  - Programas Liderazgo: se remueve del menú si el usuario no tiene acceso a WMS Latam (SSO)
   */

  function sistemadi_validate_menu_elements($item, $options) {
    // Validar que el usuario esté logueado
    $user_id = get_current_user_id();

    if(!$user_id) {
      // Si no hay usuario, salir de la función
      return;
    }

    /**
     *  Validaciones SSO: Octágono (sentido y propósito) / WMS Latam (liderazgo)
     *  Si no tiene acceso, se remueve el ítem por completo (no se imprime nada).
     */
    if ( function_exists('mi_sso_user_has_access') ) {

      if ( ! mi_sso_user_has_access('octagono') && $options['class'] == 'my-sentido-y-proposito' ) {
        return;
      }

      if ( ! mi_sso_user_has_access('wmslatam') && $options['class'] == 'my-programas-liderazgo' ) {
        return;
      }

    } else {
      error_log('sistemadi_validate_menu_elements: mi_sso_user_has_access() no existe en este contexto.');
    }

    wp_enqueue_script( 'yith-menu-js', get_stylesheet_directory_uri() . '/assets/js/yith-menu.js', array('jquery'), '', true );

    $classes = array();
    // Set item classes.
    if ( ! empty( $options['class'] ) ) {
      $classes[] = $options['class'];
    }

    // Get current endpoint.
    $current = yith_wcmap_get_current_endpoint();
    if ( $item === $current ) {
      $classes[] = 'active';
    }

    $url = get_permalink( wc_get_page_id( 'myaccount' ) );
    if ( 'dashboard' !== $item ) {
      $url = wc_get_endpoint_url( $item, '', $url );
    }

    /**
     *  Validaciones para los apartados de resultados y cursos
     */
    // Si el usuario no ha realizado el test
    if (!UserQueries::user_completed_test($user_id)) {
      if ($options['class'] == 'my-results' || $options['class'] == 'my-courses' || $options['class'] == 'my-efren-ia' || $options['class'] == 'my-recursos-adicionales') {
        // Se deshabilitan los apartados "mis resultados", "cursos del área" y "cursos"
        $classes[] = 'yith-item-disabled';
      }
    }

    // Si el usuario ha realizado el test, pero no ha comprado ningún tipo de resultado
    if 
    (
      UserQueries::user_completed_test($user_id) && 
      (
        !!UserQueries::user_bought_test($user_id, AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PADRES]) &&
        !!UserQueries::user_bought_test($user_id, AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PAREJAS]) &&
        !!UserQueries::user_bought_test($user_id, AppConstants::TESTS_PRODUCTS_IDS[AppConstants::TEST_TYPE_PERSONAL])
      )
    ) {
      if ($options['class'] == 'my-results') {
        // Se deshabilita el apartado "Resultados"
        $classes[] = 'yith-item-disabled';
      }
    }

    // Let's filter only item classes.
    /**
     * APPLY_FILTERS: yith_wcmap_endpoint_menu_class
     *
     * Filters the CSS classes for the endpoint in the menu.
     *
     * @param array  $classes  CSS classes.
     * @param string $item    Item key.
     * @param array  $options Item options.
     *
     * @return array
     */
    $classes = apply_filters( 'yith_wcmap_endpoint_menu_class', $classes, $item, $options );
  
    // Build args array.
    /**
     * APPLY_FILTERS: yith_wcmap_print_single_endpoint_args
     *
     * Filters the array of arguments needed to print the endpoint.
     *
     * @param array  $args    Array of arguments.
     * @param string $item    Item key.
     * @param array  $options Item options.
     *
     * @return array
     */
    
    $args = apply_filters(
      'yith_wcmap_print_single_endpoint_args',
      array(
        'url'      => $url,
        'endpoint' => $item,
        'options'  => $options,
        'classes'  => $classes,
      ),
      $item,
      $options
    );
  
    wc_get_template( 'ywcmap-myaccount-menu-item.php', $args, '', YITH_WCMAP_DIR . 'templates/' );
  }
}

add_action( 'yith_wcmap_print_single_endpoint', 'sistemadi_validate_menu_elements', 10, 2 );